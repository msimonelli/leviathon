﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Battle Grid")]
	public class BattleGridComponent : MonoBehaviour
	{
		// generation settings
		public int rows = 10;

		public int columns = 10;

		public TextAnchor positionAnchor = TextAnchor.MiddleCenter;

		public bool generateKeepOldCells = false;

		// cell settings
		public bool useSlope = false;

		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int cellTypeID = 0;

		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int emptyCellTypeID = 0;

		public bool useBlockedType = false;

		public float blockedTypeSlope = 45;

		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int blockedCellTypeID = 0;

		// raycast settings
		public LayerMask rayLayerMask = -1;

		public Vector3 raySourceOffset = new Vector3(0, 10, 0);

		public float rayDistance = 100;

		public Vector3 rayHitOffset = Vector3.zero;

		// editor display
		public bool showEditorGrid = false;

		public bool showEditorPrefabs = false;

		public bool showEditorUnselected = false;

		private bool editorPrefabsShowing = false;


		// generated battle grid
		public bool autoShowGrid = false;

		public BattleGridCellRow[] cellRow;


		// in-game
		private bool highlightsHidden = false;

		// notify
		private Notify gridChangedHandler;
		public event Notify GridChanged
		{
			add { this.gridChangedHandler += value; }
			remove { this.gridChangedHandler -= value; }
		}

		public void FireGridChanged()
		{
			if(this.gridChangedHandler != null)
			{
				this.gridChangedHandler();
			}
		}

		public void Start()
		{
			if(this.autoShowGrid)
			{
				this.ShowGridPrefabs();
			}
		}


		/*
		============================================================================
		Grid functions
		============================================================================
		*/
		public void RemoveGrid()
		{
			if(this.cellRow != null)
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].Length; j++)
					{
						if(this.cellRow[i][j] != null)
						{
							GameObject.DestroyImmediate(this.cellRow[i][j].gameObject);
						}
					}
				}
			}
			this.cellRow = null;
		}

		public BattleGridCellComponent GetCell(int row, int column)
		{
			if(this.cellRow != null &&
				row >= 0 && row < this.cellRow.Length &&
				column >= 0 && column < this.cellRow[row].Length)
			{
				return this.cellRow[row][column];
			}
			return null;
		}

		public BattleGridCellComponent GetCell(CubeCoord coord)
		{
			int row = 0;
			int column = 0;
			coord.ToOffset(ref row, ref column);

			if(this.cellRow != null &&
				row >= 0 && row < this.cellRow.Length &&
				column >= 0 && column < this.cellRow[row].Length)
			{
				return this.cellRow[row][column];
			}
			return null;
		}

		public void GetCells(ref List<BattleGridCellComponent> cells, GridCellCheck check)
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].Length; j++)
					{
						if(this.cellRow[i][j] != null &&
							(check == null || check(this.cellRow[i][j])))
						{
							cells.Add(this.cellRow[i][j]);
						}
					}
				}
			}
		}

		public BattleGridCellComponent GetNearestFreeCell(Combatant combatant)
		{
			BattleGridCellComponent nearest = null;
			float distance = Mathf.Infinity;

			if(this.cellRow != null &&
				combatant != null)
			{
				Vector3 position = combatant.GameObject != null ?
					combatant.GameObject.transform.position :
					(combatant.BattleSpot != null ?
						combatant.BattleSpot.transform.position :
						this.transform.position);
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].Length; j++)
					{
						if(this.cellRow[i][j] != null &&
							this.cellRow[i][j].enabled &&
							this.cellRow[i][j].gameObject.activeInHierarchy &&
							!this.cellRow[i][j].IsBlocked &&
							this.cellRow[i][j].IsEmpty)
						{
							float tmp = Vector3.Distance(position,
								this.cellRow[i][j].transform.position);
							if(tmp < distance)
							{
								nearest = this.cellRow[i][j];
								distance = tmp;
							}
						}
					}
				}
			}
			return nearest;
		}

		public BattleGridCellComponent GetNearestDeploymentCell(Combatant combatant)
		{
			BattleGridCellComponent nearest = null;
			float distance = Mathf.Infinity;

			if(this.cellRow != null &&
				combatant != null)
			{
				Vector3 position = combatant.GameObject != null ?
					combatant.GameObject.transform.position :
					(combatant.BattleSpot != null ?
						combatant.BattleSpot.transform.position :
						this.transform.position);
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].Length; j++)
					{
						if(this.cellRow[i][j] != null &&
							this.cellRow[i][j].enabled &&
							this.cellRow[i][j].gameObject.activeInHierarchy &&
							this.cellRow[i][j].CanDeploy(combatant))
						{
							float tmp = Vector3.Distance(position,
								this.cellRow[i][j].transform.position);
							if(tmp < distance)
							{
								nearest = this.cellRow[i][j];
								distance = tmp;
							}
						}
					}
				}
			}
			return nearest;
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public void ShowGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].Length; j++)
					{
						if(this.cellRow[i][j] != null)
						{
							this.cellRow[i][j].ShowPrefab();
						}
					}
				}
			}
		}

		public void HideGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].Length; j++)
					{
						if(this.cellRow[i][j] != null)
						{
							this.cellRow[i][j].HidePrefab();
						}
					}
				}
			}
		}

		public void RemoveGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].Length; j++)
					{
						if(this.cellRow[i][j] != null)
						{
							this.cellRow[i][j].DestroyPrefab();
						}
					}
				}
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public bool HighlightsHidden
		{
			get { return this.highlightsHidden; }
			set
			{
				if(this.highlightsHidden != value)
				{
					this.highlightsHidden = value;

					for(int i = 0; i < this.cellRow.Length; i++)
					{
						if(this.cellRow[i] != null)
						{
							for(int j = 0; j < this.cellRow[i].Length; j++)
							{
								if(this.cellRow[i][j] != null)
								{
									this.cellRow[i][j].HideHighlights(this.highlightsHidden);
								}
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "BattleGrid.psd");

			if(this.showEditorGrid &&
				this.showEditorPrefabs &&
				this.showEditorUnselected &&
				!Application.isPlaying)
			{
				this.EditorShowPrefabs();
			}
		}

		public void EditorShowPrefabs()
		{
			if(this.cellRow != null &&
				!this.editorPrefabsShowing)
			{
				this.editorPrefabsShowing = true;

				for(int i = 0; i < this.cellRow.Length; i++)
				{
					if(this.cellRow[i] != null)
					{
						for(int j = 0; j < this.cellRow[i].Length; j++)
						{
							if(this.cellRow[i][j] != null)
							{
								this.cellRow[i][j].ShowPrefab();
							}
						}
					}
				}
			}
		}

		public void EditorDestroyPrefabs()
		{
			this.editorPrefabsShowing = false;

			if(this.cellRow != null)
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					if(this.cellRow[i] != null)
					{
						for(int j = 0; j < this.cellRow[i].Length; j++)
						{
							if(this.cellRow[i][j] != null &&
								this.cellRow[i][j].PrefabInstance != null)
							{
								GameObject.DestroyImmediate(this.cellRow[i][j].PrefabInstance);
							}
						}
					}
				}
			}
		}
	}
}
