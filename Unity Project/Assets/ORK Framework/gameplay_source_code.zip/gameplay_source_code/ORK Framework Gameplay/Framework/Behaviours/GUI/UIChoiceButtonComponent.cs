
using UnityEngine;
using UnityEngine.UI;
using ORKFramework.UI;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework.Behaviours
{
	public class UIChoiceButtonComponent : MonoBehaviour
	{
		private GUIBox box;

		private ChoiceContent content;

		private Button button;

		private ButtonClick callback;

		private int choiceIndex = 0;


		// fade
		private bool startInactive = false;

		private NewUIButtonSettings buttonSettings;

		private CanvasRenderer canvasRenderer;

		private List<CanvasRenderer> childRenderer;

		public void Initialize(GUIBox box, ChoiceContent content, Button button, ButtonClick callback, int choiceIndex, NewUIButtonSettings buttonSettings)
		{
			this.box = box;
			this.content = content;
			this.buttonSettings = buttonSettings;

			this.button = button;
			this.callback = callback;
			this.choiceIndex = choiceIndex;
			if(this.button != null)
			{
				this.button.onClick.AddListener(this.ClickDelegate);
			}

			this.startInactive = !this.content.Active;

			if(this.buttonSettings != null)
			{
				this.canvasRenderer = this.GetComponent<CanvasRenderer>();
				if(this.buttonSettings.fadeMode == ChildColorFadeMode.None)
				{
					if(this.childRenderer != null)
					{
						this.childRenderer.Clear();
					}
				}
				else
				{
					ArrayHelper.GetBlank(ref this.childRenderer);
					this.GetComponentsInChildren<CanvasRenderer>(this.childRenderer);
					this.childRenderer.Remove(this.canvasRenderer);
				}
			}
		}

		private void ClickDelegate()
		{
			if(this.callback != null &&
				this.box.Controlable &&
				this.content.Active &&
				(!this.box.unfocusedClick ||
					this.box.Settings.unfocusedChoice))
			{
				this.callback(this.choiceIndex);
			}
		}

		public void Clear()
		{
			if(this.button != null &&
				this.callback != null)
			{
				this.button.onClick.RemoveListener(this.ClickDelegate);
			}
			if(this.content != null)
			{
				this.content.buttonRectTransform = null;
			}

			this.box = null;
			this.content = null;
			this.button = null;
			this.buttonSettings = null;
			this.canvasRenderer = null;
			if(this.childRenderer != null)
			{
				this.childRenderer.Clear();
			}
		}

		void LateUpdate()
		{
			if(this.box != null &&
				this.canvasRenderer != null &&
				this.buttonSettings != null)
			{
				Color boxColor = this.box.controlable && this.box.focusable &&
					!this.box.IsClosing && !this.box.Focused &&
					this.box.InactiveColor.setColor ?
						this.box.InactiveColor.color : this.box.color;

				Color color = this.canvasRenderer.GetColor();
				if(!this.box.IsOpened)
				{
					this.canvasRenderer.SetColor(color * boxColor);
					color *= boxColor;
				}
				if(this.startInactive)
				{
					if(!this.content.Active &&
						Selectable.Transition.ColorTint == this.button.transition)
					{
						color = this.button.colors.disabledColor;
						this.canvasRenderer.SetColor(color * boxColor);
					}
					else
					{
						this.startInactive = false;
					}
				}

				if(this.buttonSettings.useInactiveColor &&
					!this.content.Active)
				{
					color = this.buttonSettings.inactiveColor;
					color *= boxColor;
				}
				else
				{
					if(this.box.controlable && this.box.focusable &&
						!this.box.Focused && this.box.InactiveColor.setColor)
					{
						color = this.box.InactiveColor.color;
						this.canvasRenderer.SetColor(color);
					}
				}

				if(this.childRenderer != null &&
					this.childRenderer.Count > 0)
				{
					if(this.buttonSettings.fadeMode == ChildColorFadeMode.Alpha)
					{
						for(int i = 0; i < this.childRenderer.Count; i++)
						{
							if(this.childRenderer[i] != null)
							{
								this.childRenderer[i].SetAlpha(color.a);
							}
						}
					}
					else if(this.buttonSettings.fadeMode == ChildColorFadeMode.Color)
					{
						for(int i = 0; i < this.childRenderer.Count; i++)
						{
							if(this.childRenderer[i] != null)
							{
								this.childRenderer[i].SetColor(color);
							}
						}
					}
				}
			}
		}
	}
}
