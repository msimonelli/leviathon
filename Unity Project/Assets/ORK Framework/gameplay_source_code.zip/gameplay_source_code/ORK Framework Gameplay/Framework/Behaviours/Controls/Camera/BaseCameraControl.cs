
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public abstract class BaseCameraControl : MonoBehaviour
	{
		private GameObject cameraTarget;


		// transition
		private CameraControlTargetTransition targetTransition;

		private float transitionTime = -1;

		private Vector3 previousTargetPosition;

		public GameObject CameraTarget
		{
			get
			{
				if(this.cameraTarget == null)
				{
					return ORK.Game.GetPlayer();
				}
				else
				{
					return this.cameraTarget;
				}
			}
		}

		public void SetCameraControlTarget(GameObject target, CameraControlTargetTransition transition)
		{
			GameObject previousTarget = this.CameraTarget;
			if(previousTarget != target &&
				(this.cameraTarget != null || target != null))
			{
				this.cameraTarget = target;
				GameObject newTarget = this.CameraTarget;

				this.targetTransition = transition;

				if(newTarget != null &&
					this.CameraTargetTransition.enabled)
				{
					this.transitionTime = 0;
					this.CameraTargetTransition.StartTransition(this.transform,
						previousTarget != null ?
							VectorHelper.Distance(newTarget.transform.position,
								previousTarget.transform.position, true) :
							1);
				}
				else
				{
					this.transitionTime = -1;
				}
				this.CameraTargetChanged(previousTarget, newTarget);
			}
		}

		public void ResetCurrentCameraTarget(CameraControlTargetTransition transition)
		{
			GameObject target = this.CameraTarget;
			this.targetTransition = transition;

			if(target != null &&
				this.CameraTargetTransition.enabled)
			{
				this.transitionTime = 0;
				this.CameraTargetTransition.StartTransition(this.transform,
					VectorHelper.Distance(this.gameObject, target, true));
			}
			else
			{
				this.transitionTime = -1;
			}

			this.CameraTargetChanged(target, target);
		}

		public virtual void CameraTargetChanged(GameObject oldTarget, GameObject newTarget)
		{

		}

		public void UpdatePosition(Vector3 position, Quaternion rotation)
		{
			if(this.IsCameraTargetTransition)
			{
				this.TransitionUpdate(position, rotation);
			}
			else
			{
				this.transform.SetPositionAndRotation(position, rotation);
			}
		}


		/*
		============================================================================
		Transition functions
		============================================================================
		*/
		public CameraControlTargetTransition CameraTargetTransition
		{
			get
			{
				if(this.targetTransition != null)
				{
					return this.targetTransition;
				}
				return ORK.GameControls.cameraControl.targetTransition;
			}
		}

		public bool IsCameraTargetTransition
		{
			get
			{
				return this.CameraTargetTransition.enabled &&
					this.transitionTime >= 0;
			}
		}

		public void TransitionUpdate(Vector3 position, Quaternion rotation)
		{
			this.transitionTime += Time.deltaTime;
			if(this.CameraTargetTransition.Transition(this.transform,
				position, rotation, this.transitionTime))
			{
				this.transitionTime = -1;
				this.targetTransition = null;
			}
		}
	}
}
