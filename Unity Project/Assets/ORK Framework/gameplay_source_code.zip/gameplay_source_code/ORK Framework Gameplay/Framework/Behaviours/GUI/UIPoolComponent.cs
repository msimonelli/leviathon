﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class UIPoolComponent : MonoBehaviour
	{
		private GameObject prefab;

		public GameObject Prefab
		{
			get { return this.prefab; }
			set { this.prefab = value; }
		}
	}
}
