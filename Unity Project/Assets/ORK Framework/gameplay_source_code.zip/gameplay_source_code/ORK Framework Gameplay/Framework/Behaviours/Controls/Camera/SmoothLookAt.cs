
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Smooth Look At")]
	public class SmoothLookAt : BaseCameraControl
	{
		public string onChild = "";

		public float damping = 6.0f;

		public bool smooth = true;

		void Start()
		{
			Rigidbody rigidbody = this.GetComponent<Rigidbody>();
			if(rigidbody != null)
			{
				rigidbody.freezeRotation = true;
			}
		}

		void LateUpdate()
		{
			GameObject targetObject = TransformHelper.GetChildObject(this.onChild, this.CameraTarget);
			if(targetObject != null)
			{
				Quaternion rotation = VectorHelper.LookAt(this.transform.position,
					targetObject.transform.position);

				if(this.smooth &&
					this.damping > 0)
				{
					rotation = Quaternion.Slerp(
						this.transform.rotation, rotation,
						Time.deltaTime * this.damping);
				}

				this.UpdatePosition(this.transform.position, rotation);
			}
		}
	}
}
