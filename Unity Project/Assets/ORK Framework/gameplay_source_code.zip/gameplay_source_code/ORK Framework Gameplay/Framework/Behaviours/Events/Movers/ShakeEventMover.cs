﻿
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class ShakeEventMover : MonoBehaviour
	{
		private Transform taret;

		private float time;

		private float time2;

		private float hitTime;


		// shaker
		private bool shaking = false;

		private float xIntensity;

		private float yIntensity;

		private float zIntensity;

		private Vector3 originalPosition;

		private float shakeSpeed;

		public void Stop()
		{
			this.shaking = false;
		}

		public void StartShake(Transform target, float time,
			float xIntensity, float yIntensity, float zIntensity, float speed)
		{
			this.Stop();

			this.taret = target;
			this.time = 0;
			this.time2 = time;
			this.xIntensity = xIntensity;
			this.yIntensity = yIntensity;
			this.zIntensity = zIntensity;
			this.shakeSpeed = speed;

			this.hitTime = Time.time;
			this.originalPosition = this.taret.localPosition;
			this.shaking = true;
		}

		void Update()
		{
			if(this.taret != null &&
				this.shaking &&
				!ORK.Game.Paused)
			{
				this.time += ORK.Game.DeltaTime;

				float timer = (Time.time - hitTime) * shakeSpeed;
				float factor = (1 - ((this.time2 - this.time) / this.time2));

				this.taret.localPosition = new Vector3(
					this.xIntensity != 0 ?
						this.originalPosition.x + Mathf.Sin(timer) * this.xIntensity * factor :
						this.taret.localPosition.x,
					this.yIntensity != 0 ?
						this.originalPosition.y + Mathf.Sin(timer) * this.yIntensity * factor :
						this.taret.localPosition.y,
					this.zIntensity != 0 ?
						this.originalPosition.z + Mathf.Sin(timer) * this.zIntensity * factor :
						this.taret.localPosition.z);

				if(timer > Mathf.PI * 2)
				{
					hitTime = Time.time;
				}

				if(this.time >= this.time2)
				{
					this.taret.localPosition = new Vector3(
						this.xIntensity != 0 ? this.originalPosition.x : this.taret.localPosition.x,
						this.yIntensity != 0 ? this.originalPosition.y : this.taret.localPosition.y,
						this.zIntensity != 0 ? this.originalPosition.z : this.taret.localPosition.z);
					this.shaking = false;
				}
			}
		}
	}
}
