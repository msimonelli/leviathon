
using UnityEngine;

namespace ORKFramework
{
	[System.Serializable]
	public class CombatantGroupMember : BaseData
	{
		[ORKEditorHelp("Combatant", "Select the combatant that will join the group.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		public int id = 0;


		// start inventory/equipment
		[ORKEditorHelp("Use Start Inventory", "Use the combatant's start inventory.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useStartInventory = true;

		[ORKEditorHelp("Use Start Equipment", "Use the combatant's start equipment.", "")]
		public bool useStartEquipment = true;


		// base level
		[ORKEditorHelp("Set Level", "Select which level this combatant will have:\n" +
			"- Default: The level will be set according to it's start level in the combatant settings.\n" +
			"- Player: The level will be set to match the average level of the player's group.\n" +
			"- Random: The level will be set randomly between a minimum and maximum.\n" +
			"- Variable: The level will be set using the value of a game variable (float).", "")]
		[ORKEditorInfo(separator=true, labelText="Level Settings")]
		public CombatantInit levelInit = CombatantInit.Default;

		// player
		[ORKEditorHelp("Only Battle", "Only members of the player's battle group will be used to get the average level.", "")]
		[ORKEditorLayout("levelInit", CombatantInit.Player)]
		public bool levelOnlyBattle = false;

		[ORKEditorHelp("Minimum Offset", "Minimum offset added to the average level of the players group.", "")]
		public int levelMinOffset = -5;

		[ORKEditorHelp("Maximum Offset", "Maximum offset added to the average level of the players group.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int levelMaxOffset = 5;

		// random
		[ORKEditorHelp("Minimum Random", "Minimum random level (included).", "")]
		[ORKEditorLayout("levelInit", CombatantInit.Random)]
		[ORKEditorLimit(1, false)]
		public int levelMinRandom = 1;

		[ORKEditorHelp("Maximum Random", "Maximum random level (included).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int levelMaxRandom = 99;

		// variable
		[ORKEditorHelp("Variable Key", "The key (name) of the game variable (float) used.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout("levelInit", CombatantInit.Variable, endCheckGroup=true)]
		public string levelKey = "";


		// class level
		[ORKEditorHelp("Set Class Level", "Select which class level this combatant will have:\n" +
			"- Default: The class level will be set according to its start level in the combatant settings.\n" +
			"- Player: The class level will be set to match the average class level of the player's group.\n" +
			"- Random: The class level will be set randomly between a minimum and maximum.\n" +
			"- Variable: The class level will be set using the value of a game variable (float).", "")]
		[ORKEditorInfo(separator=true, labelText="Class Level Settings")]
		public CombatantInit classInit = CombatantInit.Default;

		// player
		[ORKEditorHelp("Only Battle", "Only members of the player's battle group will be used to get the average class level.", "")]
		[ORKEditorLayout("classInit", CombatantInit.Player)]
		public bool classOnlyBattle = false;

		[ORKEditorHelp("Minimum Offset", "Minimum offset added to the average class level of the players group.", "")]
		public int classMinOffset = -5;

		[ORKEditorHelp("Maximum Offset", "Maximum offset added to the average class level of the players group.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int classMaxOffset = 5;

		// random
		[ORKEditorHelp("Minimum Random", "Minimum random class level (included).", "")]
		[ORKEditorLayout("classInit", CombatantInit.Random)]
		[ORKEditorLimit(1, false)]
		public int classMinRandom = 1;

		[ORKEditorHelp("Maximum Random", "Maximum random class level (included).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int classMaxRandom = 99;

		// variable
		[ORKEditorHelp("Variable Key", "The key (name) of the game variable (float) used.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout("classInit", CombatantInit.Variable, endCheckGroup=true)]
		public string classKey = "";

		public CombatantGroupMember()
		{

		}

		public Combatant Create(Group group)
		{
			int lvl = ORK.Combatants.Get(this.id).startLevel;
			int cLvl = ORK.Combatants.Get(this.id).startClassLevel;

			// base level
			if(CombatantInit.Player == this.levelInit)
			{
				if(this.levelOnlyBattle)
				{
					lvl = ORK.Game.ActiveGroup.AverageBattleLevel;
				}
				else
				{
					lvl = ORK.Game.ActiveGroup.AverageLevel;
				}
				lvl = Random.Range(lvl + this.levelMinOffset, lvl + this.levelMaxOffset + 1);
			}
			else if(CombatantInit.Random == this.levelInit)
			{
				if(this.levelMinRandom == this.levelMaxRandom)
				{
					lvl = this.levelMinRandom;
				}
				else
				{
					lvl = Random.Range(this.levelMinRandom, this.levelMaxRandom + 1);
				}
			}
			else if(CombatantInit.Variable == this.levelInit)
			{
				lvl = (int)ORK.Game.Variables.GetFloat(this.levelKey);
			}

			// class level
			if(CombatantInit.Player == this.classInit)
			{
				if(this.classOnlyBattle)
				{
					cLvl = ORK.Game.ActiveGroup.AverageBattleClassLevel;
				}
				else
				{
					cLvl = ORK.Game.ActiveGroup.AverageClassLevel;
				}
				cLvl = Random.Range(cLvl + this.classMinOffset, cLvl + this.classMaxOffset + 1);
			}
			else if(CombatantInit.Random == this.classInit)
			{
				if(this.classMinRandom == this.classMaxRandom)
				{
					cLvl = this.classMinRandom;
				}
				else
				{
					cLvl = Random.Range(this.classMinRandom, this.classMaxRandom + 1);
				}
			}
			else if(CombatantInit.Variable == this.classInit)
			{
				cLvl = (int)ORK.Game.Variables.GetFloat(this.classKey);
			}

			// minimum level is 1
			if(lvl < 1)
			{
				lvl = 1;
			}
			if(cLvl < 1)
			{
				cLvl = 1;
			}

			Combatant combatant = ORK.Combatants.Create(this.id, group);
			combatant.Init(lvl, cLvl, combatant.Setting.startClassID,
				this.useStartInventory, this.useStartEquipment);
			return combatant;
		}

		public string GetInfoText()
		{
			return ORK.Combatants.GetName(this.id);
		}
	}
}
