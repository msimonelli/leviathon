﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class GridCellEvent : BaseData
	{
		[ORKEditorHelp("Event Type", "Select what will be performed by this cell event:\n" +
			"- Ability: Uses an ability with the combatant as a target.\n" +
			"- Status Effect: Changes status effects on the combatant.\n" +
			"- Game Event: Starts a game event with the combatant as starting object.", "")]
		public GridCellEventType type = GridCellEventType.Ability;

		[ORKEditorHelp("Start Type", "Select when this cell event will be started:\n" +
			"- None: Can only be started through the event system.\n" +
			"- Any: Starts with any other type.\n" +
			"- Move To: Starts when a combatant moves to this cell (i.e. target of a move command).\n" +
			"- Move Over: Starts when a combatant moves over this cell (i.e. path of a move command).\n" +
			"- Start Turn: Starts when a combatant's turn starts on this cell.\n" +
			"- End Turn: Starts when a combatant's turn ends on this cell.", "")]
		public GridCellEventStartType startType = GridCellEventStartType.None;


		// ability
		[ORKEditorHelp("Ability", "Select the ability that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability, separator=true, labelText="Ability Settings")]
		[ORKEditorLayout("type", GridCellEventType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("Level", "Define the ability level that will be used.", "")]
		[ORKEditorLimit(1, false)]
		public int level = 1;

		[ORKEditorHelp("Animate Ability", "Using the ability will be animated.\n" +
			"If disabled, the ability will only calculate the outcome.", "")]
		public bool animateAbility = true;

		// combatant
		[ORKEditorHelp("Faction", "Select the faction of the combatant that will use the ability.", "")]
		[ORKEditorInfo(ORKDataType.Faction, separator=true, labelText="Combatant Settings")]
		public int factionID = 0;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public CombatantGroupMember combatantSetting;


		// status effect
		[ORKEditorLayout("type", GridCellEventType.StatusEffect, endCheckGroup=true, autoInit=true)]
		public StatusEffectCast statusEffect;


		// game event
		[ORKEditorHelp("Game Event", "Select the game event asset that will be used.\n" +
			"The combatant will be used as starting object.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", GridCellEventType.GameEvent, endCheckGroup=true,
			setDefault=true, defaultValue=null)]
		public ORKGameEvent gameEvent;

		public GridCellEvent()
		{

		}

		public void StartEvent(BattleGridCellComponent cell, List<Combatant> targets, Notify finishedCallback)
		{
			bool done = false;

			if(GridCellEventType.Ability == this.type)
			{
				Combatant user = this.combatantSetting.Create(new Group(this.factionID));
				user.Abilities.Learn(this.abilityID, this.level, false, false);
				user.SetGameObjectSimple(cell.gameObject);
				user.Battle.StartBattle();

				AbilityShortcut ability = user.Abilities.GetUseable(this.abilityID);
				if(ability != null)
				{
					ability.SetUseLevel(this.level);
					ActiveAbility activeLevel = ability.GetActiveLevel();

					if(activeLevel.targetSettings.CanTargetAny(user, targets))
					{
						if(this.animateAbility)
						{
							done = true;
							AbilityAction action = new AbilityAction(user, ability);

							if(activeLevel.targetSettings.NoneTarget() &&
								activeLevel.targetSettings.noneSelectGridCell)
							{
								action.rayTargetSet = true;
								action.rayPoint = cell.transform.position;
								action.rayObject = cell.gameObject;
								action.target = targets;
							}
							else
							{
								activeLevel.targetSettings.SetTargets(action, user, targets);
							}

							action.finishedCallback = delegate (BaseAction finishedAction)
							{
								if(finishedCallback != null)
								{
									finishedCallback();
								}
							};
							action.PerformAction();
						}
						else if(activeLevel != null)
						{
							activeLevel.targetSettings.CheckTargets(user, ref targets);
							activeLevel.Use(user, targets, ability.Setting, true, ability.Type, null,
								SelectedDataHelper.CreateSelectedData(SelectedDataHelper.Action, ability));
						}
					}
				}
			}
			else if(GridCellEventType.StatusEffect == this.type)
			{
				for(int i = 0; i < targets.Count; i++)
				{
					if(targets[i] != null)
					{
						this.statusEffect.ChangeEffect(targets[i], targets[i], false, null);
					}
				}
			}
			else if(GridCellEventType.GameEvent == this.type)
			{
				if(this.gameEvent != null)
				{
					done = true;
					ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
						this.gameEvent, targets, false, finishedCallback);
				}
			}

			if(!done && finishedCallback != null)
			{
				finishedCallback();
			}
		}
	}
}
