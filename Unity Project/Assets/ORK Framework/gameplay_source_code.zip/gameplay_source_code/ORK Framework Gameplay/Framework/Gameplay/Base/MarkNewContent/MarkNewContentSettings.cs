﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MarkNewContentSettings : BaseData
	{
		[ORKEditorInfo("Default Settings", "The default settings for marking new content.\n" +
			"This can be optionally overridden for different contents.", "",
			endFoldout=true)]
		public MarkNewContent markNewContent = new MarkNewContent();


		// abilities
		[ORKEditorHelp("Override Settings", "Ability content uses custom settings.", "")]
		[ORKEditorInfo("Ability Settings", "Optionally override the default settings for ability content.\n" +
			"For ability content, 'Each Add' refers to each time learning an ability (after removing it), " +
			"'Each Change' refers to increasing an ability's level.", "")]
		public bool ownAbility = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownAbility", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent ability;


		// ability tree
		[ORKEditorHelp("Override Settings", "Ability tree content uses custom settings.", "")]
		[ORKEditorInfo("Ability Tree Settings", "Optionally override the default settings for ability tree content.\n" +
			"For ability tree content, 'Each Add' and 'Each Change' refer to each time adding an ability tree (after removing it)", "")]
		public bool ownAbilityTree = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownAbilityTree", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent abilityTree;


		// AI behaviours
		[ORKEditorHelp("Override Settings", "AI behaviour content uses custom settings.", "")]
		[ORKEditorInfo("AI Behaviour Settings", "Optionally override the default settings for AI behaviour content.\n" +
			"For AI behaviour content, 'Each Add' refers to each time adding a new AI behaviour, " +
			"'Each Change' refers to increasing an AI behaviour's quantity.", "")]
		public bool ownAIBehaviour = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownAIBehaviour", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent aiBehaviour;


		// AI rulesets
		[ORKEditorHelp("Override Settings", "AI ruleset content uses custom settings.", "")]
		[ORKEditorInfo("AI Ruleset Settings", "Optionally override the default settings for AI ruleset content.\n" +
			"For AI ruleset content, 'Each Add' refesr to each time adding a new AI ruleset, " +
			"'Each Change' refers to increasing an AI ruleset's quantity.", "")]
		public bool ownAIRuleset = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownAIRuleset", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent aiRuleset;


		// armors
		[ORKEditorHelp("Override Settings", "Armor content uses custom settings.", "")]
		[ORKEditorInfo("Armor Settings", "Optionally override the default settings for armor content.\n" +
			"For armor content, 'Each Add' refers to each time adding an armor (as a separate item), " +
			"'Each Change' refers to increasing an added armor's quantity.", "")]
		public bool ownArmor = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownArmor", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent armor;


		// bestiary
		[ORKEditorHelp("Override Settings", "Bestiary content uses custom settings.", "")]
		[ORKEditorInfo("Bestiary Settings", "Optionally override the default settings for bestiary content.\n" +
			"For bestiary content, 'Each Add' refers to each time adding a new area to a bestiary entry, " +
			"'Each Change' refers to new area and status information.", "")]
		public bool ownBestiary = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownBestiary", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent bestiary;


		// crafting recipes
		[ORKEditorHelp("Override Settings", "Crafting recipe content uses custom settings.", "")]
		[ORKEditorInfo("Crafting Recipe Settings", "Optionally override the default settings for crafting recipe content.\n" +
			"For crafting recipe content, 'Each Add' refers to each time adding a new crafting recipe, " +
			"'Each Change' refers to increasing a crafting recipe's quantity.", "")]
		public bool ownCraftingRecipe = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCraftingRecipe", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent craftingRecipe;


		// items
		[ORKEditorHelp("Override Settings", "Item content uses custom settings.", "")]
		[ORKEditorInfo("Item Settings", "Optionally override the default settings for item content.\n" +
			"For item content, 'Each Add' refers to each time adding an item (as a separate item), " +
			"'Each Change' refers to increasing an added item's quantity.", "")]
		public bool ownItem = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownItem", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent item;


		// logs
		[ORKEditorHelp("Override Settings", "Log content uses custom settings.", "")]
		[ORKEditorInfo("Log Settings", "Optionally override the default settings for log content.\n" +
			"For log content, 'Each Add' refers to each time adding a log (e.g. after removing it), " +
			"'Each Change' refers to new log texts added to the log.", "")]
		public bool ownLog = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownLog", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent log;


		// quests
		[ORKEditorHelp("Override Settings", "Quest content uses custom settings.", "")]
		[ORKEditorInfo("Quest Settings", "Optionally override the default settings for quest content.\n" +
			"For quest content, 'Each Add' refers to each time adding a quest (e.g. after removing it), " +
			"'Each Change' refers to changing a quest/task status.", "")]
		public bool ownQuest = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownQuest", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent quest;


		// research
		[ORKEditorHelp("Override Settings", "Research tree content uses custom settings.", "")]
		[ORKEditorInfo("Research Tree Settings", "Optionally override the default settings for research tree content.\n" +
			"For research tree content, 'Each Add' refers to each time adding a research tree, " +
			"'Each Change' refers to changes in the state of research tree items.", "")]
		public bool ownResearchTree = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownResearchTree", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent researchTree;


		// weapons
		[ORKEditorHelp("Override Settings", "Weapon content uses custom settings.", "")]
		[ORKEditorInfo("Weapon Settings", "Optionally override the default settings for weapon content.\n" +
			"For weapon content, 'Each Add' refers to each time adding a weapon (as a separate item), " +
			"'Each Change' refers to increasing an added weapon's quantity.", "")]
		public bool ownWeapon = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownWeapon", true, endCheckGroup=true, autoInit=true)]
		public MarkNewContent weapon;

		public MarkNewContentSettings()
		{

		}
	}
}
