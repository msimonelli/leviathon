﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridPath
	{
		private Combatant user;

		private List<BattleGridCellComponent> path;

		private BattleGridCellComponent targetCell;

		private float moveCost;

		private bool ended = false;

		public GridPath(Combatant user, List<BattleGridCellComponent> path, float moveCost)
		{
			this.user = user;
			this.path = path;
			this.moveCost = moveCost;

			if(this.path != null)
			{
				while(this.path.Count > 0 &&
					(!this.path[this.path.Count - 1].IsEmpty ||
					this.path[this.path.Count - 1].IsBlocked))
				{
					this.path.RemoveAt(this.path.Count - 1);
				}
				if(this.path.Count > 0)
				{
					this.targetCell = this.path[this.path.Count - 1];
					this.targetCell.MarkedForCombatant = this.user;
				}
			}
		}

		public void Clear()
		{
			this.path = null;
			if(this.targetCell != null)
			{
				this.targetCell.MarkedForCombatant = null;
				this.targetCell = null;
			}
		}

		public void ConsumeMoveCost()
		{
			this.user.Battle.GridMoveRange -= this.moveCost;
			this.moveCost = 0;
		}

		public void End()
		{
			if(!this.ended)
			{
				this.ended = true;
				if(this.targetCell != null)
				{
					this.user.GridCell = this.targetCell;
				}
				this.ConsumeMoveCost();

				if(this.user.GridCell != null &&
					this.user.GameObject != null)
				{
					this.user.GameObject.transform.position = this.user.GridCell.transform.position;
				}
			}
		}

		public Combatant User
		{
			get { return this.user; }
		}


		/*
		============================================================================
		Path functions
		============================================================================
		*/
		public int GetRemainingPathLength()
		{
			return this.path != null ? this.path.Count : 0;
		}

		public BattleGridCellComponent GetNextPathCell(bool remove)
		{
			if(this.path != null && this.path.Count > 0)
			{
				BattleGridCellComponent cell = this.path[0];
				if(remove)
				{
					this.path.RemoveAt(0);
				}
				return cell;
			}
			return null;
		}

		public BattleGridCellComponent GetLastPathCell(bool remove)
		{
			if(this.path != null && this.path.Count > 0)
			{
				int index = this.path.Count - 1;
				BattleGridCellComponent cell = this.path[index];
				if(remove)
				{
					this.path.RemoveAt(index);
				}
				return cell;
			}
			return null;
		}

		public List<BattleGridCellComponent> GetRemainingPath(bool remove)
		{
			List<BattleGridCellComponent> list = this.path;
			if(remove)
			{
				this.path = null;
			}
			return list;
		}

		public void RemoveCell(GridPathCellSelection selection)
		{
			if(GridPathCellSelection.Next == selection)
			{
				if(this.path != null && this.path.Count > 0)
				{
					this.path.RemoveAt(0);
				}
			}
			else if(GridPathCellSelection.Last == selection)
			{
				if(this.path != null && this.path.Count > 0)
				{
					this.path.RemoveAt(this.path.Count - 1);
				}
			}
			else if(GridPathCellSelection.All == selection)
			{
				this.path = null;
			}
		}

		public bool CheckValidStart()
		{
			bool found = false;
			if(this.path != null && this.path.Count > 0)
			{

				for(int i = 0; i < this.path.Count; i++)
				{
					if(BattleGridHelper.IsNeighbourCell(this.user.GridCell, this.path[i],
						ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove, null))
					{
						found = true;
						break;
					}
					else
					{
						this.path.RemoveAt(i--);
					}
				}
			}

			if(!found)
			{
				this.Clear();
			}

			return found;
		}
	}
}
