
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantAbilities : ISaveData
	{
		private Combatant owner;


		// base attacks
		private AbilityShortcut[] attack;

		private AbilityShortcut counter;

		private List<AbilityShortcut> equipAttack = new List<AbilityShortcut>();

		private AbilityShortcut equipCounter;


		// class ability
		private Dictionary<int, AbilityShortcut> classAbility = new Dictionary<int, AbilityShortcut>();


		// lists
		private List<AbilityShortcut> learned = new List<AbilityShortcut>();

		private List<EquipAbilityShortcut> equip = new List<EquipAbilityShortcut>();

		private List<AbilityShortcut> temporary = new List<AbilityShortcut>();

		private List<AbilityShortcut> passive = new List<AbilityShortcut>();

		private List<AbilityShortcut> both = new List<AbilityShortcut>();

		private List<AbilityShortcut> field = new List<AbilityShortcut>();

		private List<AbilityShortcut> battle = new List<AbilityShortcut>();


		// ability trees
		private List<int> abilityTree = new List<int>();


		// new content
		private bool dataChanged = false;

		private bool treeDataChanged = false;

		private List<int> addedAbilities = new List<int>();

		private List<int> newAbilityTypes = new List<int>();

		private List<int> addedAbilityTrees = new List<int>();

		private List<int> newAbilityTrees = new List<int>();


		// battle
		private int lastAbilityID = -1;

		private int attackIndex = 0;

		private float attackTimeout = -10;

		public CombatantAbilities(Combatant owner)
		{
			this.owner = owner;

			// init base attacks
			this.attack = new AbilityShortcut[this.owner.Setting.baseAttack.Length];
			for(int i = 0; i < this.attack.Length; i++)
			{
				this.attack[i] = this.owner.Setting.baseAttack[i].GetAbility(AbilityActionType.BaseAttack);
				this.attack[i].RegisterStatusChanges(this.owner);
			}

			// init counter attack
			this.counter = this.owner.Setting.counterAttack.GetAbility(AbilityActionType.CounterAttack);
			this.counter.RegisterStatusChanges(this.owner);
		}


		/*
		============================================================================
		Event functions
		============================================================================
		*/
		private CombatantChanged abilitiesChangedHandler;
		public event CombatantChanged AbilitiesChanged
		{
			add { this.abilitiesChangedHandler += value; }
			remove { this.abilitiesChangedHandler -= value; }
		}

		public void FireChanged()
		{
			if(this.abilitiesChangedHandler != null)
			{
				this.abilitiesChangedHandler(this.owner);
			}
		}

		private void AutoAddShortcut(AbilityShortcut ability)
		{
			this.owner.Shortcuts.AutoAdd(this.owner, ability);
			this.owner.Group.Shortcuts.AutoAdd(this.owner, ability);
		}

		public void GroupAbilitiesChanged(Group group)
		{
			if(this.owner.Group == group)
			{
				this.CreateAbilities();
			}
			else
			{
				this.owner.Group.Abilities.Changed -= this.GroupAbilitiesChanged;
			}
		}

		public bool DataChanged
		{
			get { return this.dataChanged; }
			set { this.dataChanged = value; }
		}

		public bool TreeDataChanged
		{
			get { return this.treeDataChanged; }
			set { this.treeDataChanged = value; }
		}

		public void UpdateLists()
		{
			this.newAbilityTypes.Clear();

			this.CheckNewAbilityType(this.both);
			this.CheckNewAbilityType(this.field);
			this.CheckNewAbilityType(this.battle);
			this.CheckNewAbilityType(this.passive);

			this.dataChanged = false;
		}

		private void CheckNewAbilityType(List<AbilityShortcut> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].IsNewContent &&
					!this.newAbilityTypes.Contains(list[i].TypeID))
				{
					this.newAbilityTypes.Add(list[i].TypeID);
				}
			}
		}


		/*
		============================================================================
		Get/set functions
		============================================================================
		*/
		public int LastAbilityID
		{
			get { return this.lastAbilityID; }
			set { this.lastAbilityID = value; }
		}

		public int AttackIndex
		{
			get { return this.attackIndex; }
			set { this.attackIndex = value; }
		}



		/*
		============================================================================
		List functions
		============================================================================
		*/
		private void CheckAddNew(AbilityShortcut ability)
		{
			if(this.addedAbilities.Contains(ability.ID))
			{
				MarkNewContent.Ability.MarkEachAdd(ability);
			}
			else
			{
				this.addedAbilities.Add(ability.ID);
				MarkNewContent.Ability.MarkFirstAdd(ability);
			}
		}

		/// <summary>
		/// Creates the ability lists from learned and equipped abilities.
		/// </summary>
		private void CreateAbilities()
		{
			this.CreateAbilities(out this.both, UseableIn.Both);
			this.CreateAbilities(out this.field, UseableIn.Field);
			this.CreateAbilities(out this.battle, UseableIn.Battle);
			this.CreateAbilities(out this.passive, UseableIn.None);

			this.SetStartEffects();

			// notify
			this.dataChanged = true;
			this.FireChanged();
			this.owner.FireChanged();
		}

		private void CreateAbilities(out List<AbilityShortcut> list, UseableIn useIn)
		{
			list = new List<AbilityShortcut>();
			List<int> added = new List<int>();

			// learned
			for(int i = 0; i < this.learned.Count; i++)
			{
				if(this.learned[i].IsUseable(useIn))
				{
					list.Add(this.learned[i]);
					added.Add(this.learned[i].ID);
				}
			}

			// equipment
			for(int i = 0; i < this.equip.Count; i++)
			{
				if(this.equip[i].IsUseable(useIn))
				{
					if(added.Contains(this.equip[i].ID))
					{
						int k = added.IndexOf(this.equip[i].ID);
						if(list[k].Level < this.equip[i].Level)
						{
							list[k] = this.equip[i];
						}
					}
					else
					{
						list.Add(this.equip[i]);
					}
				}
			}

			// temporary
			for(int i = 0; i < this.temporary.Count; i++)
			{
				if(this.temporary[i].IsUseable(useIn))
				{
					if(added.Contains(this.temporary[i].ID))
					{
						int k = added.IndexOf(this.temporary[i].ID);
						if(list[k].Level < this.temporary[i].Level)
						{
							list[k] = this.temporary[i];
						}
					}
					else
					{
						list.Add(this.temporary[i]);
					}
				}
			}

			// group
			List<AbilityShortcut> groupAbilities = this.owner.Group.Abilities.GetAbilities();
			for(int i = 0; i < groupAbilities.Count; i++)
			{
				if(groupAbilities[i].IsUseable(useIn))
				{
					if(added.Contains(groupAbilities[i].ID))
					{
						int k = added.IndexOf(groupAbilities[i].ID);
						if(list[k].Level < groupAbilities[i].Level)
						{
							list[k] = groupAbilities[i];
						}
					}
					else
					{
						list.Add(groupAbilities[i]);
						added.Add(groupAbilities[i].ID);
					}
				}
			}
		}


		/*
		============================================================================
		Base attack functions
		============================================================================
		*/
		public void ResetEquipmentAttacks()
		{
			this.equipAttack.Clear();
			this.equipCounter = null;

			// base attacks
			for(int i = 0; i < ORK.EquipmentParts.Count; i++)
			{
				if(this.owner.Equipment[i].Equipped &&
					this.owner.Equipment[i].Equipment.IsType(EquipSet.Weapon) &&
					this.owner.Equipment[i].Equipment.GetBaseAttacks(ref this.equipAttack))
				{
					break;
				}
			}

			// counter attacks
			for(int i = 0; i < ORK.EquipmentParts.Count; i++)
			{
				if(this.owner.Equipment[i].Equipped &&
					this.owner.Equipment[i].Equipment.IsType(EquipSet.Weapon))
				{
					this.equipCounter = this.owner.Equipment[i].Equipment.GetCounterAttack();
					if(this.equipCounter != null)
					{
						break;
					}
				}
			}
		}

		/// <summary>
		/// Gets the current base attack ability.
		/// </summary>
		/// <returns>The current base attack as an <c>AbilityShortcut</c>.</returns>
		public AbilityShortcut GetCurrentBaseAttack()
		{
			return this.GetBaseAttack(ref this.attackIndex);
		}

		/// <summary>
		/// Gets the base attack ability.
		/// </summary>
		/// <param name="index">
		/// The index of the base attack.
		/// Will be reset to 0 if outside of available attacks.
		/// </param>
		/// <returns>The base attack's as an <c>AbilityShortcut</c>.</returns>
		public AbilityShortcut GetBaseAttack(int index)
		{
			return this.GetBaseAttack(ref index);
		}

		private AbilityShortcut GetBaseAttack(ref int index)
		{
			// equipment attack
			if(this.equipAttack.Count > 0)
			{
				if(index >= this.equipAttack.Count)
				{
					index = 0;
				}
				if(index >= 0 &&
					index < this.equipAttack.Count)
				{
					return this.equipAttack[index];
				}
			}
			// base attack
			if(index >= this.attack.Length)
			{
				index = 0;
			}
			if(index >= 0 && index < this.attack.Length)
			{
				return this.attack[index];
			}
			return null;
		}

		/// <summary>
		/// Adds all base attacks to the list.
		/// </summary>
		/// <param name="list">
		/// The list the base attacks will be added to.
		/// </param>
		public void GetBaseAttacks(ref List<AbilityShortcut> list)
		{
			// equipment attack
			if(this.equipAttack.Count > 0)
			{
				for(int i = 0; i < this.equipAttack.Count; i++)
				{
					if(!list.Contains(this.equipAttack[i]))
					{
						list.Add(this.equipAttack[i]);
					}
				}
				return;
			}
			// base attack
			for(int i = 0; i < this.attack.Length; i++)
			{
				if(!list.Contains(this.attack[i]))
				{
					list.Add(this.attack[i]);
				}
			}
		}

		public void NextBaseAttack()
		{
			this.attackIndex++;
			// equipment attack
			if(this.equipAttack.Count > 0)
			{
				if(this.attackIndex >= this.equipAttack.Count)
				{
					this.attackIndex = 0;
				}
				if(this.attackIndex >= 0 &&
					this.attackIndex < this.equipAttack.Count)
				{
					float time = this.equipAttack[this.attackIndex].GetAvailableTime();
					if(time > 0)
					{
						this.attackTimeout = time;
					}
					else
					{
						this.attackTimeout = -10;
					}
					return;
				}
			}
			// base attack
			AbilityShortcut attack = this.GetBaseAttack(ref this.attackIndex);
			if(attack != null)
			{
				float time = attack.GetAvailableTime();
				if(time > 0)
				{
					this.attackTimeout = time;
				}
				else
				{
					this.attackTimeout = -10;
				}
			}
		}

		public void ResetBaseAttack()
		{
			this.attackIndex = 0;
			this.attackTimeout = -10;
		}

		public bool InAttackRange(Combatant target)
		{
			AbilityShortcut ab = this.GetCurrentBaseAttack();
			return ab.InRange(this.owner, target);
		}

		public void TickBaseAttackTimeout(float battleTime)
		{
			if(this.owner.Actions.ActionState == CombatantActionState.Available &&
				this.attackTimeout != -10)
			{
				this.attackTimeout -= battleTime;
				if(this.attackTimeout <= 0)
				{
					this.ResetBaseAttack();
				}
			}
		}


		/*
		============================================================================
		Counter attack functions
		============================================================================
		*/
		/// <summary>
		/// Gets the counter attack ability.
		/// </summary>
		/// <returns>
		/// The counter attack's ability.
		/// </returns>
		public AbilityShortcut GetCounterAttack()
		{
			// equipment counter
			if(this.equipCounter != null)
			{
				return this.equipCounter;
			}
			/*for(int i = 0; i < ORK.EquipmentParts.Count; i++)
			{
				if(this.owner.Equipment[i].Equipped)
				{
					AbilityShortcut ability = this.owner.Equipment[i].Equipment.GetCounterAttack();
					if(ability != null)
					{
						return ability;
					}
				}
			}*/
			// base counter
			return this.counter;
		}

		public bool UseCounter(Combatant target)
		{
			if(!this.owner.Dead && ORK.Battle.CanCounter)
			{
				if(ORK.GameSettings.CheckRandom(this.owner.GetCounterChance(target)))
				{
					if(ORK.Battle.IsRealTime())
					{
						this.owner.AI.RealTimeCounterTarget = target;
					}
					else
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Status functions
		============================================================================
		*/
		/// <summary>
		/// Gets the status changes from passive abilities.
		/// </summary>
		/// <param name='status'>
		/// The status value changes (absolute).
		/// </param>
		/// <param name='statusPercent'>
		/// The status value changes (percent).
		/// </param>
		/// <param name='chance'>
		/// The chance changes.
		/// </param>
		/// <param name='atkBonus'>
		/// Attack attribute bonuses.
		/// </param>
		/// <param name='defBonus'>
		/// Defence attribute bonuses.
		/// </param>
		public void GetStatusChanges(ref StatusPreviewInformation info)
		{
			for(int i = 0; i < this.passive.Count; i++)
			{
				this.passive[i].GetPassiveLevel().bonus.GetBonus(ref info);
			}
		}

		/// <summary>
		/// Applies the auto status effects of passive abilities.
		/// </summary>
		public void SetStartEffects()
		{
			for(int i = 0; i < this.passive.Count; i++)
			{
				this.passive[i].SetStartEffects(this.owner);
			}
		}

		/// <summary>
		/// Removes the auto status effects of passive abilities.
		/// </summary>
		public void RemoveStartEffects()
		{
			for(int i = 0; i < this.passive.Count; i++)
			{
				this.passive[i].RemoveStartEffects(this.owner);
			}
		}

		/// <summary>
		/// Checks the passive abilities if a status effect can be applied.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the status effect can be applied; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='effectID'>
		/// The ID (index) of the status effect.
		/// </param>
		public bool CanApplyEffect(int effectID)
		{
			for(int i = 0; i < this.passive.Count; i++)
			{
				if(!this.passive[i].GetPassiveLevel().autoEffects.CanApplyEffect(this.owner, effectID))
				{
					return false;
				}
			}
			return true;
		}

		/// <summary>
		/// Checks the passive abilities if a status effect can be removed.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the status effect can be removed; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='effectID'>
		/// The ID (index) of the status effect
		/// </param>
		public bool CanRemoveEffect(int effectID)
		{
			for(int i = 0; i < this.passive.Count; i++)
			{
				if(!this.passive[i].GetPassiveLevel().autoEffects.CanRemoveEffect(this.owner, effectID))
				{
					return false;
				}
			}
			return true;
		}

		public void UseAttackEffects(Combatant target)
		{
			for(int i = 0; i < this.passive.Count; i++)
			{
				this.passive[i].GetPassiveLevel().autoEffects.UseAttackEffects(this.owner, target);
			}
		}

		public void UseDefenceEffects(Combatant target)
		{
			for(int i = 0; i < this.passive.Count; i++)
			{
				this.passive[i].GetPassiveLevel().autoEffects.UseDefenceEffects(this.owner, target);
			}
		}


		/*
		============================================================================
		Learn functions
		============================================================================
		*/
		/// <summary>
		/// Forgets an ability.
		/// </summary>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='showNotification'>
		/// <c>true</c> to display popup notifications.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to display in the console.
		/// </param>
		public bool Forget(int id, bool showNotification, bool showConsole)
		{
			if(this.HasLearned(id, 0))
			{
				AbilityShortcut ability = this.GetLearned(id);
				if(ability != null)
				{
					this.learned.Remove(ability);
					ability.UnregisterStatusChanges(this.owner);
					this.CreateAbilities();
					this.owner.MarkResetStatus();

					// notification
					if(showNotification)
					{
						if(ability.Setting.ownNotifications)
						{
							ability.Setting.abilityForgotten.Show(this.owner, ability);
						}
						else
						{
							ORK.InventorySettings.notifications.abilityForgotten.Show(this.owner, ability);
						}
					}
					// console
					if(showConsole && ORK.ConsoleSettings.displayForgetting)
					{
						if(ability.Setting.ownConsoleForgetting)
						{
							ability.Setting.consoleForgetting.PrintForgetRange(this.owner, ability);
						}
						else
						{
							ORK.ConsoleSettings.forgetAbility.PrintForgetRange(this.owner, ability);
						}
					}

					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Learns an ability.
		/// </summary>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='level'>
		/// The level that will be learned
		/// </param>
		/// <param name='showNotification'>
		/// <c>true</c> to display popup notifications.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to display in the console.
		/// </param>
		public bool Learn(int id, int level, bool showNotification, bool showConsole)
		{
			if(!this.HasLearned(id, level))
			{
				AbilityShortcut ability = new AbilityShortcut(id, level, AbilityActionType.Ability);
				bool add = true;
				for(int i = 0; i < this.learned.Count; i++)
				{
					if(this.learned[i].ID == id)
					{
						PassiveAbility passiveLevel = this.learned[i].GetPassiveLevel();
						this.learned[i].Level = level;
						this.learned[i].SetUseLevel(level);
						MarkNewContent.Ability.MarkEachChange(this.learned[i]);
						add = false;

						if(passiveLevel != null)
						{
							passiveLevel.autoEffects.RemoveEffects(this.owner, this.learned[i]);
						}

						break;
					}
				}
				if(add)
				{
					this.learned.Add(ability);
					this.CheckAddNew(ability);
					ability.RegisterStatusChanges(this.owner);
				}

				// notification
				if(showNotification)
				{
					if(ability.Setting.ownNotifications)
					{
						ability.Setting.abilityLearned.Show(this.owner, ability);
					}
					else
					{
						ORK.InventorySettings.notifications.abilityLearned.Show(this.owner, ability);
					}
				}
				// console
				if(showConsole && ORK.ConsoleSettings.displayLearning)
				{
					if(ability.Setting.ownConsoleLearning)
					{
						ability.Setting.consoleLearning.PrintLearnRange(this.owner, ability);
					}
					else
					{
						ORK.ConsoleSettings.learnAbility.PrintLearnRange(this.owner, ability);
					}
				}

				this.CreateAbilities();
				this.owner.MarkResetStatus();
				this.AutoAddShortcut(ability);
				return true;
			}
			return false;
		}

		/// <summary>
		/// Learns an ability.
		/// </summary>
		/// <param name='ability'>
		/// The ability that will be learned.
		/// </param>
		/// <param name='showNotification'>
		/// <c>true</c> to display popup notifications.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to display in the console.
		/// </param>
		public bool Learn(AbilityShortcut ability, bool showNotification, bool showConsole)
		{
			if(!this.HasLearned(ability.ID, ability.Level))
			{
				bool add = true;
				for(int i = 0; i < this.learned.Count; i++)
				{
					if(this.learned[i].ID == ability.ID)
					{
						PassiveAbility passiveLevel = this.learned[i].GetPassiveLevel();
						this.learned[i].Level = ability.Level;
						this.learned[i].SetUseLevel(ability.Level);
						MarkNewContent.Ability.MarkEachChange(this.learned[i]);
						add = false;

						if(passiveLevel != null)
						{
							passiveLevel.autoEffects.RemoveEffects(this.owner, this.learned[i]);
						}

						break;
					}
				}
				if(add)
				{
					ability = (AbilityShortcut)ability.GetCopy(0);
					this.learned.Add(ability);
					this.CheckAddNew(ability);
					ability.RegisterStatusChanges(this.owner);
				}

				// notification
				if(showNotification)
				{
					if(ability.Setting.ownNotifications)
					{
						ability.Setting.abilityLearned.Show(this.owner, ability);
					}
					else
					{
						ORK.InventorySettings.notifications.abilityLearned.Show(this.owner, ability);
					}
				}
				// console
				if(showConsole && ORK.ConsoleSettings.displayLearning)
				{
					if(ability.Setting.ownConsoleLearning)
					{
						ability.Setting.consoleLearning.PrintLearnRange(this.owner, ability);
					}
					else
					{
						ORK.ConsoleSettings.learnAbility.PrintLearnRange(this.owner, ability);
					}
				}

				this.CreateAbilities();
				this.owner.MarkResetStatus();
				this.AutoAddShortcut(ability);
				return true;
			}
			return false;
		}


		/*
		============================================================================
		List functions
		============================================================================
		*/
		/// <summary>
		/// Gets a useable ability (not passive), searches in base attacks, counter attack and abilities.
		/// </summary>
		/// <returns>
		/// The ability.
		/// </returns>
		/// <param name='abilityID'>
		/// The ID (index) of the ability.
		/// </param>
		public AbilityShortcut GetUseable(int abilityID)
		{
			for(int i = 0; i < this.attack.Length; i++)
			{
				if(this.attack[i].ID == abilityID)
				{
					return this.attack[i];
				}
			}
			if(this.counter.ID == abilityID)
			{
				return this.counter;
			}
			for(int i = 0; i < this.both.Count; i++)
			{
				if(this.both[i].ID == abilityID)
				{
					return this.both[i];
				}
			}
			return null;
		}

		/// <summary>
		/// Gets a list of abilities useable in a specified mode.
		/// </summary>
		/// <returns>
		/// The ability list.
		/// </returns>
		/// <param name='useIn'>
		/// Either useable in <c>Field</c>, <c>Battle</c>, <c>Both</c> or <c>None</c> (passive abilities).
		/// </param>
		public List<AbilityShortcut> GetAbilities(UseableIn useIn, IncludeCheckType addTemporary)
		{
			if(UseableIn.Field == useIn)
			{
				return this.GetAbilities(this.field, addTemporary);
			}
			else if(UseableIn.Battle == useIn)
			{
				return this.GetAbilities(this.battle, addTemporary);
			}
			else if(UseableIn.Both == useIn)
			{
				return this.GetAbilities(this.both, addTemporary);
			}
			else if(UseableIn.None == useIn)
			{
				return this.GetAbilities(this.passive, addTemporary);
			}
			return new List<AbilityShortcut>();
		}

		private List<AbilityShortcut> GetAbilities(List<AbilityShortcut> abilities, IncludeCheckType addTemporary)
		{
			List<AbilityShortcut> list = new List<AbilityShortcut>();
			for(int i = 0; i < abilities.Count; i++)
			{
				if(IncludeCheckType.Yes == addTemporary ||
					(IncludeCheckType.No == addTemporary && !abilities[i].IsTemporary) ||
					(IncludeCheckType.Only == addTemporary && abilities[i].IsTemporary))
				{
					list.Add(abilities[i]);
				}
			}
			return list;
		}

		/// <summary>
		/// Gets a learned ability.
		/// </summary>
		/// <returns>
		/// The ability if learned, otherwise <c>null</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		public AbilityShortcut GetLearned(int id)
		{
			for(int i = 0; i < this.learned.Count; i++)
			{
				if(this.learned[i].ID == id)
				{
					return this.learned[i];
				}
			}
			return null;
		}

		/// <summary>
		/// Gets a known ability.
		/// </summary>
		/// <returns>
		/// The ability if known, otherwise <c>null</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		public AbilityShortcut Get(int id)
		{
			for(int i = 0; i < this.both.Count; i++)
			{
				if(this.both[i].ID == id)
				{
					return this.both[i];
				}
			}
			for(int i = 0; i < this.passive.Count; i++)
			{
				if(this.passive[i].ID == id)
				{
					return this.passive[i];
				}
			}
			return null;
		}

		/// <summary>
		/// Gets a known ability and tries to set it's use level (only non-passive abilities).
		/// </summary>
		/// <returns>
		/// The ability if known, otherwise <c>null</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='level'>
		/// The level that should be used.
		/// </param>
		public AbilityShortcut Get(int id, int level)
		{
			for(int i = 0; i < this.both.Count; i++)
			{
				if(this.both[i].ID == id)
				{
					this.both[i].SetUseLevel(level);
					return this.both[i];
				}
			}
			for(int i = 0; i < this.passive.Count; i++)
			{
				if(this.passive[i].ID == id)
				{
					return this.passive[i];
				}
			}
			return null;
		}

		/// <summary>
		/// Gets an ability matching a defined ability.
		/// </summary>
		/// <param name='shortcut'>
		/// The AbilityShortcut to look for.
		/// </param>
		public AbilityShortcut Get(AbilityShortcut shortcut)
		{
			if(AbilityActionType.BaseAttack == shortcut.Type)
			{
				for(int i = 0; i < this.attack.Length; i++)
				{
					if(this.attack[i].ID == shortcut.ID &&
						this.attack[i].Level >= shortcut.Level)
					{
						this.attack[i].SetUseLevel(shortcut.Level);
						return this.attack[i];
					}
				}
			}
			else if(AbilityActionType.CounterAttack == shortcut.Type)
			{
				if(this.counter.ID == shortcut.ID &&
					this.counter.Level >= shortcut.Level)
				{
					this.counter.SetUseLevel(shortcut.Level);
					return this.counter;
				}
			}
			else if(AbilityActionType.Ability == shortcut.Type)
			{
				for(int i = 0; i < this.both.Count; i++)
				{
					if(this.both[i].ID == shortcut.ID &&
						this.both[i].Level >= shortcut.Level)
					{
						this.both[i].SetUseLevel(shortcut.Level);
						return this.both[i];
					}
				}
				for(int i = 0; i < this.passive.Count; i++)
				{
					if(this.passive[i].ID == shortcut.ID &&
						this.passive[i].Level >= shortcut.Level)
					{
						this.passive[i].SetUseLevel(shortcut.Level);
						return this.passive[i];
					}
				}
			}
			return null;
		}

		/// <summary>
		/// Gets a list of all available ability types.
		/// </summary>
		/// <returns>
		/// The ability types as a list of integers (IDs of the types).
		/// </returns>
		public List<int> GetTypes(int parentType, bool addAttacks, bool addCounters, bool addClass,
			bool addActive, bool addPassive, IncludeCheckType addTemporary)
		{
			if(this.dataChanged)
			{
				this.UpdateLists();
			}

			List<int> list = new List<int>();

			// base attacks
			if(addAttacks)
			{
				for(int i = 0; i < this.attack.Length; i++)
				{
					ORK.AbilityTypes.Get(this.attack[i].TypeID).AddTypeToList(parentType, ref list);
				}
			}
			// counter attacks
			if(addCounters)
			{
				ORK.AbilityTypes.Get(this.counter.TypeID).AddTypeToList(parentType, ref list);
			}
			// class ability
			if(addClass && this.HasClassAbility())
			{
				ORK.AbilityTypes.Get(this.classAbility[this.owner.ClassID].TypeID).AddTypeToList(parentType, ref list);
			}
			// active abilities
			if(addActive)
			{
				for(int i = 0; i < this.both.Count; i++)
				{
					if(IncludeCheckType.Yes == addTemporary ||
						(IncludeCheckType.No == addTemporary && !this.both[i].IsTemporary) ||
						(IncludeCheckType.Only == addTemporary && this.both[i].IsTemporary))
					{
						ORK.AbilityTypes.Get(this.both[i].TypeID).AddTypeToList(parentType, ref list);
					}
				}
			}
			// passive abilities
			if(addPassive)
			{
				for(int i = 0; i < this.passive.Count; i++)
				{
					if(IncludeCheckType.Yes == addTemporary ||
						(IncludeCheckType.No == addTemporary && !this.passive[i].IsTemporary) ||
						(IncludeCheckType.Only == addTemporary && this.passive[i].IsTemporary))
					{
						ORK.AbilityTypes.Get(this.passive[i].TypeID).AddTypeToList(parentType, ref list);
					}
				}
			}

			return list;
		}

		/// <summary>
		/// Gets a list of all available ability types useable in a specified mode.
		/// </summary>
		/// <returns>
		/// The ability types as a list of integers (IDs of the types).
		/// </returns>
		/// <param name='useIn'>
		/// Either useable in <c>Field</c>, <c>Battle</c>, <c>Both</c> or <c>None</c> (passive abilities).
		/// </param>
		public List<int> GetTypes(UseableIn useIn, IncludeCheckType addTemporary, int parentType)
		{
			List<int> list = new List<int>();
			List<AbilityShortcut> abilities = this.GetAbilities(useIn, addTemporary);
			for(int i = 0; i < abilities.Count; i++)
			{
				ORK.AbilityTypes.Get(abilities[i].TypeID).AddTypeToList(parentType, ref list);
			}
			return list;
		}

		/// <summary>
		/// Gets a list of abilities by ability type.
		/// </summary>
		/// <returns>
		/// The list of abilities.
		/// </returns>
		/// <param name='typeID'>
		/// The ID (index) of the ability type to look for.
		/// </param>
		/// <param name='addAttacks'>
		/// <c>true</c> to add base attack abilities.
		/// </param>
		/// <param name='addCounters'>
		/// <c>true</c> to add counter attack abilities.
		/// </param>
		/// <param name='addClass'>
		/// <c>true</c> to add class abilities.
		/// </param>
		/// <param name='addActive'>
		/// <c>true</c> to add active abilities.
		/// </param>
		/// <param name='addPassive'>
		/// <c>true</c> to add passive abilities.
		/// </param>
		public List<AbilityShortcut> GetByType(bool checkParent, int typeID, bool addAttacks, bool addCounters, bool addClass,
			bool addActive, bool addPassive, IncludeCheckType addTemporary)
		{
			List<AbilityShortcut> list = new List<AbilityShortcut>();
			this.GetByType(checkParent, typeID, addAttacks, addCounters, addClass, addActive, addPassive, addTemporary, ref list);
			return list;
		}

		public void GetByType(bool checkParent, int typeID, bool addAttacks, bool addCounters, bool addClass,
			bool addActive, bool addPassive, IncludeCheckType addTemporary, ref List<AbilityShortcut> list)
		{
			if(this.dataChanged)
			{
				this.UpdateLists();
			}

			// base attacks
			if(addAttacks)
			{
				for(int i = 0; i < this.attack.Length; i++)
				{
					if(typeID < 0 ||
						this.attack[i].TypeID == typeID ||
						(checkParent &&
							ORK.AbilityTypes.Get(this.attack[i].TypeID).IsSubTypeOf(typeID)))
					{
						list.Add(this.attack[i]);
					}
				}
			}
			// counter attacks
			if(addCounters &&
				(typeID < 0 ||
					this.counter.TypeID == typeID ||
					(checkParent &&
						ORK.AbilityTypes.Get(this.counter.TypeID).IsSubTypeOf(typeID))))
			{
				list.Add(this.counter);
			}
			// class ability
			if(addClass &&
				this.HasClassAbility() &&
				(typeID < 0 ||
					this.classAbility[this.owner.ClassID].TypeID == typeID ||
					(checkParent &&
						ORK.AbilityTypes.Get(this.classAbility[this.owner.ClassID].TypeID).IsSubTypeOf(typeID))))
			{
				list.Add(this.classAbility[this.owner.ClassID]);
			}
			// active abilities
			if(addActive)
			{
				for(int i = 0; i < this.both.Count; i++)
				{
					if((typeID < 0 ||
							this.both[i].TypeID == typeID ||
							(checkParent &&
								ORK.AbilityTypes.Get(this.both[i].TypeID).IsSubTypeOf(typeID))) &&
						(IncludeCheckType.Yes == addTemporary ||
							(IncludeCheckType.No == addTemporary && !this.both[i].IsTemporary) ||
							(IncludeCheckType.Only == addTemporary && this.both[i].IsTemporary)))
					{
						list.Add(this.both[i]);
					}
				}
			}
			// passive abilities
			if(addPassive)
			{
				for(int i = 0; i < this.passive.Count; i++)
				{
					if((typeID < 0 ||
							this.passive[i].TypeID == typeID ||
							(checkParent &&
								ORK.AbilityTypes.Get(this.passive[i].TypeID).IsSubTypeOf(typeID))) &&
						(IncludeCheckType.Yes == addTemporary ||
							(IncludeCheckType.No == addTemporary && !this.passive[i].IsTemporary) ||
							(IncludeCheckType.Only == addTemporary && this.passive[i].IsTemporary)))
					{
						list.Add(this.passive[i]);
					}
				}
			}
		}

		/// <summary>
		/// Gets a list of abilities by ability type useable in a specified mode.
		/// </summary>
		/// <returns>
		/// The list of abilities.
		/// </returns>
		/// <param name='typeID'>
		/// The ID (index) of the ability type.
		/// </param>
		/// <param name='useIn'>
		/// Either useable in <c>Field</c>, <c>Battle</c>, <c>Both</c> or <c>None</c> (passive abilities).
		/// </param>
		public List<AbilityShortcut> GetByType(int typeID, UseableIn useIn, IncludeCheckType addTemporary, bool checkParent)
		{
			if(typeID < 0)
			{
				return this.GetAbilities(useIn, addTemporary);
			}
			else
			{
				List<AbilityShortcut> list = new List<AbilityShortcut>();
				List<AbilityShortcut> abilities = this.GetAbilities(useIn, addTemporary);
				for(int i = 0; i < abilities.Count; i++)
				{
					if(abilities[i].TypeID == typeID ||
						(checkParent && ORK.AbilityTypes.Get(abilities[i].TypeID).IsSubTypeOf(typeID)))
					{
						list.Add(abilities[i]);
					}
				}
				return list;
			}
		}

		public bool HasType(int typeID, UseableIn useIn, IncludeCheckType addTemporary)
		{
			List<AbilityShortcut> abilities = this.GetAbilities(useIn, addTemporary);
			for(int i = 0; i < abilities.Count; i++)
			{
				if(typeID == -1 || abilities[i].TypeID == typeID ||
					ORK.AbilityTypes.Get(abilities[i].TypeID).IsSubTypeOf(typeID))
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		/// <summary>
		/// Determines whether the specified ability can receive experience.
		/// The ability has to be a base attack, counter attack or a learned ability to receive experience.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability can receive experience; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='ab'>
		/// The AbilityShortcut representing the ability.
		/// </param>
		public bool CanGetUseExperience(AbilityShortcut ab)
		{
			if(this.counter == ab)
			{
				return true;
			}
			for(int i = 0; i < this.attack.Length; i++)
			{
				if(this.attack[i] == ab)
				{
					return true;
				}
			}
			for(int i = 0; i < this.learned.Count; i++)
			{
				if(this.learned[i] == ab)
				{
					return true;
				}
			}
			for(int i = 0; i < this.equip.Count; i++)
			{
				if(this.equip[i] == ab)
				{
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Determines whether the specified ability has been learned.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability has been learned; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='ab'>
		/// The AbilityShortcut representing the ability.
		/// </param>
		public bool IsLearned(AbilityShortcut ab)
		{
			for(int i = 0; i < this.learned.Count; i++)
			{
				if(this.learned[i] == ab)
				{
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Determines whether the specified ability has been learned.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability has been learned; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='level'>
		/// The minimum level that has to be learned.
		/// </param>
		public bool HasLearned(int id, int level)
		{
			for(int i = 0; i < this.learned.Count; i++)
			{
				if(this.learned[i].ID == id &&
					this.learned[i].Level >= level)
				{
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Determines whether the specified ability is available.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability is available; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='shortcut'>
		/// The AbilityShortcut representing the ability.
		/// </param>
		public bool Has(AbilityShortcut shortcut)
		{
			if(AbilityActionType.BaseAttack == shortcut.Type)
			{
				for(int i = 0; i < this.attack.Length; i++)
				{
					if(this.attack[i].ID == shortcut.ID &&
						this.attack[i].Level >= shortcut.Level)
					{
						return true;
					}
				}
			}
			else if(AbilityActionType.CounterAttack == shortcut.Type)
			{
				return this.counter.ID == shortcut.ID &&
					this.counter.Level >= shortcut.Level;
			}
			else if(AbilityActionType.Ability == shortcut.Type)
			{
				for(int i = 0; i < this.both.Count; i++)
				{
					if(this.both[i].ID == shortcut.ID &&
						this.both[i].Level >= shortcut.Level)
					{
						return true;
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Determines whether the specified ability is available.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability is available; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='level'>
		/// The minimum level that has to be learned.
		/// </param>
		public bool Has(int id, int level)
		{
			for(int i = 0; i < this.both.Count; i++)
			{
				if(this.both[i].ID == id &&
					this.both[i].Level >= level)
				{
					return true;
				}
			}
			for(int i = 0; i < this.passive.Count; i++)
			{
				if(this.passive[i].ID == id &&
					this.passive[i].Level >= level)
				{
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Is <c>true</c> if any active or passive abilities are available.
		/// </summary>
		public bool HasAbilities
		{
			get { return this.both.Count > 0 || this.passive.Count > 0; }
		}

		public bool HasNewTypes(bool checkParent, List<int> types,
			bool addAttacks, bool addCounters, bool addClass,
			bool addActive, bool addPassive, IncludeCheckType addTemporary)
		{
			if(this.dataChanged)
			{
				this.UpdateLists();
			}

			if(this.newAbilityTypes.Count > 0)
			{
				for(int i = 0; i < types.Count; i++)
				{
					if(types[i] >= 0 &&
						this.HasType(checkParent, types[i],
							addAttacks, addCounters, addClass,
							addActive, addPassive, addTemporary, true))
					{
						return true;
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Determines whether the specified ability type is available.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability type is available; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='typeID'>
		/// The ID (index) of the ability type.
		/// </param>
		public bool HasType(bool checkParent, int typeID,
			bool addAttacks, bool addCounters, bool addClass,
			bool addActive, bool addPassive, IncludeCheckType addTemporary, bool checkNewContent)
		{
			if(checkNewContent && this.dataChanged)
			{
				this.UpdateLists();
			}

			List<int> types = new List<int>();
			if(addAttacks)
			{
				for(int i = 0; i < this.attack.Length; i++)
				{
					if(this.CheckType(checkParent, typeID, this.attack[i],
						ref types, addTemporary, checkNewContent))
					{
						return true;
					}
				}
			}
			if(addCounters &&
				this.CheckType(checkParent, typeID, this.counter,
					ref types, IncludeCheckType.Yes, checkNewContent))
			{
				return true;
			}
			if(addClass && this.HasClassAbility() &&
				this.CheckType(checkParent, typeID, this.classAbility[this.owner.ClassID],
					ref types, IncludeCheckType.Yes, checkNewContent))
			{
				return true;
			}
			if(addActive)
			{
				for(int i = 0; i < this.both.Count; i++)
				{
					if(this.CheckType(checkParent, typeID, this.both[i],
						ref types, addTemporary, checkNewContent))
					{
						return true;
					}
				}
			}
			if(addPassive)
			{
				for(int i = 0; i < this.passive.Count; i++)
				{
					if(this.CheckType(checkParent, typeID, this.passive[i],
						ref types, addTemporary, checkNewContent))
					{
						return true;
					}
				}
			}
			return false;
		}

		private bool CheckType(bool checkParent, int typeID, AbilityShortcut ability,
			ref List<int> types, IncludeCheckType addTemporary, bool checkNewContent)
		{
			if((!checkNewContent || ability.IsNewContent) &&
				(IncludeCheckType.Yes == addTemporary ||
					(IncludeCheckType.No == addTemporary && !ability.IsTemporary) ||
					(IncludeCheckType.Only == addTemporary && ability.IsTemporary)))
			{
				if(typeID == -2 || ability.TypeID == typeID)
				{
					return true;
				}
				else if(checkParent)
				{
					if(!types.Contains(ability.TypeID))
					{
						if(ORK.AbilityTypes.Get(ability.TypeID).IsSubTypeOf(typeID))
						{
							return true;
						}
						else
						{
							types.Add(ability.TypeID);
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Temporary ability functions
		============================================================================
		*/
		/// <summary>
		/// Adds a temporary ability. 
		/// If the same ability (ID) is already added as temporary ability, 
		/// the higher level version will be used.
		/// </summary>
		/// <param name="abilityID">The ID of the ability that will be added.</param>
		/// <param name="level">The level of the ability that will be added.</param>
		public void AddTemporaryAbility(int abilityID, int level, EndAfter removeAfter, float time)
		{
			bool found = false;
			for(int i = 0; i < this.temporary.Count; i++)
			{
				if(this.temporary[i].ID == abilityID)
				{
					found = true;
					if(this.temporary[i].Level < level)
					{
						this.temporary[i].Level = level;
						MarkNewContent.Ability.MarkEachChange(this.temporary[i]);
					}
					break;
				}
			}

			if(!found)
			{
				AbilityShortcut ability = new AbilityShortcut(abilityID, level, AbilityActionType.Ability);
				ability.IsTemporary = true;
				this.temporary.Add(ability);
				this.CheckAddNew(ability);
				this.CreateAbilities();
				this.owner.MarkResetStatus();
				this.AutoAddShortcut(ability);
			}

			if(EndAfter.None != removeAfter &&
				time > 0)
			{
				this.owner.Battle.AddAutoRemoveTemporaryAbility(
					new RemoveTemporaryAbility(abilityID, time, removeAfter));
			}
		}

		/// <summary>
		/// Adds a temporary ability. 
		/// If the same ability (ID) is already added as temporary ability, 
		/// the higher level version will be used.
		/// </summary>
		/// <param name="ability">The ability that will be added.</param>
		/// <param name="level">The level of the ability that will be added.</param>
		public void AddTemporaryAbility(AbilityShortcut ability, EndAfter removeAfter, float time)
		{
			bool found = false;
			for(int i = 0; i < this.temporary.Count; i++)
			{
				if(this.temporary[i].ID == ability.ID)
				{
					found = true;
					if(this.temporary[i].Level < ability.Level)
					{
						this.temporary[i].Level = ability.Level;
						MarkNewContent.Ability.MarkEachChange(this.temporary[i]);
					}
					break;
				}
			}

			if(!found)
			{
				ability = (AbilityShortcut)ability.GetCopy(0);
				ability.IsTemporary = true;
				this.temporary.Add(ability);
				this.CheckAddNew(ability);
				this.CreateAbilities();
				this.owner.MarkResetStatus();
			}

			if(EndAfter.None != removeAfter &&
				time > 0)
			{
				this.owner.Battle.AddAutoRemoveTemporaryAbility(
					new RemoveTemporaryAbility(ability.ID, time, removeAfter));
			}
		}

		/// <summary>
		/// Removes a temporary ability.
		/// </summary>
		/// <param name="abilityID">The ID of the ability that will be removed.</param>
		public void RemoveTemporaryAbility(int abilityID)
		{
			for(int i = 0; i < this.temporary.Count; i++)
			{
				if(this.temporary[i].ID == abilityID)
				{
					this.temporary.RemoveAt(i);
					this.CreateAbilities();
					this.owner.MarkResetStatus();
					break;
				}
			}
		}

		/// <summary>
		/// Removes all temporary abilities.
		/// </summary>
		public void ClearTemporaryAbilities()
		{
			this.temporary = new List<AbilityShortcut>();
			this.owner.Battle.ClearAutoRemoveTemporaryAbility();
			this.CreateAbilities();
			this.owner.MarkResetStatus();
		}

		/// <summary>
		/// Determines wheter the specified temporary ability is available.
		/// </summary>
		/// <param name="abilityID">The ID of the ability.</param>
		/// <param name="level">The minimum level of the ability.</param>
		/// <returns></returns>
		public bool HasTemporary(int abilityID, int level)
		{
			for(int i = 0; i < this.temporary.Count; i++)
			{
				if(this.temporary[i].ID == abilityID &&
					this.temporary[i].Level >= level)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Equipment functions
		============================================================================
		*/
		private EquipAbilityShortcut GetEquipmentAbility(EquipmentAbility ea)
		{
			for(int i = 0; i < this.equip.Count; i++)
			{
				if(this.equip[i].EquipmentAbility == ea)
				{
					return this.equip[i];
				}
			}
			return null;
		}

		/// <summary>
		/// Adds an ability that is attached to an equipment.
		/// </summary>
		/// <param name='ea'>
		/// The equipment ability.
		/// </param>
		public void AddEquipmentAbility(EquipShortcut equipment, EquipmentAbility ea, int index)
		{
			if(this.GetEquipmentAbility(ea) == null)
			{
				EquipAbilityShortcut ability = new EquipAbilityShortcut(equipment, ea, index);
				this.equip.Add(ability);
				this.CheckAddNew(ability);
				ability.RegisterStatusChanges(this.owner);
				this.CreateAbilities();
				this.owner.MarkResetStatus();
				this.AutoAddShortcut(ability);
			}
		}

		/// <summary>
		/// Removes an ability that is attached an equipment.
		/// </summary>
		/// <param name='ea'>
		/// The equipment ability.
		/// </param>
		public void RemoveEquipmentAbility(EquipmentAbility ea)
		{
			EquipAbilityShortcut eaShort = this.GetEquipmentAbility(ea);
			if(eaShort != null)
			{
				eaShort.UnregisterStatusChanges(this.owner);
				this.equip.Remove(eaShort);
				this.CreateAbilities();

				if(ORK.Abilities.Get(ea.abilityID).IsUseable(UseableIn.None))
				{
					new AbilityShortcut(ea.abilityID, ea.abilityLevel,
						AbilityActionType.Ability).RemoveStartEffects(this.owner);
				}

				this.owner.MarkResetStatus();
			}
		}

		/// <summary>
		/// Resets all equipment abilities.
		/// All abilities coming from equipments will be removed and the current equipment will be checked for abilities.
		/// </summary>
		public void ResetEquipmentAbilities()
		{
			for(int i = 0; i < this.equip.Count; i++)
			{
				this.equip[i].UnregisterStatusChanges(this.owner);
			}

			this.equip = new List<EquipAbilityShortcut>();
			for(int i = 0; i < ORK.EquipmentParts.Count; i++)
			{
				if(this.owner.Equipment[i].Equipped)
				{
					this.owner.Equipment[i].Equipment.CheckAbilities(this.owner);
				}
			}
			this.CreateAbilities();
		}


		/*
		============================================================================
		Class ability functions
		============================================================================
		*/
		/// <summary>
		/// Checks if the current class of the combatant has a class ability and adds it, if it's not yet added to the combatant.
		/// </summary>
		public void UpdateClassAbility()
		{
			if(!this.classAbility.ContainsKey(this.owner.ClassID))
			{
				Class c = ORK.Classes.Get(this.owner.ClassID);
				if(c.useClassAbility)
				{
					AbilityShortcut ability = c.classAbility.GetAbility(AbilityActionType.Ability);
					this.classAbility.Add(this.owner.ClassID, ability);
					this.CheckAddNew(ability);
				}
			}
		}

		/// <summary>
		/// Determines whether the class ability of the combatant's current class is available.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the class ability is available; otherwise, <c>false</c>.
		/// </returns>
		public bool HasClassAbility()
		{
			return this.classAbility.ContainsKey(this.owner.ClassID) &&
				this.classAbility[this.owner.ClassID] != null;
		}

		/// <summary>
		/// Gets the class ability.
		/// </summary>
		/// <returns>
		/// The class ability (if available); otherwise <c>null</c>.
		/// </returns>
		public AbilityShortcut GetClassAbility()
		{
			if(this.classAbility.ContainsKey(this.owner.ClassID))
			{
				return this.classAbility[this.owner.ClassID];
			}
			return null;
		}


		/*
		============================================================================
		Ability tree functions
		============================================================================
		*/
		/// <summary>
		/// Learns an ability tree.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability tree has been learned; otherwise <c>false</c>.
		/// </returns>
		/// <param name='abilityTreeID'>
		/// The ID (index) of the ability tree.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to show learning the ability tree in the console.
		/// </param>
		public bool LearnTree(int abilityTreeID, bool showConsole)
		{
			if(!this.abilityTree.Contains(abilityTreeID))
			{
				this.abilityTree.Add(abilityTreeID);
				if(this.addedAbilityTrees.Contains(abilityTreeID))
				{
					if(MarkNewContent.AbilityTree.IsMarkEachAdd)
					{
						this.newAbilityTrees.Add(abilityTreeID);
						this.treeDataChanged = true;
					}
				}
				else
				{
					this.addedAbilityTrees.Add(abilityTreeID);
					if(MarkNewContent.AbilityTree.IsMarkFirstAdd)
					{
						this.newAbilityTrees.Add(abilityTreeID);
						this.treeDataChanged = true;
					}
				}

				if(showConsole && ORK.ConsoleSettings.displayLearning)
				{
					AbilityTree tree = ORK.AbilityTrees.Get(abilityTreeID);
					if(tree.ownConsoleLearning)
					{
						tree.consoleLearning.PrintLearnRange(this.owner, tree);
					}
					else
					{
						ORK.ConsoleSettings.learnAbilityTree.PrintLearnRange(this.owner, tree);
					}
				}

				this.FireChanged();
				this.owner.FireChanged();
				return true;
			}
			return false;
		}

		/// <summary>
		/// Forgets an ability tree.
		/// </summary>
		/// <param name='abilityTreeID'>
		/// The ID (index) of the ability tree.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to show learning the ability tree in the console.
		/// </param>
		public void ForgetTree(int abilityTreeID, bool showConsole)
		{
			if(this.abilityTree.Contains(abilityTreeID))
			{
				this.abilityTree.Remove(abilityTreeID);
				if(this.newAbilityTrees.Contains(abilityTreeID))
				{
					this.newAbilityTrees.Remove(abilityTreeID);
					this.treeDataChanged = true;
				}

				if(showConsole && ORK.ConsoleSettings.displayForgetting)
				{
					AbilityTree tree = ORK.AbilityTrees.Get(abilityTreeID);
					if(tree.ownConsoleForgetting)
					{
						tree.consoleForgetting.PrintForgetRange(this.owner, tree);
					}
					else
					{
						ORK.ConsoleSettings.forgetAbilityTree.PrintForgetRange(this.owner, tree);
					}
				}
				this.FireChanged();
				this.owner.FireChanged();
			}
		}

		/// <summary>
		/// Is <c>true</c> if any ability trees are available.
		/// </summary>
		public bool HasTrees
		{
			get { return this.abilityTree.Count > 0; }
		}

		/// <summary>
		/// Determines whether the combatant has learned an ability tree.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability tree has been learned; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='abilityTreeID'>
		/// The ID (index) of the ability tree.
		/// </param>
		public bool HasTree(bool checkParent, int abilityTreeID, bool checkNewContent)
		{
			if(checkNewContent)
			{
				this.treeDataChanged = false;
			}
			return this.CheckTree(checkParent, abilityTreeID,
				checkNewContent ? this.newAbilityTrees : this.abilityTree);
		}

		private bool CheckTree(bool checkParent, int abilityTreeID, List<int> list)
		{
			List<int> trees = new List<int>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] == abilityTreeID)
				{
					return true;
				}
				else if(checkParent)
				{
					if(!trees.Contains(list[i]))
					{
						if(ORK.AbilityTrees.Get(list[i]).IsSubTreeOf(abilityTreeID))
						{
							return true;
						}
						else
						{
							trees.Add(list[i]);
						}
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Gets a list of learned ability trees.
		/// </summary>
		/// <returns>
		/// The list of ability trees.
		/// The ability trees are represented by their ID (index).
		/// </returns>
		public List<int> GetTrees(int parentTree)
		{
			List<int> list = new List<int>();

			for(int i = 0; i < this.abilityTree.Count; i++)
			{
				ORK.AbilityTrees.Get(this.abilityTree[i]).AddTreeToList(parentTree, ref list);
			}

			return list;
		}

		public bool UnmarkNewTree(int treeID)
		{
			if(this.newAbilityTrees.Contains(treeID))
			{
				this.newAbilityTrees.Remove(treeID);
				this.treeDataChanged = true;
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			if(this.counter != null)
			{
				data.Set("counter", this.counter.SaveGame());
			}

			DataObject[] tmp = new DataObject[this.attack.Length];
			for(int i = 0; i < tmp.Length; i++)
			{
				tmp[i] = this.attack[i].SaveGame();
			}
			data.Set("attack", tmp);

			DataObject cab = new DataObject();
			foreach(KeyValuePair<int, AbilityShortcut> pair in this.classAbility)
			{
				cab.Set(pair.Key.ToString(), pair.Value.SaveGame());
			}
			data.Set("cab", cab);

			tmp = new DataObject[this.learned.Count];
			for(int i = 0; i < tmp.Length; i++)
			{
				tmp[i] = this.learned[i].SaveGame();
			}
			data.Set("learned", tmp);

			tmp = new DataObject[this.temporary.Count];
			for(int i = 0; i < tmp.Length; i++)
			{
				tmp[i] = this.temporary[i].SaveGame();
			}
			data.Set("temporary", tmp);

			data.Set("abilityTree", this.abilityTree.ToArray());

			if(this.addedAbilities.Count > 0)
			{
				data.Set("addedAbilities", this.addedAbilities.ToArray());
			}

			if(this.addedAbilityTrees.Count > 0)
			{
				data.Set("addedAbilityTrees", this.addedAbilityTrees.ToArray());
			}

			if(this.newAbilityTrees.Count > 0)
			{
				data.Set("newAbilityTrees", this.newAbilityTrees.ToArray());
			}

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				int[] tmp = null;
				data.Get("addedAbilities", out tmp);
				if(tmp != null &&
					tmp.Length > 0)
				{
					this.addedAbilities.AddRange(tmp);
				}

				tmp = null;
				data.Get("addedAbilityTrees", out tmp);
				if(tmp != null &&
					tmp.Length > 0)
				{
					this.addedAbilityTrees.AddRange(tmp);
				}

				tmp = null;
				data.Get("newAbilityTrees", out tmp);
				if(tmp != null &&
					tmp.Length > 0)
				{
					this.newAbilityTrees.AddRange(tmp);
				}

				DataObject counterData = data.GetFile("counter");
				if(counterData != null)
				{
					this.counter = new AbilityShortcut();
					this.counter.LoadGame(counterData);
					this.counter.RegisterStatusChanges(this.owner);
				}

				DataObject[] tmpData = data.GetFileArray("attack");
				if(tmpData != null)
				{
					this.attack = new AbilityShortcut[tmpData.Length];
					for(int i = 0; i < tmpData.Length; i++)
					{
						this.attack[i] = new AbilityShortcut();
						this.attack[i].LoadGame(tmpData[i]);
						this.attack[i].RegisterStatusChanges(this.owner);
					}
				}

				DataObject cab = data.GetFile("cab");
				if(cab != null)
				{
					Dictionary<string, AbilityShortcut> list = cab.GetData<AbilityShortcut>(typeof(AbilityShortcut));
					if(list != null && list.Count > 0)
					{
						foreach(KeyValuePair<string, AbilityShortcut> pair in list)
						{
							int classID = int.Parse(pair.Key);
							if(classID >= 0 &&
								classID < ORK.Classes.Count)
							{
								this.classAbility.Add(classID, pair.Value);
							}
						}
					}
				}

				this.learned.Clear();
				tmpData = data.GetFileArray("learned");
				if(tmpData != null)
				{
					for(int i = 0; i < tmpData.Length; i++)
					{
						AbilityShortcut shortcut = new AbilityShortcut();
						shortcut.LoadGame(tmpData[i]);
						if(shortcut.ID >= 0 &&
							shortcut.ID < ORK.Abilities.Count)
						{
							this.learned.Add(shortcut);
							shortcut.RegisterStatusChanges(this.owner);
						}
					}
				}

				this.temporary.Clear();
				tmpData = data.GetFileArray("temporary");
				if(tmpData != null)
				{
					for(int i = 0; i < tmpData.Length; i++)
					{
						AbilityShortcut shortcut = new AbilityShortcut();
						shortcut.LoadGame(tmpData[i]);
						shortcut.IsTemporary = true;
						if(shortcut.ID >= 0 &&
							shortcut.ID < ORK.Abilities.Count)
						{
							this.temporary.Add(shortcut);
						}
					}
				}

				this.abilityTree.Clear();
				int[] tmp3;
				data.Get("abilityTree", out tmp3);
				if(tmp3 != null)
				{
					for(int i = 0; i < tmp3.Length; i++)
					{
						if(tmp3[i] >= 0 &&
							tmp3[i] < ORK.AbilityTrees.Count)
						{
							this.abilityTree.Add(tmp3[i]);
						}
					}
				}

				this.dataChanged = true;
			}
		}
	}
}
