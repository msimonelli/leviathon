
namespace ORKFramework
{
	public class BattleAdvantage : BaseData
	{
		[ORKEditorHelp("Enabled", "The advantage is enabled and will happen in battles.", "")]
		public bool enabled = false;
		
		[ORKEditorHelp("Chance (%)", "The chance the advantage will happen at the start of a battle.\n" +
			"The advantage is given if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) " +
			"is less or equal to chance defined here.", "")]
		[ORKEditorLayout("enabled", true)]
		public float chance = 0;
		
		[ORKEditorHelp("Block Escape", "The escape action is blocked in the battle.", "")]
		public bool blockEscape = false;
		
		
		// group conditions
		[ORKEditorInfo(separator=true, labelText="Player Group Advantage", 
			beginBox=true, endBox=true)]
		public GroupAdvantage playerGroupCondition = new GroupAdvantage();
		
		[ORKEditorInfo(separator=true, labelText="Enemy Group Advantage", 
			beginBox=true, endBox=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public GroupAdvantage enemyGroupCondition = new GroupAdvantage();
		
		public BattleAdvantage()
		{
			
		}
	}
}
