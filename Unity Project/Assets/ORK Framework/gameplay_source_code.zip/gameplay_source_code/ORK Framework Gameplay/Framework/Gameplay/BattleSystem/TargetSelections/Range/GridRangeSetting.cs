﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridRangeSetting : BaseData
	{
		[ORKEditorHelp("Shape Type", "Select the type of this grid shape:\n" +
			"- None: Uses the range settings (i.e. no special grid handling).\n" +
			"- All: Uses the whole grid.\n" +
			"- Range: All cells within a defined range of the origin cell.\n" +
			"- Mask: Only defined cells around the origin cell.\n" +
			"- Ring: All cells on a ring with a defined range (radius) around the origin cell.", "")]
		public GridShapeType gridShapeType = GridShapeType.None;

		[ORKEditorHelp("Range (Cells)", "The range around the origin cell in cells.\n" +
			"This defines the available cells for selection when using 'Mask' type.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout(new string[] { "gridShapeType", "gridShapeType", "gridShapeType" },
			new System.Object[] { GridShapeType.Range, GridShapeType.Mask, GridShapeType.Ring },
			needed=Needed.One, endCheckGroup=true)]
		public int gridRange = 1;


		// cell settings
		[ORKEditorHelp("Add Origin Cell", "The origin cell will also be used by this shape.\n" +
			"If disabled, only the cells around the origin cell will be used.", "")]
		[ORKEditorLayout("gridShapeType", GridShapeType.Range, endCheckGroup=true)]
		public bool addOriginCell = true;

		[ORKEditorHelp("Add Blocked Cells", "Blocked cells will be selected by this shape.\n" +
			"If disabled, blocked cells will be omitted.", "")]
		[ORKEditorLayout("gridShapeType", GridShapeType.None, elseCheckGroup=true)]
		public bool addBlockedCells = false;

		[ORKEditorHelp("Add Not Passable Cells", "Blocked cells that are not passable will be selected by this shape.\n" +
			"If disabled, blocked cells that aren't passable will be omitted.", "")]
		[ORKEditorLayout("addBlockedCells", true, endCheckGroup=true, endGroups=2)]
		public bool addNotPassableCells = false;

		[ORKEditorHelp("Local Space", "The shape will be rotated in the local space of the combatant using it.\n" +
			"If disabled, the shape is rotated in world space.", "")]
		[ORKEditorLayout("gridShapeType", GridShapeType.Mask, endCheckGroup=true)]
		public bool shapeLocalSpace = false;


		// line of sight
		[ORKEditorHelp("Use Line of Sight", "Use a line of sight between the center of the origin cell " +
			"and the center of the used cells to determine if they're available.", "")]
		[ORKEditorInfo(separator=true, labelText="Line of Sight")]
		public bool useLineOfSight = false;

		[ORKEditorLayout("useLineOfSight", true, endCheckGroup=true)]
		public GridLineOfSight lineOfSight = new GridLineOfSight();


		// shape mask
		[ORKEditorInfo(hide=true, instanceCallback="editor:GridShapeMask")]
		[ORKEditorLayout("gridShapeType", GridShapeType.Mask, endCheckGroup=true,
			setDefault=true, defaultValue=null)]
		public GridShapeMask gridShapeMask;

		public GridRangeSetting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("losBlockedCells"))
			{
				this.lineOfSight.SetData(data);
			}
		}


		/*
		============================================================================
		Cell functions
		============================================================================
		*/
		public void GetCells(BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list, GridCellCheck check)
		{
			if(origin != null)
			{
				if(GridShapeType.All == this.gridShapeType)
				{
					if(origin.parentGrid != null &&
						origin.parentGrid.cellRow != null)
					{
						for(int i = 0; i < origin.parentGrid.cellRow.Length; i++)
						{
							for(int j = 0; j < origin.parentGrid.cellRow[i].cell.Length; j++)
							{
								if(origin.parentGrid.cellRow[i].cell[j] != null &&
									(this.addOriginCell || origin != origin.parentGrid.cellRow[i].cell[j]) &&
									(this.addBlockedCells || !origin.parentGrid.cellRow[i].cell[j].IsBlocked) &&
									(this.addNotPassableCells || origin.parentGrid.cellRow[i].cell[j].IsPassable) &&
									(check == null || check(origin.parentGrid.cellRow[i].cell[j])) &&
									!list.Contains(origin.parentGrid.cellRow[i].cell[j]) &&
									(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin,
										origin.parentGrid.cellRow[i].cell[j],
										this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea)))
								{
									list.Add(origin.parentGrid.cellRow[i].cell[j]);
								}
							}
						}
					}
				}
				else if(GridShapeType.Range == this.gridShapeType)
				{
					BattleGridHelper.GetRange(origin, this.gridRange, ref list,
						this.addOriginCell, this.addBlockedCells, this.addNotPassableCells, check);
					if(this.useLineOfSight)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(!BattleGridHelper.CheckLineOfSight(origin,
								list[i], this.lineOfSight.BlocksLineOfSight,
								this.lineOfSight.visibleCellArea))
							{
								list.RemoveAt(i--);
							}
						}
					}
				}
				else if(GridShapeType.Mask == this.gridShapeType)
				{
					if(this.gridShapeMask != null &&
						this.gridShapeMask.cell != null)
					{
						if(this.shapeLocalSpace &&
							origin.Combatant != null)
						{
							int turns = BattleGridHelper.GetCombatantDirection(origin.Combatant);
							for(int i = 0; i < this.gridShapeMask.cell.Length; i++)
							{
								if(this.gridShapeMask.cell[i] != null &&
									this.gridShapeMask.cell[i].selected)
								{
									BattleGridCellComponent cell = origin.parentGrid.GetCell(
										origin.CubeCoord + this.gridShapeMask.cell[i].coord.Rotate(turns));
									if(cell != null &&
										(this.addOriginCell || origin != cell) &&
										(this.addBlockedCells || !cell.IsBlocked) &&
										(this.addNotPassableCells || cell.IsPassable) &&
										(check == null || check(cell)) &&
										!list.Contains(cell) &&
										(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin, cell,
											this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea)))
									{
										list.Add(cell);
									}
								}
							}
						}
						else
						{
							for(int i = 0; i < this.gridShapeMask.cell.Length; i++)
							{
								if(this.gridShapeMask.cell[i] != null &&
									this.gridShapeMask.cell[i].selected)
								{
									BattleGridCellComponent cell = origin.parentGrid.GetCell(
										origin.CubeCoord + this.gridShapeMask.cell[i].coord);
									if(cell != null &&
										(this.addOriginCell || origin != cell) &&
										(this.addBlockedCells || !cell.IsBlocked) &&
										(this.addNotPassableCells || cell.IsPassable) &&
										(check == null || check(cell)) &&
										!list.Contains(cell) &&
										(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin, cell,
											this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea)))
									{
										list.Add(cell);
									}
								}
							}
						}
					}
				}
				else if(GridShapeType.Ring == this.gridShapeType)
				{
					BattleGridHelper.GetRing(origin, this.gridRange, ref list,
						this.addOriginCell, this.addBlockedCells, this.addNotPassableCells, check);
					if(this.useLineOfSight)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(!BattleGridHelper.CheckLineOfSight(origin, list[i],
								this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea))
							{
								list.RemoveAt(i--);
							}
						}
					}
				}
			}
		}

		public void GetCellCombatants(BattleGridCellComponent origin,
			ref List<Combatant> list, GridCellCheck check)
		{
			if(origin != null)
			{
				if(GridShapeType.All == this.gridShapeType)
				{
					if(origin.parentGrid != null &&
						origin.parentGrid.cellRow != null)
					{
						for(int i = 0; i < origin.parentGrid.cellRow.Length; i++)
						{
							for(int j = 0; j < origin.parentGrid.cellRow[i].cell.Length; j++)
							{
								if(origin.parentGrid.cellRow[i].cell[j] != null &&
									!origin.parentGrid.cellRow[i].cell[j].IsEmpty &&
									(this.addOriginCell || origin != origin.parentGrid.cellRow[i].cell[j]) &&
									(this.addBlockedCells || !origin.parentGrid.cellRow[i].cell[j].IsBlocked) &&
									(this.addNotPassableCells || origin.parentGrid.cellRow[i].cell[j].IsPassable) &&
									(check == null || check(origin.parentGrid.cellRow[i].cell[j])) &&
									(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin,
										origin.parentGrid.cellRow[i].cell[j],
										this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea)))
								{
									origin.parentGrid.cellRow[i].cell[j].GetCombatants(ref list, null);
								}
							}
						}
					}
				}
				else if(GridShapeType.Range == this.gridShapeType)
				{
					BattleGridHelper.GetRangeCombatants(origin, this.gridRange, ref list,
						this.addOriginCell, this.addBlockedCells, this.addNotPassableCells, check);
					if(this.useLineOfSight)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(!BattleGridHelper.CheckLineOfSight(origin, list[i].GridCell,
								this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea))
							{
								list.RemoveAt(i--);
							}
						}
					}
				}
				else if(GridShapeType.Mask == this.gridShapeType)
				{
					if(this.gridShapeMask != null &&
						this.gridShapeMask.cell != null)
					{
						if(this.shapeLocalSpace &&
							origin.Combatant != null)
						{
							int turns = BattleGridHelper.GetCombatantDirection(origin.Combatant);
							for(int i = 0; i < this.gridShapeMask.cell.Length; i++)
							{
								if(this.gridShapeMask.cell[i] != null &&
									this.gridShapeMask.cell[i].selected)
								{
									BattleGridCellComponent cell = origin.parentGrid.GetCell(
										origin.CubeCoord + this.gridShapeMask.cell[i].coord.Rotate(turns));
									if(cell != null && !cell.IsEmpty &&
										(this.addOriginCell || origin != cell) &&
										(this.addBlockedCells || !cell.IsBlocked) &&
										(this.addNotPassableCells || cell.IsPassable) &&
										(check == null || check(cell)) &&
										(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin, cell,
											this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea)))
									{
										cell.GetCombatants(ref list, null);
									}
								}
							}
						}
						else
						{
							for(int i = 0; i < this.gridShapeMask.cell.Length; i++)
							{
								if(this.gridShapeMask.cell[i] != null &&
									this.gridShapeMask.cell[i].selected)
								{
									BattleGridCellComponent cell = origin.parentGrid.GetCell(
										origin.CubeCoord + this.gridShapeMask.cell[i].coord);
									if(cell != null && !cell.IsEmpty &&
										(this.addOriginCell || origin != cell) &&
										(this.addBlockedCells || !cell.IsBlocked) &&
										(this.addNotPassableCells || cell.IsPassable) &&
										(check == null || check(cell)) &&
										(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin, cell,
											this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea)))
									{
										cell.GetCombatants(ref list, null);
									}
								}
							}
						}
					}
				}
				else if(GridShapeType.Ring == this.gridShapeType)
				{
					BattleGridHelper.GetRingCombatants(origin, this.gridRange, ref list,
						this.addOriginCell, this.addBlockedCells, this.addNotPassableCells, check);
					if(this.useLineOfSight)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(!BattleGridHelper.CheckLineOfSight(origin, list[i].GridCell,
								this.lineOfSight.BlocksLineOfSight, this.lineOfSight.visibleCellArea))
							{
								list.RemoveAt(i--);
							}
						}
					}
				}
			}
		}
	}
}
