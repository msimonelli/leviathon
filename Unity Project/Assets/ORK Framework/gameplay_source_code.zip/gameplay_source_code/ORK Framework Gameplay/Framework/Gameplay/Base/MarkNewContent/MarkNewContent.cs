﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MarkNewContent : BaseData
	{
		[ORKEditorHelp("Mark New Data", "Select if and when new data will be marked:\n" +
			"- None: Doesn't mark new data.\n" +
			"- First Add: Only the first time adding the data.\n" +
			"- Each Add: Each time when adding the data.\n" +
			"- Each Change: Each time the data is changed.", "")]
		public MarkNewContentType markType = MarkNewContentType.None;

		[ORKEditorHelp("Unmark New Data", "Select if and when new data will be marked as seen (i.e. removing new data mark):\n" +
			"- None: Doesn't unmark new data.\n" +
			"- View: When viewing the data (e.g. in a menu list).\n" +
			"- Selection: When selecting the data (e.g. selecting/highlighting the choice in a menu).", "")]
		public UnmarkNewContentType unmarkType = UnmarkNewContentType.None;

		public MarkNewContent()
		{

		}

		/*
		============================================================================
		Mark functions
		============================================================================
		*/
		public bool IsMarkFirstAdd
		{
			get { return MarkNewContentType.None != this.markType; }
		}

		public bool IsMarkEachAdd
		{
			get
			{
				return MarkNewContentType.EachAdd == this.markType ||
					MarkNewContentType.EachChange == this.markType;
			}
		}

		public bool IsMarkEachChange
		{
			get { return MarkNewContentType.EachChange == this.markType; }
		}

		public bool MarkFirstAdd(IMarkNewContent content)
		{
			if(this.IsMarkFirstAdd)
			{
				content.IsNewContent = true;
				return true;
			}
			return false;
		}

		public bool MarkEachAdd(IMarkNewContent content)
		{
			if(this.IsMarkEachAdd)
			{
				content.IsNewContent = true;
				return true;
			}
			return false;
		}

		public bool MarkEachChange(IMarkNewContent content)
		{
			if(this.IsMarkEachChange)
			{
				content.IsNewContent = true;
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Unmark functions
		============================================================================
		*/
		public bool IsUnmarkView
		{
			get { return UnmarkNewContentType.View == this.unmarkType; }
		}

		public bool IsUnmarkSelection
		{
			get { return UnmarkNewContentType.Selection == this.unmarkType; }
		}

		public bool UnmarkView(IMarkNewContent content, int unmarkID)
		{
			if(content.IsNewContent &&
				this.IsUnmarkView)
			{
				content.UnmarkID(unmarkID);
				content.IsNewContent = false;
				return true;
			}
			return false;
		}

		public bool UnmarkSelection(IMarkNewContent content, int unmarkID)
		{
			if(content.IsNewContent &&
				this.IsUnmarkSelection)
			{
				content.UnmarkID(unmarkID);
				content.IsNewContent = false;
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Setting getters
		============================================================================
		*/
		public static MarkNewContent Ability
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownAbility)
				{
					return ORK.InventorySettings.markNewContent.ability;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent AbilityTree
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownAbilityTree)
				{
					return ORK.InventorySettings.markNewContent.abilityTree;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent AIBehaviour
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownAIBehaviour)
				{
					return ORK.InventorySettings.markNewContent.aiBehaviour;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent AIRuleset
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownAIRuleset)
				{
					return ORK.InventorySettings.markNewContent.aiRuleset;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Armor
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownArmor)
				{
					return ORK.InventorySettings.markNewContent.armor;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Bestiary
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownBestiary)
				{
					return ORK.InventorySettings.markNewContent.bestiary;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent CraftingRecipe
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownCraftingRecipe)
				{
					return ORK.InventorySettings.markNewContent.craftingRecipe;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Item
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownItem)
				{
					return ORK.InventorySettings.markNewContent.item;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Logs
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownLog)
				{
					return ORK.InventorySettings.markNewContent.log;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Quests
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownQuest)
				{
					return ORK.InventorySettings.markNewContent.quest;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent ResearchTree
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownResearchTree)
				{
					return ORK.InventorySettings.markNewContent.researchTree;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Weapon
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownWeapon)
				{
					return ORK.InventorySettings.markNewContent.weapon;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}
	}
}
