
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BestiarySettings : BaseData
	{
		// base settings
		[ORKEditorHelp("Use Bestiary", "The bestiary is used.\n" +
			"Information on enemies is learned by encountering them.", "")]
		public bool useBestiary = false;

		[ORKEditorHelp("Level/Class Separation", "Encountering the same combatant with different " +
			"classes and levels will add entries for each level/class combination separately.\n" +
			"If disabled, encountering a combatant once will create an entry for all levels. " +
			"Menu screens will display information for the default level/class settings.", "")]
		[ORKEditorLayout("useBestiary", true)]
		public bool separation = false;

		[ORKEditorHelp("Use in Battle AI", "Combatants of the player group will use bestiary " +
			"when checking status information in battle AIs.\n" +
			"I.e. if an information of a combatant isn't in the bestiary, it can't be checked by the AI.", "")]
		public bool useInBattleAI = false;


		// status values
		[ORKEditorHelp("Status Values", "Select how status values are learned:\n" +
			"- None: They aren't learned automatically.\n" +
			"- Encounter: They are learned when encountering a combatant.\n" +
			"- Attack: They are learned when attacking a combatant.\n" +
			"- Attacked By: They are learned when a player group member is attacked by a combatant.\n" +
			"- Death: They are learned when the combatant has been killed.\n" +
			"All status values are learned at the same time.", "")]
		[ORKEditorInfo("Status Value Settings", "Define how status values are learned and unknown values are displayed.", "")]
		public BestiaryLearnType statusValues = BestiaryLearnType.Encounter;

		[ORKEditorHelp("No Value Bars", "Unknown status values wont display value bars.\n" +
			"If disabled, the value bars will also be displayed for unknown status values.", "")]
		[ORKEditorInfo(separator=true)]
		public bool noStatusValueBars = false;

		[ORKEditorHelp("Unknown Value", "The text used to display the value of an unknown status value.\n" +
			"Note that this text will only replace the value, not any other information of the status value.", "")]
		[ORKEditorInfo(endFoldout=true, expandWidth=true, separator=true, labelText="Unknown Value Text")]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] statusValueText = ArrayHelper.CreateArray(ORK.Languages.Count, "???");


		// status values
		[ORKEditorHelp("Equipment", "Select how equipped weapons and armors are learned:\n" +
			"- None: They aren't learned automatically.\n" +
			"- Encounter: They are learned when encountering a combatant.\n" +
			"- Attack: They are learned when attacking a combatant.\n" +
			"- Attacked By: They are learned when a player group member is attacked by a combatant.\n" +
			"- Death: They are learned when the combatant has been killed.\n" +
			"All equipment is learned at the same time.", "")]
		[ORKEditorInfo("Equipment Settings", "Define how equipped weapons and armors are learned and unknown equipment is displayed.", "")]
		public BestiaryLearnType equipment = BestiaryLearnType.Encounter;

		[ORKEditorHelp("Unknown Equipment", "The text used to display the unknown equipment of a combatant.\n" +
			"Note that this text will only replace the name of the equipment, " +
			"other information (e.g. icons) will be ignored when displayed.", "")]
		[ORKEditorInfo(endFoldout=true, expandWidth=true, separator=true, labelText="Unknown Equipment Text")]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] equipmentText = ArrayHelper.CreateArray(ORK.Languages.Count, "???");


		// attack attributes
		[ORKEditorHelp("Attack Attributes", "Select how attack attribute values are learned:\n" +
			"- None: They aren't learned automatically.\n" +
			"- Encounter: They are learned when encountering a combatant (all attributes).\n" +
			"- Attack: They are learned when attacking a combatant with the different attributes (single attribute).\n" +
			"- Attacked By: They are learned when a player group member is attacked by a combatant (all attributes).\n" +
			"- Death: They are learned when the combatant has been killed (all attributes).", "")]
		[ORKEditorInfo("Attack Attribute Settings", "Define how attack attributes are learned and unknown values are displayed.", "")]
		public BestiaryLearnType attackAttributes = BestiaryLearnType.Attack;

		[ORKEditorHelp("Unknown Value", "The text used to display the value of an unknown attack attribute.\n" +
			"Note that this text will only replace the value, not any other information of the attack attribute.", "")]
		[ORKEditorInfo(endFoldout=true, expandWidth=true, separator=true, labelText="Unknown Value Text")]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] attackAttributeText = ArrayHelper.CreateArray(ORK.Languages.Count, "???");


		// defence attributes
		[ORKEditorHelp("Defence Attributes", "Select how defence attribute values are learned:\n" +
			"- None: They aren't learned automatically.\n" +
			"- Encounter: They are learned when encountering a combatant (all attributes).\n" +
			"- Attack: They are learned when attacking a combatant (all attributes).\n" +
			"- Attacked By: They are learned when a player group member is attacked by a combatant " +
			"with the different attributes (single attribute).\n" +
			"- Death: They are learned when the combatant has been killed (all attributes).", "")]
		[ORKEditorInfo("Defence Attribute Settings", "Define how defence attributes are learned and " +
			"unknown values and attributes are displayed.", "")]
		public BestiaryLearnType defenceAttributes = BestiaryLearnType.AttackedBy;

		[ORKEditorHelp("Defence Attribute IDs", "Select how defence attribute IDs are learned:\n" +
			"- None: They aren't learned automatically.\n" +
			"- Encounter: They are learned when encountering a combatant.\n" +
			"- Attack: They are learned when attacking a combatant.\n" +
			"- Attacked By: They are learned when a player group member is attacked by a combatant.\n" +
			"- Death: They are learned when the combatant has been killed.\n" +
			"All defence attribute IDs are learned at the same time.", "")]
		public BestiaryLearnType defenceAttributeIDs = BestiaryLearnType.Encounter;

		[ORKEditorHelp("Unknown Value", "The text used to display the value of an unknown defence attribute.\n" +
			"Note that this text will only replace the value, not any other information of the defence attribute.", "")]
		[ORKEditorInfo(expandWidth=true, separator=true, labelText="Unknown Value Text")]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] defenceAttributeText = ArrayHelper.CreateArray(ORK.Languages.Count, "???");

		[ORKEditorHelp("Unknown Attribute ID", "The text used to display the unknown defence attribute ID of a combatant.\n" +
			"Note that this text will only replace the name of the defence attribute, " +
			"other information (e.g. icons) will be ignored when displayed.", "")]
		[ORKEditorInfo(endFoldout=true, expandWidth=true, separator=true, labelText="Unknown Attribute ID Text")]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string[] defenceAttributeIDText = ArrayHelper.CreateArray(ORK.Languages.Count, "???");

		public BestiarySettings()
		{

		}
	}
}
