
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BestiaryAttribute : ISaveData
	{
		public bool[] attribute;
		
		public BestiaryAttribute(int size)
		{
			this.attribute = new bool[size];
		}
		
		public bool IsComplete()
		{
			for(int i=0; i<this.attribute.Length; i++)
			{
				if(!this.attribute[i])
				{
					return false;
				}
			}
			return true;
		}
		
		public void SetAll(bool value, ref bool changed)
		{
			for(int i=0; i<this.attribute.Length; i++)
			{
				if(!this.attribute[i])
				{
					this.attribute[i] = value;
					changed = true;
				}
			}
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			data.Set("attribute", this.attribute);
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("attribute", out this.attribute);
			}
		}
	}
}
