﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TooltipRequirement : BaseData
	{
		// variable conditions
		[ORKEditorHelp("Use Tooltip Variables", "Use variables of the displayed tooltip.\n" +
			"E.g. when displaying a combatant, this'll use object variables of the combatant.\n" +
			"E.g. when displaying an item, this'll use item variables of the item.", "")]
		[ORKEditorInfo(labelText="Variable Conditions")]
		public bool useTooltipVariables = false;

		public VariableCondition condition = new VariableCondition();

		public TooltipRequirement()
		{

		}

		public bool Check(IContentSimple tooltip)
		{
			if(tooltip is PreviewSelection)
			{
				tooltip = ((PreviewSelection)tooltip).Shortcut;
			}
			VariableHandler handler = this.GetUsedVariableHandler(tooltip);
			if(handler != null)
			{
				return this.condition.CheckVariables(handler);
			}
			return false;
		}

		private VariableHandler GetUsedVariableHandler(IContentSimple tooltip)
		{
			if(this.useTooltipVariables)
			{
				return VariableHandler.GetHandler(tooltip);
			}
			else
			{
				return ORK.Game.Variables;
			}
		}
	}
}
