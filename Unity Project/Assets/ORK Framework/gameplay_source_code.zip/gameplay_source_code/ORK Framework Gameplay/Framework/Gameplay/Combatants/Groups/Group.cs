
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Behaviours;

namespace ORKFramework
{
	public class Group : ISaveData
	{
		private int factionID = 0;


		// items
		private Inventory inventory;

		private List<IShortcut> loot = new List<IShortcut>();


		// handlers
		private GroupAbilities abilities;

		private SelectedTargets selectedTargets;

		private GroupShortcuts shortcuts;


		// members
		private List<Combatant> members = new List<Combatant>();

		private List<Combatant> battleMembers = new List<Combatant>();

		private List<Combatant> lockedBattleMembers = new List<Combatant>();

		private List<Combatant> inactiveMembers = new List<Combatant>();

		private List<Combatant> hiddenMembers = new List<Combatant>();

		private int battleLeaderIndex = 0;


		// spawner
		private CombatantSpawner spawner;

		private int spawnerIndex = -1;

		private bool spawnerRespawn = false;

		private BattleSystemType battleType;


		// change
		private GroupChanged changedHandler;
		public event GroupChanged Changed
		{
			add { this.changedHandler += value; }
			remove { this.changedHandler -= value; }
		}

		public Group()
		{
			this.inventory = new Inventory(this);
			this.abilities = new GroupAbilities(this);
			this.shortcuts = new GroupShortcuts(this);
		}

		public Group(int fid)
		{
			this.factionID = fid;
			this.inventory = new Inventory(this);
			this.abilities = new GroupAbilities(this);
			this.shortcuts = new GroupShortcuts(this);
		}

		public Group(DataObject data)
		{
			this.inventory = new Inventory(this);
			this.abilities = new GroupAbilities(this);
			this.shortcuts = new GroupShortcuts(this);
			this.LoadGame(data);
		}

		public void FireChanged()
		{
			if(this.changedHandler != null)
			{
				this.changedHandler(this);
			}
			for(int i = 0; i < this.members.Count; i++)
			{
				this.members[i].FireGroupChanged();
			}
		}


		/*
		============================================================================
		Time functions (only active player group)
		============================================================================
		*/
		public void Tick(float time, float battleTime)
		{
			// tick all unspawned members
			for(int i = 0; i < this.members.Count; i++)
			{
				if(this.members[i].GameObject == null)
				{
					this.members[i].Tick(time, battleTime);
				}
			}
		}


		/*
		============================================================================
		Get/Set functions
		============================================================================
		*/
		public int FactionID
		{
			get { return this.factionID; }
			set { this.factionID = value; }
		}

		public Inventory Inventory
		{
			get
			{
				if(ORK.InventorySettings.IsIndividual() &&
					this.Leader != null)
				{
					return this.Leader.Inventory;
				}
				return this.inventory;
			}
		}

		public List<IShortcut> Loot
		{
			get { return this.loot; }
		}

		public int Size
		{
			get { return this.members.Count; }
		}

		public int BattleSize
		{
			get { return this.battleMembers.Count; }
		}

		public int NonBattleSize
		{
			get { return this.members.Count - this.battleMembers.Count; }
		}

		public GroupAbilities Abilities
		{
			get { return this.abilities; }
		}

		public GroupShortcuts Shortcuts
		{
			get { return this.shortcuts; }
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public SelectedTargets SelectedTargets
		{
			get
			{
				if(this.selectedTargets == null)
				{
					this.selectedTargets = new SelectedTargets(this);
				}
				return this.selectedTargets;
			}
		}

		public void ClearTargets()
		{
			this.SelectedTargets.Clear();
			for(int i = 0; i < this.members.Count; i++)
			{
				this.members[i].SelectedTargets.Clear();
			}
		}


		/*
		============================================================================
		Level functions
		============================================================================
		*/
		public int AverageLevel
		{
			get
			{
				if(this.members.Count > 0)
				{
					int lvl = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						lvl += this.members[i].Level;
					}
					return lvl / this.members.Count;
				}
				return 1;
			}
		}

		public int AverageBattleLevel
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					int lvl = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						lvl += this.battleMembers[i].Level;
					}
					return lvl / this.battleMembers.Count;
				}
				return 1;
			}
		}

		public int AverageMaxLevel
		{
			get
			{
				if(this.members.Count > 0)
				{
					int lvl = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						lvl += this.members[i].MaxLevel;
					}
					return lvl / this.members.Count;
				}
				return 1;
			}
		}

		public int AverageBattleMaxLevel
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					int lvl = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						lvl += this.battleMembers[i].MaxLevel;
					}
					return lvl / this.battleMembers.Count;
				}
				return 1;
			}
		}

		public int AverageClassLevel
		{
			get
			{
				if(this.members.Count > 0)
				{
					int lvl = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						lvl += this.members[i].ClassLevel;
					}
					return lvl / this.members.Count;
				}
				return 1;
			}
		}

		public int AverageBattleClassLevel
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					int lvl = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						lvl += this.battleMembers[i].ClassLevel;
					}
					return lvl / this.battleMembers.Count;
				}
				return 1;
			}
		}

		public int AverageMaxClassLevel
		{
			get
			{
				if(this.members.Count > 0)
				{
					int lvl = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						lvl += this.members[i].MaxClassLevel;
					}
					return lvl / this.members.Count;
				}
				return 1;
			}
		}

		public int AverageBattleMaxClassLevel
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					int lvl = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						lvl += this.battleMembers[i].MaxClassLevel;
					}
					return lvl / this.battleMembers.Count;
				}
				return 1;
			}
		}

		public int AverageTurn
		{
			get
			{
				if(this.members.Count > 0)
				{
					int turn = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						turn += this.members[i].Battle.Turn;
					}
					return turn / this.members.Count;
				}
				return 0;
			}
		}

		public int AverageBattleTurn
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					int turn = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						turn += this.battleMembers[i].Battle.Turn;
					}
					return turn / this.battleMembers.Count;
				}
				return 0;
			}
		}

		public float AverageTurnValue
		{
			get
			{
				if(this.members.Count > 0)
				{
					float value = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						value += this.members[i].Battle.TurnValue;
					}
					return value / this.members.Count;
				}
				return 0;
			}
		}

		public float AverageBattleTurnValue
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					float value = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						value += this.battleMembers[i].Battle.TurnValue;
					}
					return value / this.battleMembers.Count;
				}
				return 0;
			}
		}

		public float AverageActionBar
		{
			get
			{
				if(this.members.Count > 0)
				{
					float value = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						value += this.members[i].Battle.ActionBar;
					}
					return value / this.members.Count;
				}
				return 0;
			}
		}

		public float AverageBattleActionBar
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					float value = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						value += this.battleMembers[i].Battle.ActionBar;
					}
					return value / this.battleMembers.Count;
				}
				return 0;
			}
		}

		public float AverageUsedActionBar
		{
			get
			{
				if(this.members.Count > 0)
				{
					float value = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						value += this.members[i].Battle.UsedActionBar;
					}
					return value / this.members.Count;
				}
				return 0;
			}
		}

		public float AverageBattleUsedActionBar
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					float value = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						value += this.battleMembers[i].Battle.UsedActionBar;
					}
					return value / this.battleMembers.Count;
				}
				return 0;
			}
		}

		public float AverageActionTime
		{
			get
			{
				if(this.members.Count > 0)
				{
					float value = 0;
					for(int i = 0; i < this.members.Count; i++)
					{
						value += this.members[i].Battle.ActionTime;
					}
					return value / this.members.Count;
				}
				return 0;
			}
		}

		public float AverageBattleActionTime
		{
			get
			{
				if(this.battleMembers.Count > 0)
				{
					float value = 0;
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						value += this.battleMembers[i].Battle.ActionTime;
					}
					return value / this.battleMembers.Count;
				}
				return 0;
			}
		}


		/*
		============================================================================
		Get group functions
		============================================================================
		*/
		public List<Combatant> GetGroup()
		{
			return this.members;
		}

		public void GetGroup(ref List<Combatant> list)
		{
			for(int i = 0; i < this.members.Count; i++)
			{
				if(!list.Contains(this.members[i]))
				{
					list.Add(this.members[i]);
				}
			}
		}

		public List<Combatant> GetBattle()
		{
			return this.battleMembers;
		}

		public void GetBattle(ref List<Combatant> list)
		{
			for(int i = 0; i < this.battleMembers.Count; i++)
			{
				if(!list.Contains(this.battleMembers[i]))
				{
					list.Add(this.battleMembers[i]);
				}
			}
		}

		public List<Combatant> GetLockedBattle()
		{
			return this.lockedBattleMembers;
		}

		public void GetLockedBattle(ref List<Combatant> list)
		{
			for(int i = 0; i < this.lockedBattleMembers.Count; i++)
			{
				if(!list.Contains(this.lockedBattleMembers[i]))
				{
					list.Add(this.lockedBattleMembers[i]);
				}
			}
		}

		public List<Combatant> GetNonBattle()
		{
			List<Combatant> list = new List<Combatant>(this.members);
			for(int i = 0; i < this.battleMembers.Count; i++)
			{
				list.Remove(this.battleMembers[i]);
			}
			for(int i = 0; i < this.hiddenMembers.Count; i++)
			{
				list.Remove(this.hiddenMembers[i]);
			}
			return list;
		}

		public void GetNonBattle(ref List<Combatant> list)
		{
			for(int i = 0; i < this.members.Count; i++)
			{
				if(!list.Contains(this.members[i]) &&
					!this.battleMembers.Contains(this.members[i]) &&
					!this.hiddenMembers.Contains(this.members[i]))
				{
					list.Add(this.members[i]);
				}
			}
		}

		public List<Combatant> GetInactiveGroup()
		{
			return this.inactiveMembers;
		}

		public void GetInactiveGroup(ref List<Combatant> list)
		{
			for(int i = 0; i < this.inactiveMembers.Count; i++)
			{
				if(!list.Contains(this.inactiveMembers[i]))
				{
					list.Add(this.inactiveMembers[i]);
				}
			}
		}

		public List<Combatant> GetHiddenGroup()
		{
			return this.hiddenMembers;
		}

		public void GetHiddenGroup(ref List<Combatant> list)
		{
			for(int i = 0; i < this.hiddenMembers.Count; i++)
			{
				if(!list.Contains(this.hiddenMembers[i]))
				{
					list.Add(this.hiddenMembers[i]);
				}
			}
		}

		public void GetMembers(MenuCombatantScope scope, ref List<Combatant> list)
		{
			if(MenuCombatantScope.Battle == scope)
			{
				for(int i = 0; i < this.battleMembers.Count; i++)
				{
					if(this.battleMembers[i] != null &&
						!list.Contains(this.battleMembers[i]))
					{
						list.Add(this.battleMembers[i]);
					}
				}
			}
			else if(MenuCombatantScope.Group == scope)
			{
				for(int i = 0; i < this.members.Count; i++)
				{
					if(this.members[i] != null &&
						!list.Contains(this.members[i]))
					{
						list.Add(this.members[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Faction functions
		============================================================================
		*/
		public bool IsPlayerControlled()
		{
			return this == ORK.Game.ActiveGroup;
		}

		public bool IsEnemy(Combatant c)
		{
			return c != null && c.Group != null &&
				ORK.Game.Faction.IsEnemy(this.factionID, c.Group.FactionID);
		}

		public bool IsEnemy(int id)
		{
			return ORK.Game.Faction.IsEnemy(this.factionID, id);
		}


		/*
		============================================================================
		Leader functions
		============================================================================
		*/
		public Combatant Leader
		{
			get
			{
				if(ORK.Control.InBattle)
				{
					if(this.battleLeaderIndex >= 0 &&
						this.battleLeaderIndex < this.battleMembers.Count)
					{
						return this.battleMembers[this.battleLeaderIndex];
					}
				}
				if(this.members.Count > 0)
				{
					return this.members[0];
				}
				return null;
			}
		}

		public Combatant FieldLeader
		{
			get
			{
				if(this.members.Count > 0)
				{
					return this.members[0];
				}
				return null;
			}
		}

		public Combatant BattleLeader
		{
			get
			{
				if(this.battleLeaderIndex >= 0 &&
					this.battleLeaderIndex < this.battleMembers.Count)
				{
					return this.battleMembers[this.battleLeaderIndex];
				}
				return this.Leader;
			}
		}

		public void SetLeader(Combatant newLeader, bool moveOldBack)
		{
			if(this.members.Count == 0 || this.members[0] != newLeader)
			{
				Combatant oldLeader = this.BattleLeader;
				if(moveOldBack && this.members.Count > 0)
				{
					Combatant tmp = this.members[0];
					this.members.RemoveAt(0);
					this.members.Add(tmp);
				}
				if(this.members.Contains(newLeader))
				{
					this.members.Remove(newLeader);
				}
				this.members.Insert(0, newLeader);

				// update battle group
				if(this.battleMembers.Contains(newLeader))
				{
					this.battleLeaderIndex = this.battleMembers.IndexOf(newLeader);
				}

				this.Abilities.LeaderChanged(oldLeader, this.BattleLeader);

				for(int i = 0; i < this.members.Count; i++)
				{
					if(this.members[i].MoveAI != null)
					{
						this.members[i].MoveAI.LeaderChanged(oldLeader, this.BattleLeader);
					}
				}
			}
			this.FireChanged();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		private bool InGroup(int id, List<Combatant> group)
		{
			for(int i = 0; i < group.Count; i++)
			{
				if(group[i] != null && group[i].RealID == id)
				{
					return true;
				}
			}
			return false;
		}

		public bool IsMember(int id)
		{
			return this.InGroup(id, this.members);
		}

		public bool IsMember(Combatant c)
		{
			return this.members.Contains(c);
		}

		public bool IsBattleMember(int id)
		{
			return this.InGroup(id, this.battleMembers);
		}

		public bool IsBattleMember(Combatant c)
		{
			return this.battleMembers.Contains(c);
		}

		public bool IsInactive(int id)
		{
			return this.InGroup(id, this.inactiveMembers);
		}

		public bool IsInactive(Combatant c)
		{
			return this.inactiveMembers.Contains(c);
		}

		public bool AllDeadBattle()
		{
			if(this.battleMembers.Count > 0)
			{
				for(int i = 0; i < this.battleMembers.Count; i++)
				{
					if(this.battleMembers[i] != null &&
						!this.battleMembers[i].Dead)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool AllDead()
		{
			if(this.members.Count > 0)
			{
				for(int i = 0; i < this.members.Count; i++)
				{
					if(this.members[i] != null &&
						!this.members[i].Dead)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Group functions
		============================================================================
		*/
		public void Join(Combatant c, bool showNotification, bool showConsole)
		{
			if(c != null && !this.IsMember(c))
			{
				if(this.IsPlayerControlled())
				{
					// notification
					if(showNotification)
					{
						if(c.Setting.ownPlayerGroupNotifications)
						{
							c.Setting.playerGroupNotifications.joinGroup.Show(c);
						}
						else
						{
							ORK.GameSettings.playerGroupNotifications.joinGroup.Show(c);
						}
					}
					// console
					if(showConsole && ORK.ConsoleSettings.displayPlayerGroup)
					{
						if(c.Setting.ownConsoleJoinGroup)
						{
							c.Setting.consoleJoinGroup.Print(c);
						}
						else
						{
							ORK.ConsoleSettings.joinGroup.Print(c);
						}
					}
				}

				this.inactiveMembers.Remove(c);
				this.members.Add(c);
				c.SetGroup(this);
				this.JoinBattle(c);

				if(this == ORK.Game.ActiveGroup && c == this.Leader)
				{
					c.Inventory.showNotifications = true;
				}

				this.FireChanged();
			}
		}

		public void Leave(int id, bool destroyPrefab, bool showNotification, bool showConsole)
		{
			if(this.IsMember(id))
			{
				this.Leave(this.Get(id), destroyPrefab, showNotification, showConsole);
			}
		}

		public void Leave(Combatant c, bool destroyPrefab, bool showNotification, bool showConsole)
		{
			if(c != null)
			{
				if(this.IsPlayerControlled())
				{
					// notification
					if(showNotification)
					{
						if(c.Setting.ownPlayerGroupNotifications)
						{
							c.Setting.playerGroupNotifications.leaveGroup.Show(c);
						}
						else
						{
							ORK.GameSettings.playerGroupNotifications.leaveGroup.Show(c);
						}
					}
					// console
					if(showConsole && ORK.ConsoleSettings.displayPlayerGroup)
					{
						if(c.Setting.ownConsoleLeaveGroup)
						{
							c.Setting.consoleLeaveGroup.Print(c);
						}
						else
						{
							ORK.ConsoleSettings.leaveGroup.Print(c);
						}
					}
				}

				this.UnlockBattleMember(c);
				this.LeaveBattle(c, destroyPrefab);
				this.members.Remove(c);
				this.inactiveMembers.Add(c);
				this.shortcuts.RemoveCombatant(c);
				this.FireChanged();
			}
		}

		public void Remove(int id, bool setGroup, bool destroyPrefab, bool showNotification, bool showConsole)
		{
			this.Remove(this.Get(id), setGroup, destroyPrefab, showNotification, showConsole);
		}

		public void Remove(Combatant c, bool setGroup, bool destroyPrefab, bool showNotification, bool showConsole)
		{
			if(c != null)
			{
				if(this.IsPlayerControlled())
				{
					// notification
					if(showNotification)
					{
						if(c.Setting.ownPlayerGroupNotifications)
						{
							c.Setting.playerGroupNotifications.leaveGroup.Show(c);
						}
						else
						{
							ORK.GameSettings.playerGroupNotifications.leaveGroup.Show(c);
						}
					}
					// console
					if(showConsole && ORK.ConsoleSettings.displayPlayerGroup)
					{
						if(c.Setting.ownConsoleLeaveGroup)
						{
							c.Setting.consoleLeaveGroup.Print(c);
						}
						else
						{
							ORK.ConsoleSettings.leaveGroup.Print(c);
						}
					}
				}

				if(setGroup)
				{
					c.ClearGroup();
				}
				this.UnlockBattleMember(c);
				this.LeaveBattle(c, destroyPrefab);
				this.members.Remove(c);
				this.inactiveMembers.Remove(c);
				this.shortcuts.RemoveCombatant(c);
				this.FireChanged();
			}
		}

		public void Regenerate(bool onlyBattle, bool revive)
		{
			if(onlyBattle)
			{
				for(int i = 0; i < this.battleMembers.Count; i++)
				{
					if(this.battleMembers[i] != null)
					{
						this.battleMembers[i].Status.Regenerate(revive);
					}
				}
			}
			else
			{
				for(int i = 0; i < this.members.Count; i++)
				{
					if(this.members[i] != null)
					{
						this.members[i].Status.Regenerate(revive);
					}
				}
			}
		}

		public void MarkHUDUpdate()
		{
			for(int i = 0; i < this.members.Count; i++)
			{
				this.members[i].MarkHUDUpdate();
			}
		}


		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public void SetBattleGroup(List<Combatant> list)
		{
			bool doLock = false;
			bool inBattle = false;
			Combatant battleLeader = this.BattleLeader;
			List<Combatant> keep = new List<Combatant>();
			for(int i = 0; i < this.battleMembers.Count; i++)
			{
				if(list.Contains(this.battleMembers[i]))
				{
					keep.Add(this.battleMembers[i]);
				}
				else
				{
					this.PlayerChangeCheck(this.battleMembers[i]);
					this.shortcuts.RemoveCombatant(this.battleMembers[i]);
					if(ORK.Game.Combatants.Unlock(this.battleMembers[i]))
					{
						doLock = true;
					}
					if(this.battleMembers[i].Battle.InBattle)
					{
						inBattle = true;
						ORK.Battle.RemoveCombatant(this.battleMembers[i], false);
					}
				}
			}
			this.battleMembers.Clear();

			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(keep.Contains(list[i]))
					{
						this.battleMembers.Add(list[i]);
					}
					else
					{
						if(!this.IsMember(list[i]))
						{
							this.inactiveMembers.Remove(list[i]);
							this.members.Add(list[i]);
							list[i].SetGroup(this);

							if(this == ORK.Game.ActiveGroup && list[i] == this.Leader)
							{
								list[i].Inventory.showNotifications = true;
							}
						}
						this.battleMembers.Add(list[i]);
						if(doLock)
						{
							ORK.Game.Combatants.Lock(list[i]);
						}
						if(inBattle)
						{
							ORK.Battle.Join(list[i]);
						}
					}
				}
			}

			if(this.battleMembers.Contains(battleLeader))
			{
				this.battleLeaderIndex = this.battleMembers.IndexOf(battleLeader);
			}
			else
			{
				this.battleLeaderIndex = 0;
			}

			this.FireChanged();
		}

		public void JoinBattle(Combatant combatant)
		{
			if(combatant != null && !this.IsBattleMember(combatant) &&
				(!this.IsPlayerControlled() ||
				this.battleMembers.Count < ORK.Battle.PlayerMaxBattleGroupSize))
			{
				if(this.IsMember(combatant))
				{
					this.battleMembers.Add(combatant);
					if(this.Leader != null && this.Leader.GameObject != null &&
						(!this.IsPlayerControlled() || ORK.GameSettings.spawnGroup))
					{
						this.SpawnGroup(true, true);
					}
					this.FireChanged();
				}
				else
				{
					this.Join(combatant, false, false);
				}
			}
		}

		public void LeaveBattle(Combatant combatant, bool destroyPrefab)
		{
			if(combatant != null && !this.IsLockedBattleMember(combatant))
			{
				this.DoLeaveBattle(combatant, destroyPrefab);
				this.FireChanged();
			}
		}

		private void DoLeaveBattle(Combatant combatant, bool destroyPrefab)
		{
			this.PlayerChangeCheck(combatant);
			Combatant battleLeader = this.BattleLeader;
			this.battleMembers.Remove(combatant);
			if(this.battleMembers.Contains(battleLeader))
			{
				this.battleLeaderIndex = this.battleMembers.IndexOf(battleLeader);
			}
			if(destroyPrefab)
			{
				combatant.DestroyPrefab();
			}
			this.shortcuts.RemoveCombatant(combatant);
		}

		public void ChangeBattle(Combatant oldCombatant, Combatant newCombatant)
		{
			if(this.IsBattleMember(oldCombatant) &&
				!this.IsLockedBattleMember(oldCombatant) &&
				!this.IsBattleMember(newCombatant))
			{
				this.battleMembers[this.battleMembers.IndexOf(oldCombatant)] = newCombatant;
				if(oldCombatant.GameObject != null &&
					newCombatant.GameObject == null)
				{
					Vector3 pos = oldCombatant.GameObject.transform.position;
					Vector3 ea = oldCombatant.GameObject.transform.eulerAngles;
					oldCombatant.DestroyPrefab();

					newCombatant.Spawn(pos, true, ea.y, false, Vector3.one);
				}
				else
				{
					oldCombatant.DestroyPrefab();

					if(this.Leader != null && this.Leader.GameObject != null &&
						(!this.IsPlayerControlled() || ORK.GameSettings.spawnGroup))
					{
						this.SpawnGroup(true, true);
					}
				}
				this.PlayerChangeCheck(oldCombatant);

				this.FireChanged();
			}
		}

		public void PlayerChangeCheck(Combatant combatant)
		{
			if(this.IsPlayerControlled() &&
				this.members.Count > 0 &&
				combatant == this.members[0] &&
				this.battleMembers.Count > 0)
			{
				if(combatant != this.battleMembers[0])
				{
					ORK.Game.PlayerHandler.SetPlayer(this.battleMembers[0], false);
				}
				else if(this.battleMembers.Count > 1)
				{
					ORK.Game.PlayerHandler.SetPlayer(this.battleMembers[1], false);
				}
			}
		}

		public void CheckMaxBattleGroup()
		{
			if(this.IsPlayerControlled() &&
				this.battleMembers.Count >= ORK.Battle.PlayerMaxBattleGroupSize)
			{
				for(int i = this.battleMembers.Count - 1; i >= ORK.Battle.PlayerMaxBattleGroupSize; i--)
				{
					Combatant combatant = this.battleMembers[i];
					if(this.IsLockedBattleMember(combatant))
					{
						this.UnlockBattleMember(combatant);
					}
					this.DoLeaveBattle(combatant, true);
				}

				if(this.battleLeaderIndex >= 0 &&
					this.battleLeaderIndex < this.battleMembers.Count)
				{
					this.battleLeaderIndex = 0;
				}
				this.FireChanged();
			}
		}


		/*
		============================================================================
		Index functions
		============================================================================
		*/
		private Combatant GetOffsetGroup(Combatant c, int offset, List<Combatant> group, ref int cycles)
		{
			int index = group.IndexOf(c) + offset;
			if(index < 0)
			{
				index = group.Count - 1;
				cycles++;
			}
			else if(index >= group.Count)
			{
				index = 0;
				cycles++;
			}
			return group[index];
		}

		public Combatant GetOffset(Combatant c, int offset, bool battleGroup)
		{
			int cycles = 0;
			if(battleGroup)
			{
				return this.GetOffsetGroup(c, offset, this.battleMembers, ref cycles);
			}
			else
			{
				return this.GetOffsetGroup(c, offset, this.members, ref cycles);
			}
		}

		public Combatant GetOffsetControllable(Combatant c, int offset, bool battleGroup, bool notDead)
		{
			int cycles = 0;
			Combatant found = c;
			do
			{
				if(battleGroup)
				{
					found = this.GetOffsetGroup(found, offset, this.battleMembers, ref cycles);
				}
				else
				{
					found = this.GetOffsetGroup(found, offset, this.members, ref cycles);
				}
				if((!notDead || !found.Dead) &&
					(!found.IsAIControlled() ||
						!found.Setting.notControllable))
				{
					return found;
				}
			} while(cycles < 2);

			return c;
		}

		public int GetMemberIndex(Combatant combatant)
		{
			for(int i = 0; i < this.members.Count; i++)
			{
				if(this.members[i] == combatant)
				{
					return i;
				}
			}
			return -1;
		}

		public Combatant MemberAt(int index)
		{
			if(index >= 0 && index < this.members.Count)
			{
				return this.members[index];
			}
			else if(this.members.Count > 0)
			{
				return this.members[0];
			}
			return null;
		}

		public Combatant BattleMemberAt(int index)
		{
			if(index >= 0 && index < this.battleMembers.Count)
			{
				return this.battleMembers[index];
			}
			else if(this.battleMembers.Count > 0)
			{
				return this.battleMembers[0];
			}
			return null;
		}

		public Combatant NonBattleMemberAt(int index)
		{
			List<Combatant> nonBattle = this.GetNonBattle();
			if(index >= 0 && index < nonBattle.Count)
			{
				return nonBattle[index];
			}
			else if(nonBattle.Count > 0)
			{
				return nonBattle[0];
			}
			return null;
		}


		/*
		============================================================================
		Get member functions
		============================================================================
		*/
		public Combatant Get(int id)
		{
			for(int i = 0; i < this.members.Count; i++)
			{
				if(this.members[i] != null && this.members[i].RealID == id)
				{
					return this.members[i];
				}
			}
			return null;
		}

		public Combatant GetBattle(int id)
		{
			for(int i = 0; i < this.battleMembers.Count; i++)
			{
				if(this.battleMembers[i] != null && this.battleMembers[i].RealID == id)
				{
					return this.battleMembers[i];
				}
			}
			return null;
		}

		public Combatant GetInactive(int id)
		{
			for(int i = 0; i < this.inactiveMembers.Count; i++)
			{
				if(this.inactiveMembers[i] != null && this.inactiveMembers[i].RealID == id)
				{
					return this.inactiveMembers[i];
				}
			}
			return null;
		}

		public Combatant GetMember(int id)
		{
			Combatant c = this.Get(id);
			if(c == null)
			{
				c = this.GetInactive(id);
			}
			return c;
		}

		public Combatant GetFirstAlive()
		{
			for(int i = 0; i < this.battleMembers.Count; i++)
			{
				if(this.battleMembers[i] != null &&
					!this.battleMembers[i].Dead)
				{
					return this.battleMembers[i];
				}
			}
			for(int i = 0; i < this.members.Count; i++)
			{
				if(this.members[i] != null &&
					!this.members[i].Dead)
				{
					return this.members[i];
				}
			}
			return this.Leader;
		}


		/*
		============================================================================
		Lock battle member functions
		============================================================================
		*/
		public void LockBattleMember(Combatant c)
		{
			if(c != null && this.IsBattleMember(c) && !this.IsLockedBattleMember(c))
			{
				this.lockedBattleMembers.Add(c);
				this.FireChanged();
			}
		}

		public void UnlockBattleMember(Combatant c)
		{
			if(c != null && this.IsBattleMember(c) && this.IsLockedBattleMember(c))
			{
				this.lockedBattleMembers.Remove(c);
				this.FireChanged();
			}
		}

		public bool IsLockedBattleMember(Combatant c)
		{
			return this.lockedBattleMembers.Contains(c);
		}

		public bool HasLockedBattleMembers()
		{
			return this.lockedBattleMembers.Count > 0;
		}


		/*
		============================================================================
		Hide member functions
		============================================================================
		*/
		public void HideMember(Combatant c)
		{
			if(c != null && this.IsMember(c))
			{
				this.lockedBattleMembers.Remove(c);
				Combatant battleLeader = this.BattleLeader;
				this.battleMembers.Remove(c);
				if(this.battleMembers.Contains(battleLeader))
				{
					this.battleLeaderIndex = this.battleMembers.IndexOf(battleLeader);
				}
				this.hiddenMembers.Add(c);
				this.shortcuts.RemoveCombatant(c);
				this.FireChanged();
			}
		}

		public void UnhideMember(Combatant c)
		{
			if(c != null && this.IsMember(c))
			{
				this.hiddenMembers.Remove(c);
				this.FireChanged();
			}
		}

		public bool IsHiddenMember(Combatant c)
		{
			return this.hiddenMembers.Contains(c);
		}


		/*
		============================================================================
		Spawn group functions
		============================================================================
		*/
		public BattleSystemType BattleType
		{
			get { return this.battleType; }
			set { this.battleType = value; }
		}

		public CombatantSpawner Spawner
		{
			get { return this.spawner; }
		}

		public int SpawnerIndex
		{
			get { return this.spawnerIndex; }
		}

		public void SetSpawner(CombatantSpawner spawner, int spawnerIndex, bool respawn)
		{
			this.spawner = spawner;
			this.spawnerIndex = spawnerIndex;
			this.spawnerRespawn = respawn;
		}

		public void CheckSpawner(bool force)
		{
			if(this.spawner != null && this.spawnerRespawn)
			{
				if(!force)
				{
					for(int i = 0; i < this.battleMembers.Count; i++)
					{
						if(!this.battleMembers[i].Dead)
						{
							return;
						}
					}
				}
				this.spawner.CheckRespawn(this.spawnerIndex, this);
			}
		}

		public void RespawnGroup()
		{
			List<Combatant> list = new List<Combatant>(this.GetBattle());
			for(int i = 0; i < list.Count; i++)
			{
				if(!list[i].RespawnFlag)
				{
					list[i] = null;
				}
			}
			this.SpawnGroup(null, list);
		}

		public void SpawnGroup(bool onlyBattle, bool onlyNonCreated)
		{
			this.SpawnGroup(null, onlyBattle, onlyNonCreated);
		}

		public void SpawnGroup(Combatant leader, bool onlyBattle, bool onlyNonCreated)
		{
			List<Combatant> list = new List<Combatant>(onlyBattle ? this.GetBattle() : this.GetGroup());
			if(onlyNonCreated)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].GameObject != null)
					{
						list.RemoveAt(i--);
					}
				}
			}
			this.SpawnGroup(leader, list);
		}

		private void SpawnGroup(Combatant leader, List<Combatant> list)
		{
			if(leader != null && leader.GameObject == null)
			{
				leader = null;
			}
			if(leader == null &&
				this.Leader.GameObject != null)
			{
				leader = this.Leader;
			}
			if(leader == null &&
				this.BattleLeader.GameObject != null)
			{
				leader = this.BattleLeader;
			}
			if(leader == null &&
				this.FieldLeader.GameObject != null)
			{
				leader = this.FieldLeader;
			}
			if(leader != null &&
				leader.GameObject != null)
			{
				Vector3 upDirection = Vector3.up;
				if(HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane)
				{
					upDirection = Vector3.forward;
				}

				Vector3 spawnPosition = HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane ?
					leader.GameObject.transform.TransformPoint(0, -ORK.GameSettings.spawnDistance, 0) :
					leader.GameObject.transform.TransformPoint(0, 1, -ORK.GameSettings.spawnDistance);

				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null && list[i] != leader &&
						(!list[i].Dead || this.IsPlayerControlled()))
					{
						if(list[i].GameObject == null)
						{
							list[i].Spawn(spawnPosition, true, 0, false, Vector3.one);
						}
						else
						{
							list[i].PlaceAt(spawnPosition, true, 0, false, Vector3.one);
						}
						if(list[i].GameObject != null)
						{
							list[i].RespawnFlag = false;

							if(list.Count > 1)
							{
								if(list.Count <= 2)
								{
									list[i].GameObject.transform.RotateAround(
										leader.GameObject.transform.position,
										upDirection, 45.0f - (90.0f * i));
								}
								else if(list.Count <= 6)
								{
									if(i % 2 == 0)
									{
										list[i].GameObject.transform.RotateAround(
											leader.GameObject.transform.position,
											upDirection, (180.0f / list.Count) * i);
									}
									else
									{
										list[i].GameObject.transform.RotateAround(
											leader.GameObject.transform.position,
											upDirection, -(180.0f / list.Count) * i);
									}
								}
								else
								{
									if(i % 2 == 0)
									{
										list[i].GameObject.transform.RotateAround(
											leader.GameObject.transform.position,
											upDirection, (300.0f / (list.Count + 1)) * (i - 1));
									}
									else
									{
										list[i].GameObject.transform.RotateAround(
											leader.GameObject.transform.position,
											upDirection, -(300.0f / (list.Count + 1)) * i);
									}
								}
							}
							list[i].GameObject.transform.rotation = leader.GameObject.transform.rotation;
						}
					}
				}
			}
		}

		public void DestroySpawnedGroup()
		{
			for(int i = 0; i < this.members.Count; i++)
			{
				if(this.members[i] != this.Leader)
				{
					this.members[i].DestroyPrefab();
				}
			}
		}

		public void DestroyInstances()
		{
			for(int i = 0; i < this.members.Count; i++)
			{
				this.members[i].DestroyPrefab();
			}
			for(int i = 0; i < this.inactiveMembers.Count; i++)
			{
				this.inactiveMembers[i].DestroyPrefab();
			}
		}


		/*
		============================================================================
		Aggression functions
		============================================================================
		*/
		public void AggressionChangeGroup(Combatant combatant)
		{
			for(int i = 0; i < this.battleMembers.Count; i++)
			{
				if(this.battleMembers[i] != combatant &&
					this.battleMembers[i].Setting.aggressionReactGroup &&
					combatant.Setting.aggressionNotifyRangeGroup.InRange(combatant, this.battleMembers[i]))
				{
					this.battleMembers[i].IsAggressive = combatant.IsAggressive;
				}
			}
		}

		public void AggressionChangeFaction(Combatant combatant)
		{
			for(int i = 0; i < this.battleMembers.Count; i++)
			{
				if(this.battleMembers[i] != combatant &&
					this.battleMembers[i].Setting.aggressionReactFaction &&
					combatant.Setting.aggressionNotifyRangeFaction.InRange(combatant, this.battleMembers[i]))
				{
					this.battleMembers[i].IsAggressive = combatant.IsAggressive;
				}
			}
		}


		/*
		============================================================================
		Ability functions
		============================================================================
		*/
		public int GetAbilityCount(AbilityShortcut shortcut)
		{
			int count = 0;
			for(int i = 0; i < this.members.Count; i++)
			{
				if(this.members[i].Abilities.Has(shortcut))
				{
					count++;
				}
			}
			return count;
		}

		public List<Combatant> GetAbilityOwners(AbilityShortcut shortcut)
		{
			List<Combatant> list = new List<Combatant>();
			for(int i = 0; i < this.members.Count; i++)
			{
				if(this.members[i].Abilities.Has(shortcut))
				{
					list.Add(this.members[i]);
				}
			}
			return list;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("factionID", this.factionID);
			data.Set("battleLeaderIndex", this.battleLeaderIndex);

			if(ORK.InventorySettings.IsGroup() &&
				this.inventory != null)
			{
				data.Set("inventory", this.inventory.SaveGame());
			}

			// members
			DataObject[] tmp = new DataObject[this.members.Count];
			for(int i = 0; i < tmp.Length; i++)
			{
				tmp[i] = this.members[i].SaveGame();
			}
			data.Set("members", tmp);

			// inactive members
			tmp = new DataObject[this.inactiveMembers.Count];
			for(int i = 0; i < tmp.Length; i++)
			{
				tmp[i] = this.inactiveMembers[i].SaveGame();
			}
			data.Set("inactiveMembers", tmp);

			int[] tmp2 = new int[this.battleMembers.Count];
			for(int i = 0; i < tmp2.Length; i++)
			{
				for(int j = 0; j < this.members.Count; j++)
				{
					if(this.battleMembers[i] == this.members[j])
					{
						tmp2[i] = j;
					}
				}
			}
			data.Set("battleMembers", tmp2);

			tmp2 = new int[this.lockedBattleMembers.Count];
			for(int i = 0; i < tmp2.Length; i++)
			{
				for(int j = 0; j < this.members.Count; j++)
				{
					if(this.lockedBattleMembers[i] == this.members[j])
					{
						tmp2[i] = j;
					}
				}
			}
			data.Set("lockedBattleMembers", tmp2);

			tmp2 = new int[this.hiddenMembers.Count];
			for(int i = 0; i < tmp2.Length; i++)
			{
				for(int j = 0; j < this.members.Count; j++)
				{
					if(this.hiddenMembers[i] == this.members[j])
					{
						tmp2[i] = j;
					}
				}
			}
			data.Set("hiddenMembers", tmp2);


			// group abilities
			data.Set("abilities", this.abilities.SaveGame());

			// group shortcuts
			if(this.shortcuts != null)
			{
				data.Set("shortcuts", this.shortcuts.SaveGame());
			}

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("factionID", ref this.factionID);
				data.Get("battleLeaderIndex", ref this.battleLeaderIndex);
			}
		}

		public void LoadMembers(DataObject data, bool loadPositions)
		{
			if(data != null)
			{
				// members
				DataObject[] tmp = data.GetFileArray("members");
				if(tmp != null)
				{
					for(int i = 0; i < tmp.Length; i++)
					{
						this.members.Add(new Combatant(tmp[i], loadPositions, this));
					}
				}

				// inactive members
				tmp = data.GetFileArray("inactiveMembers");
				if(tmp != null)
				{
					for(int i = 0; i < tmp.Length; i++)
					{
						this.inactiveMembers.Add(new Combatant(tmp[i], loadPositions, this));
					}
				}

				int[] tmp2 = null;
				data.Get("battleMembers", out tmp2);
				if(tmp2 != null)
				{
					for(int i = 0; i < tmp2.Length; i++)
					{
						this.battleMembers.Add(this.members[tmp2[i]]);
					}
				}

				tmp2 = null;
				data.Get("lockedBattleMembers", out tmp2);
				if(tmp2 != null)
				{
					for(int i = 0; i < tmp2.Length; i++)
					{
						this.lockedBattleMembers.Add(this.members[tmp2[i]]);
					}
				}

				tmp2 = null;
				data.Get("hiddenMembers", out tmp2);
				if(tmp2 != null)
				{
					for(int i = 0; i < tmp2.Length; i++)
					{
						this.hiddenMembers.Add(this.members[tmp2[i]]);
					}
				}

				// group abilities
				this.abilities.LoadGame(data.GetFile("abilities"));

				// reset status for all
				for(int i = 0; i < this.members.Count; i++)
				{
					this.members[i].MarkResetStatus();
				}
				for(int i = 0; i < this.inactiveMembers.Count; i++)
				{
					this.inactiveMembers[i].MarkResetStatus();
				}

				if(ORK.InventorySettings.IsGroup())
				{
					DataObject inv = data.GetFile("inventory");
					if(inv != null)
					{
						this.inventory.LoadGame(inv);
					}
				}

				if(this.inventory != null)
				{
					this.inventory.CheckSpace(0, false);
				}

				if(data.ContainsArray<DataObject>("shortcutList"))
				{
					this.shortcuts = new GroupShortcuts(this);
					this.shortcuts.LoadGame(data);
				}
				else if(data.Contains<DataObject>("shortcuts"))
				{
					this.shortcuts = new GroupShortcuts(this);
					this.shortcuts.LoadGame(data.GetFile("shortcuts"));
				}
			}
		}
	}
}
