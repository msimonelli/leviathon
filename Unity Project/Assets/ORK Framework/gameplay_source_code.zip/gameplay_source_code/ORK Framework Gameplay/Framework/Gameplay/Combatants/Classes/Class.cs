
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class Class : BaseLanguageData, IContentSimple
	{
		// base settings
		// class ability
		[ORKEditorHelp("Use Class Ability", "The class uses a class ability.\n" +
			"The class ability can be leveled up by the combatant.", "")]
		[ORKEditorInfo("Base Settings", "Base settings of this class.", "", labelText="Class Ability")]
		public bool useClassAbility = false;

		[ORKEditorLayout("useClassAbility", true, endCheckGroup=true, autoInit=true)]
		public AbilitySetting classAbility;

		// battle menu
		[ORKEditorHelp("Own Battle Menu", "The class has it's own battle menu.\n" +
			"This setting overrides the default battle menu.\n" +
			"This setting can be overridden by a combatant's battle menu.", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Menu")]
		public bool ownBM = false;

		[ORKEditorHelp("Battle Menu", "Select the battle menu used by this class.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("ownBM", true)]
		public int menuID = 0;

		// turn based menu
		[ORKEditorHelp("Own Turn Based Menu", "Use a different battle menu in turn based battles.", "")]
		public bool useTurnBasedMenu = false;

		[ORKEditorHelp("Turn Based Menu", "Select the battle menu that will be used in turn based battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useTurnBasedMenu", true, endCheckGroup=true)]
		public int turnBasedMenuID = 0;

		// active time menu
		[ORKEditorHelp("Own Active Time Menu", "Use a different battle menu in active time battles.", "")]
		public bool useActiveTimeMenu = false;

		[ORKEditorHelp("Active Time Menu", "Select the battle menu that will be used in active time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useActiveTimeMenu", true, endCheckGroup=true)]
		public int activeTimeMenuID = 0;

		// real time menu
		[ORKEditorHelp("Own Real Time Menu", "Use a different battle menu in real time battles.", "")]
		public bool useRealTimeMenu = false;

		[ORKEditorHelp("Real Time Menu", "Select the battle menu that will be used in real time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useRealTimeMenu", true, endCheckGroup=true)]
		public int realTimeMenuID = 0;

		// phase battle menu
		[ORKEditorHelp("Own Phase Menu", "Use a different battle menu in phase battles.", "")]
		public bool usePhaseMenu = false;

		[ORKEditorHelp("Phase Menu", "Select the battle menu that will be used in phase battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("usePhaseMenu", true, endCheckGroup=true, endGroups=2)]
		public int phaseMenuID = 0;


		// control maps
		[ORKEditorHelp("Control Map", "Select the control map that will be used.", "")]
		[ORKEditorInfo(ORKDataType.ControlMap, separator=true, labelText="Control Map",
			endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Control Map", "Adds a control map to this class.", "",
			"Remove", "Removes the control map.", "", isHorizontal=true)]
		public int[] controlMap = new int[0];


		// equipment
		public AvailableEquipment equipment = new AvailableEquipment();


		// attack attribute startvalues
		[ORKEditorInfo("Attack Attributes Start Values", "Override the default start values of attack attributes.\n" +
			"Can be overridden by combatants.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Attack Attribute", "Adds an attack attribute start value setting.", "",
			"Remove", "Removes this attack attributes start value setting.", "",
			removeType=ORKDataType.AttackAttributes, removeCheckField="attributeID",
			foldout=true, foldoutText=new string[] {"Attack Attributes Start Value",
				"Set the start values for the selected attack attribute.", ""})]
		public AtkAttrStartValue[] atkAttrStart = new AtkAttrStartValue[0];


		// defence attribute start values
		[ORKEditorInfo("Defence Attributes Start Values", "Override the default start values of defence attributes.\n" +
			"Can be overridden by combatants.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Defence Attributes", "Adds a defence attributes start value setting.", "",
			"Remove", "Removes this defence attributes start value setting.", "",
			removeType=ORKDataType.DefenceAttributes, removeCheckField="attributeID",
			foldout=true, foldoutText=new string[] {"Defence Attributes Start Value",
				"Set the start values for the selected defence attributes.", ""})]
		public DefAttrStartValue[] defAttrStart = new DefAttrStartValue[0];


		// bonus
		public BonusSettings bonus = new BonusSettings();


		// status effect auto/immunity
		[ORKEditorInfo("Status Effect Settings", "A class can grant auto status effects and " +
			"status effect immunity to a combatant.", "", endFoldout=true)]
		public AutoEffects autoEffects = new AutoEffects();


		// development
		[ORKEditorHelp("Use Class Level", "This class can be leveled up using " +
			"EXPERIENCE type status values with class level up enabled.", "")]
		[ORKEditorInfo("Development Settings", "Additionally to a combatants base level system, " +
			"classes can also be leveled up and have status value development.", "")]
		public bool useClassLevel = false;

		[ORKEditorHelp("Status Development", "Select the status development used by this class.", "")]
		[ORKEditorInfo(ORKDataType.StatusDevelopment)]
		[ORKEditorLayout("useClassLevel", true)]
		public int statusDevelopmentID = 0;

		[ORKEditorHelp("Own Level Up", "This class overrides the default level up settings (battle system).", "")]
		[ORKEditorInfo(separator=true, labelText="Class Level Up Settings")]
		public bool ownLvlUp = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownLvlUp", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public LevelUpBonus lvlUp;

		public LearnAbilitySetting abilityDevelopment = new LearnAbilitySetting();


		// shortcut settings
		[ORKEditorHelp("Own List Count", "This class overrides the default shortcut list count defined in 'Menus > Shortcut Settings'.", "")]
		[ORKEditorInfo("Shortcut Settings", "Shortcuts are used to quickly use items or abilities, or equip weapons and armors.\n" +
			"They can be used via control maps or 'Combatant' type HUDs with shortcut elements.\n" +
			"Shortcuts are organized in lists, each list consists of a variable amount of slots (index based). " +
			"Only the currently active list can be used - switching between lists can be done using the event system, " +
			"e.g. with a global event called when pressing an input key.\n" +
			"Combatants can optionally use their own shortcut lists, disabling the class shortcut lists.", "")]
		public bool ownShortcutListCount = false;

		[ORKEditorHelp("Shortcut List Count", "The number of available shortcut lists of this class.\n" +
			"Each list consists of a variable amount of slots (index based). " +
			"Lists can be switched using the event system.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("ownShortcutListCount", true, endCheckGroup=true)]
		public int shortcutListCount = 1;

		// default shortcuts
		[ORKEditorHelp("Replace Default", "Replace the default shortcuts defined in 'Menus > Shortcut Settings'.\n" +
			"If disabled, the shorcuts defined here will be used in addition to the default shortcuts defined in the shortcut settings.", "")]
		[ORKEditorInfo("Shortcut Assignments", "Shortcuts are used to quickly use items or abilities, or equip weapons and armors.\n" +
			"They can be used via control maps or 'Combatant' type HUDs with shortcut elements.\n" +
			"The shortcut assignments are set up when the class is first used by a combatant.", "")]
		public bool replaceDefaultShortcuts = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Shortcut", "Adds a default shortcut.", "",
			"Remove", "Removes this shortcut.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Shortcut Assignment", "The selected shortcut slot will be assigned with the defined shortcut.", ""
		})]
		public ShortcutSlotAssignment[] defaultShortcut = new ShortcutSlotAssignment[0];

		// auto add shortcuts
		[ORKEditorHelp("Replace Default", "Replace the default auto add slots defined in 'Menus > Shortcut Settings'.\n" +
			"If disabled, the auto add slots defined here will be used in addition to the default auto add slots defined in the shortcut settings.", "")]
		[ORKEditorInfo("Auto Add Slots", "Shortcuts can be added automatically to shortcut slots upon getting them.\n" +
			"This is used when a combatant learns a new ability or gets a new item, equipment or currency.", "")]
		public bool replaceDefaultAutoAddSlots = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Auto Slots", "Adds default auto add slots.", "",
			"Remove", "Removes these auto add slots.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Auto Add Slots", "Define the slot range and used shortcuts that will be added automatically.", ""
		})]
		public AutoShortcutSlots[] autoAddShortcuts = new AutoShortcutSlots[0];

		// auto arrange shortcuts
		[ORKEditorHelp("Replace Default", "Replace the default auto arrange slots defined in 'Menus > Shortcut Settings'.\n" +
			"If disabled, the auto arrange slots defined here will be used in addition to the default auto arrange slots defined in the shortcut settings.", "")]
		[ORKEditorInfo("Auto Add Slots", "Shortcuts can be added automatically to shortcut slots upon getting them.\n" +
			"This is used when a combatant learns a new ability or gets a new item, equipment or currency.", "")]
		public bool replaceDefaultAutoArrangeSlots = false;

		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorArray(false, "Add Auto Arrange Slots", "Adds default auto arrange slots.", "",
			"Remove", "Removes these auto arrange slots.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Auto Arrange Slots", "Define the slot range and used shortcuts that will be arranged automatically.", ""
		})]
		public AutoShortcutSlots[] autoArrangeShortcuts = new AutoShortcutSlots[0];

		public Class()
		{

		}

		public Class(string name) : base(name)
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.ContainsArray<bool>("equipPart"))
			{
				this.equipment = new AvailableEquipment();
				data.Get("equipPart", out this.equipment.equipPart);
				data.Get("weapon", out this.equipment.weapon);
				data.Get("armor", out this.equipment.armor);
			}

			if(!data.Contains<bool>("ownShortcutListCount") && 
				data.Contains<int>("shortcutListCount"))
			{
				this.ownShortcutListCount = true;
			}
		}


		/*
		============================================================================
		Development functions
		============================================================================
		*/
		public StatusDevelopment GetStatusDevelopment()
		{
			if(this.useClassLevel)
			{
				return ORK.StatusDevelopments.Get(this.statusDevelopmentID);
			}
			else
			{
				return null;
			}
		}

		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			string desc = this.languageInfo[ORK.Game.Language].GetDescription();

			if(desc.Contains("%bonus"))
			{
				StatusPreviewInformation info = new StatusPreviewInformation(null);
				this.bonus.GetBonus(ref info);
				return info.GetBonusTexts(desc);
			}
			return desc;
		}

		public string GetIconTextCode()
		{
			return TextCode.ClassIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
