﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridMoveAction : BaseAction
	{
		private GridMoveShortcut gridMoveShortcut;

		public GridMoveAction(Combatant user, List<BattleGridCellComponent> path,
			float moveCost, GridMoveShortcut gridMoveShortcut)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);

			this.gridMoveShortcut = gridMoveShortcut;
			if(this.gridMoveShortcut == null)
			{
				this.gridMoveShortcut = this.user.Shortcuts.GridMoveShortcut;
			}

			this.gridPath = new GridPath(this.user, path, moveCost);

			this.actionCost = ORK.Battle.GetGridMoveActionCost(user);

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.GridMove == t;
		}

		public override IShortcut Shortcut
		{
			get { return this.gridMoveShortcut; }
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Dead &&
				!this.user.Status.StopMove &&
				!this.user.Status.StopMovement &&
				this.user.Battle.GridMoveState != GridMoveState.Performed;
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleAddGridMove)
				{
					this.user.Setting.consoleAddGridMove.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionAddGridMove.Print(this.user);
				}
			}
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.gridMoveInfo.Show(this.user, "");
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleGridMove)
				{
					this.user.Setting.consoleGridMove.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionGridMove.Print(this.user);
				}
			}

			this.user.GetGridMoveBattleEvent(ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{

		}

		protected override void ActionEndSetup()
		{
			if(this.user != null)
			{
				if(ORK.BattleSystem.gridSettings.moveCommand.useOnlyOnce)
				{
					this.user.Battle.GridMoveState = GridMoveState.Performed;
				}
				else
				{
					this.user.Battle.GridMoveState = GridMoveState.Available;
				}
				if(this.gridPath != null)
				{
					if(this.user.Dead)
					{
						this.gridPath.Clear();
					}
					else
					{
						this.gridPath.End();
					}
					this.gridPath = null;
				}
			}
		}
	}
}
