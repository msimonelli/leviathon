
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public struct AnimInfo
	{
		public AnimationSystem systemType;
		
		public string name;
		
		public float length;
		
		public AnimInfo(AnimationSystem systemType, string name, float length)
		{
			this.systemType = systemType;
			this.name = name;
			this.length = length;
		}
		
		public static AnimInfo None
		{
			get{ return new AnimInfo(AnimationSystem.Legacy, "", 0);}
		}
		
		public static bool operator ==(AnimInfo a1, AnimInfo a2)
		{
			return a1.name == a2.name && 
				a1.length == a2.length;
		}
		
		public static bool operator !=(AnimInfo a1, AnimInfo a2)
		{
			return a1.name != a2.name || 
				a1.length != a2.length;
		}
		
		public override bool Equals(object o)
		{
			try
			{
				return (bool)(this == (AnimInfo)o);
			}
			catch
			{
				return false;
			}
		}

		public override int GetHashCode()
		{
			return 0;
		}
	}
}
