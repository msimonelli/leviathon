
using ORKFramework;
using UnityEngine;

namespace ORKFramework
{
	public class BaseStatusRequirement : BaseData
	{
		[ORKEditorHelp("Status Needed", "Which type of status will be checked.\n" +
			"- Status Value: The selected status value will be compared to a defined value.\n" +
			"- Status Effect: The selected status effect must or mustn't be applied to the combatant.\n" +
			"- Attack Attribute: The selected attack attribute will be compared to a defined value.\n" +
			"- Defence Attribute: The combatant must have the selected defence attribute, or compares it to a defined value.\n" +
			"- Level: The combatants level (or class level) will be compared to a defined value.\n" +
			"- Ability: The combatant must have this ability.\n" +
			"- Class: The combatant must or mustn't be of the selected class.\n" +
			"- Death: The combatant must be dead/alive.\n" +
			"- Weapon: A defined weapon must or mustn't be equipped.\n" +
			"- Armor: A defined armor must or mustn't be equipped.\n" +
			"- Combatant: The combatant must or mustn't be a selected combatant.\n" +
			"- Group Leader: The combatant must or mustn't be the leader of his group.\n" +
			"- Group Size: The combatant's group size will be compared to a defined value.\n" +
			"- Inventory: The combatant's (or group's) inventory will be checked " +
			"for a defined item, weapon, armor or currency.\n" +
			"- Status Effect Type: A status effect of the selected status effect type must or mustn't be applied.\n" +
			"- Weapon Item Type : A weapon of the selected item type must or mustn't be equipped.\n" +
			"- Armor Item Type : An armor of the selected item type must or mustn't be equipped.\n" +
			"- Combatant Type: The combatant must or mustn't be of the selected combatant type.\n" +
			"- In Battle: The combatant must or mustn't be in battle.\n" +
			"- In Action: The combatant must or mustn't be in action (e.g. performing an ability).\n" +
			"- Is Casting: The combatant must or mustn't be casting an ability.\n" +
			"- Is Choosing: The combatant must or mustn't be choosing an action (e.g. displaying the battle menu).\n" +
			"- Turn State: The combatant's turn state must or mustn't match a defined state.\n" +
			"- Grid Move Range: The combatant's grid move range will be compared to a defined value.\n" +
			"- Research Tree: The combatant must know the defined research tree.\n" +
			"- Research Item: The state of a defined research item must match.\n" +
			"- AI Type: A defined AI type must or mustn't be equipped on an AI behaviour slot or AI ruleset slot.\n" +
			"- AI Behaviour: A defined AI behaviour must or mustn't be equipped on an AI behaviour slot.\n" +
			"- AI Ruleset: A defined AI ruleset must or mustn't be equipped on an AI ruleset slot.\n" +
			"- AI Behaviour Slot Count: The combatant's number of AI behaviour slots will be compared to a defined value.\n" +
			"- AI Ruleset Slot Count: The combatant's AI number of ruleset slot will be compared to a defined value.", "")]
		public StatusNeeded statusNeeded = StatusNeeded.StatusValue;

		[ORKEditorHelp("Selection", "Select the status information that will be checked for.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="statusNeeded")]
		[ORKEditorLayout(new string[] {
				"statusNeeded", "statusNeeded", "statusNeeded",
				"statusNeeded", "statusNeeded",
				"statusNeeded", "statusNeeded", "statusNeeded",
				"statusNeeded", "statusNeeded", "statusNeeded",
				"statusNeeded", "statusNeeded"
			},
			new System.Object[] {
				StatusNeeded.Level, StatusNeeded.Death, StatusNeeded.GroupLeader,
				StatusNeeded.GroupSize, StatusNeeded.Inventory,
				StatusNeeded.InBattle, StatusNeeded.InAction, StatusNeeded.IsCasting,
				StatusNeeded.IsChoosing, StatusNeeded.TurnState, StatusNeeded.GridMoveRange,
				StatusNeeded.AIBehaviourSlotCount, StatusNeeded.AIRulesetSlotCount
			}, needed=Needed.One, elseCheckGroup=true, endCheckGroup=true)]
		public int selectionID = 0;

		[ORKEditorHelp("Attribute", "Select the needed attribute.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="statusNeeded", idFieldName="selectionID")]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded"},
			new System.Object[] {StatusNeeded.AttackAttribute, StatusNeeded.DefenceAttribute},
			needed=Needed.One, endCheckGroup=true)]
		public int selectionID2 = 0;

		[ORKEditorHelp("Check Value", "Check the current value of the selected defence attribute.\n" +
			"If disabled, the combatant's current defence attribute is checked.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.DefenceAttribute, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool checkDefAttrVal = false;

		[ORKEditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the attribute.\n" +
			"- Base Value: The base value of the attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the attribute.\n" +
			"- Max Value: The maximum value of the attribute.\n" +
			"- Start Value: The start value of the attribute (i.e. the attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		[ORKEditorLayout(new string[] {"statusNeeded", "checkDefAttrVal"},
			new System.Object[] {StatusNeeded.AttackAttribute, true},
			needed=Needed.One, endCheckGroup=true)]
		public AttributeGetValue attrGetValue = AttributeGetValue.CurrentValue;

		// status value
		[ORKEditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.StatusValue, endCheckGroup=true)]
		public StatusValueGetValue svGetValue = StatusValueGetValue.CurrentValue;


		// comparison
		[ORKEditorHelp("Comparison", "The selected data (e.g. status value, attack attribute or level) " +
			"is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(new string[] {
				"statusNeeded", "statusNeeded", "statusNeeded",
				"statusNeeded", "checkDefAttrVal"},
			new System.Object[] {
				StatusNeeded.StatusValue, StatusNeeded.AttackAttribute, StatusNeeded.Level,
				StatusNeeded.GridMoveRange, true
			}, needed=Needed.One)]
		public ValueCheck comparison = ValueCheck.IsEqual;

		[ORKEditorHelp("Compare With Other", "Compares the selected status value with the current value of another status value.\n" +
			"If disabled, the status value is compared with a defined value.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.StatusValue, setDefault=true, defaultValue=false)]
		public bool compareWithOther = false;

		[ORKEditorHelp("Other Status Value", "Select the status value that will be used for the comparison.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue)]
		[ORKEditorLayout("compareWithOther", true)]
		public int otherStatusValueID = 0;

		[ORKEditorHelp("Other Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Min Value: The preview minimum value, displaying changes when an equipment would be equipped.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public StatusValueGetValue svOtherGetValue = StatusValueGetValue.CurrentValue;

		[ORKEditorHelp("Value", "The value that will be used for the comparison.", "")]
		[ORKEditorLayout("compareWithOther", false, endCheckGroup=true, endGroups=2)]
		public float value = 0;

		[ORKEditorHelp("Check In", "The value is either in percent of the maximum status value or an absolute value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(new string[] {"compareWithOther", "statusNeeded"},
			new System.Object[] {false, StatusNeeded.StatusValue}, endCheckGroup=true,
			setDefault=true, defaultValue=ValueSetter.Value)]
		public ValueSetter setter = ValueSetter.Value;

		[ORKEditorHelp("Class Level", "If enabled, the combatants class level will be used instead of the base level.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Level)]
		public bool classLevel = false;

		[ORKEditorHelp("Define Class", "Define the class which's class level will be checked.\n" +
			"If the combatant never used the defined class, it's class level will be 0.\n" +
			"If disabled, the class level of the combatant's current class will be checked.", "")]
		[ORKEditorLayout("classLevel", true)]
		public bool checkDefinedClassLevel = false;

		[ORKEditorHelp("Class", "Select the class which's level will be checked.\n" +
			"If the combatant never used the class, it's class level will be 0.", "")]
		[ORKEditorInfo(ORKDataType.Class)]
		[ORKEditorLayout("checkDefinedClassLevel", true, endCheckGroup=true, endGroups=3)]
		public int classLevelID = 0;


		// ability
		[ORKEditorHelp("Level", "The level of the ability/weapon/armor that will be checked for.\n" +
			"Ability: The combatant must have at least the defined ability level.\n" +
			"Weapon/Armor: The combatant must have at least the defined equipment level equipped.", "")]
		[ORKEditorLayout(new string[] { "statusNeeded", "statusNeeded", "statusNeeded" },
			new System.Object[] { StatusNeeded.Ability, StatusNeeded.Weapon, StatusNeeded.Armor },
			needed=Needed.One, endCheckGroup=true)]
		[ORKEditorLimit(1, false)]
		public int level = 1;

		[ORKEditorHelp("Ability Is", "Select if the ability is:\n" +
			"- Known: The combatant must know the ability (i.e. the ability is available).\n" +
			"- Learned: The combatant must have learned the ability.\n" +
			"- Group Ability: The ability must be a group ability of the combatant's group.\n" +
			"- Temporary: The ability is added as temporary ability.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Ability)]
		public AbilityCheckType abilityCheck = AbilityCheckType.Known;

		[ORKEditorHelp("Is Valid", "The 'Ability Is' check must be valid.\n" +
			"If disabled, the check must not be valid (i.e. " +
			"'Knows' = mustn't know at all, " +
			"'Learned' = mustn't be learned, " +
			"'Group Ability' = mustn't be a group ability).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool abilityValid = true;


		// status effect
		[ORKEditorHelp("Is Applied", "The selected status effect must be applied.\n" +
			"If disabled, the effect mustn't be applied.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.StatusEffect)]
		public bool applied = false;

		[ORKEditorHelp("Check Stacked Quantity", "Check the quantity the status effect is stacked on the combatant.", "")]
		[ORKEditorLayout("applied", true, setDefault=true, defaultValue=false)]
		public bool checkStacked = false;

		[ORKEditorHelp("Comparison", "The stacked count of the status effect " +
			"is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("checkStacked", true)]
		public ValueCheck stackComparison = ValueCheck.IsEqual;

		[ORKEditorHelp("Stacked Quantity", "The value that will be used for the comparison.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=3)]
		public int stackedQuantity = 0;


		// status effect type
		[ORKEditorHelp("Is Applied", "A status effect of the selected status effect type must be applied.\n" +
			"If disabled, an effect mustn't be applied.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.StatusEffectType, endCheckGroup=true)]
		public bool appliedEffectType = false;


		// death
		[ORKEditorHelp("Is Dead", "The combatant must be dead.\n" +
			"If disabled, the combatant must be alive.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Death)]
		public bool isDead = true;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be checked:\n" +
			"- Current: The combatant that is checked.\n" +
			"- Battle: The members of the checked combatant's battle group.\n" +
			"- Group: All members of the checked combatant's group.\n" +
			"When checking the group or battle group, 'Is Dead' is valid if all members are dead, " +
			"not 'Is Dead' is valid if at least one member is still alive.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MenuCombatantScope deadScope = MenuCombatantScope.Current;


		// equipment
		[ORKEditorHelp("Is Equipped", "The equipment must be equipped on the combatant.\n" +
			"If disabled, the equipment mustn't be equipped.", "")]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded", "statusNeeded", "statusNeeded"},
			new System.Object[] {StatusNeeded.Weapon, StatusNeeded.Armor,
				StatusNeeded.WeaponItemType, StatusNeeded.ArmorItemType},
			needed=Needed.One, endCheckGroup=true)]
		public bool isEquipped = true;


		// class
		[ORKEditorHelp("Is Class", "The combatant must be the selected combatant.\n" +
			"If disabled, the combatant mustn't be the selected combatant.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Class, endCheckGroup=true)]
		public bool isClass = true;


		// combatant type
		[ORKEditorHelp("Is Combatant Type", "The combatant must be the selected combatant type.\n" +
			"If disabled, the combatant mustn't be the selected combatant type.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.CombatantType, endCheckGroup=true)]
		public bool isCombatantType = true;


		// combatant
		[ORKEditorHelp("Is Combatant", "The combatant must be the selected combatant.\n" +
			"If disabled, the combatant mustn't be the selected combatant.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Combatant)]
		public bool isCombatant = true;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be checked:\n" +
			"- Current: The combatant that is checked.\n" +
			"- Battle: The members of the checked combatant's battle group.\n" +
			"- Group: All members of the checked combatant's group.\n" +
			"When checking the group or battle group, " +
			"'Is Combatant' is valid if at least one member is the selected combatant, " +
			"not 'Is Combatant' is valid if no member is the selected combatant.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;


		// group leader
		[ORKEditorHelp("Is Leader", "The combatant must be the leader of his group.\n" +
			"If disabled, the combatant mustn't be the leader of his group.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.GroupLeader, endCheckGroup=true)]
		public bool isLeader = true;


		// group size
		[ORKEditorHelp("Check Battle Group", "Check the battle group size.\n" +
			"If disabled, the whole group size (i.e. all members) will be checked.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.GroupSize)]
		public bool battleGroup = true;

		[ORKEditorHelp("Comparison", "The group size is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck groupSizeComparison = ValueCheck.IsEqual;

		[ORKEditorHelp("Group Size", "The value that will be used for the comparison.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int groupSize = 0;


		// inventory
		[ORKEditorLayout("statusNeeded", StatusNeeded.Inventory, autoInit=true)]
		public ItemGain itemCheck;

		[ORKEditorHelp("In Inventory", "If enabled, the defined item, weapon, armor or currency " +
			"must be in the combatant's inventory.\n" +
			"If disabled, it mustn't be in the inventory.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool inInventory = true;


		// in battle
		[ORKEditorHelp("Is In Battle", "The combatant must be in battle.\n" +
			"If disabled, the combatant mustn't be in battle.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.InBattle, endCheckGroup=true)]
		public bool isInBattle = true;


		// in action
		[ORKEditorHelp("Is In Action", "The combatant must be in action (e.g. performing an ability).\n" +
			"If disabled, the combatant mustn't be in action.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.InAction, endCheckGroup=true)]
		public bool isInAction = true;


		// is casting
		[ORKEditorHelp("Is Casting", "The combatant must be casting an ability.\n" +
			"If disabled, the combatant mustn't be casting an ability.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.IsCasting, endCheckGroup=true)]
		public bool isCasting = true;


		// is choosing
		[ORKEditorHelp("Is Choosing", "The combatant must be choosing an action (e.g. when the battle menu is displayed).\n" +
			"If disabled, the combatant mustn't be choosing an action.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.IsChoosing, endCheckGroup=true)]
		public bool isChoosing = true;


		// turn ended
		[ORKEditorHelp("Turn State", "Select the turn state that will be checked for:\n" +
			"- Before Turn: The combatant is waiting to perform a new turn.\n" +
			"- In Turn: The combatant is currently performing the turn.\n" +
			"- After Turn: The combatant ended the turn.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.TurnState)]
		public CombatantTurnState turnState = CombatantTurnState.AfterTurn;

		[ORKEditorHelp("Is Valid", "The combatant's turn state must be valid (i.e. match the defined state).\n" +
			"If disabled, the combatant's turn state mustn't be valid (i.e. not match the defined state).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool isTurnStateValid = true;


		// grid move range
		[ORKEditorHelp("Max Grid Move Range", "Check the combatant's maximum grid move range.\n" +
			"If disabled, the current grid move range will be checked.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.GridMoveRange, endCheckGroup=true)]
		public bool maxGridMoveRange = false;


		// research tree
		[ORKEditorHelp("Research Tree State", "Select the state that will be checked:\n" +
			"- Known: The combatant must know the research tree.\n" +
			"- Unknown: The combatant mustn't know the research tree.\n" +
			"- Complete: The combatant must know the research tree and fully researched all research items.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.ResearchTree, endCheckGroup=true)]
		public ResearchTreeStateCheck researchTreeState = ResearchTreeStateCheck.Known;


		// research item
		[ORKEditorHelp("Research Item", "Select the research item that will be checked.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="statusNeeded", idFieldName="selectionID")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.ResearchItem)]
		public int researchItem = 0;

		[ORKEditorHelp("Check Research Count", "Check how often the research item has been researched.\n" +
			"If disabled, the state of the research item will be checked.", "")]
		public bool checkResearchCount = false;

		[ORKEditorHelp("Comparison", "The research count is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("checkResearchCount", true)]
		public ValueCheck researchCountComparison = ValueCheck.IsEqual;

		[ORKEditorHelp("Research Count", "The value that will be used for the comparison.", "")]
		public int researchCount = 0;

		[ORKEditorHelp("Research Item State", "Select the state that will be checked for:\n" +
			"- Unresearched: The research item hasn't yet been researched.\n" +
			"- In Research: The research item is currently in research.\n" +
			"- Researched: The research item has been researched (at least once).\n" +
			"- Complete: The research item has been fully researched (i.e. reached the limit).", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public ResearchItemState researchItemState = ResearchItemState.Unresearched;


		// AI
		[ORKEditorHelp("Is Equipped", "The AI type/behaviour/ruleset must be equipped in one of the combatant's AI slots.\n" +
			"If disabled, the Ai type/behaviour/ruleset mustn't be equipped.", "")]
		[ORKEditorLayout(new string[] { "statusNeeded", "statusNeeded", "statusNeeded" },
			new System.Object[] { StatusNeeded.AIType, StatusNeeded.AIBehaviour, StatusNeeded.AIRuleset },
			needed=Needed.One, endCheckGroup=true)]
		public bool aiEquipped = true;


		// AI slot count
		[ORKEditorHelp("Comparison", "The AI behaviour/ruleset slot count is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(new string[] { "statusNeeded", "statusNeeded" },
			new System.Object[] { StatusNeeded.AIBehaviourSlotCount, StatusNeeded.AIRulesetSlotCount },
			needed=Needed.One)]
		public ValueCheck aiSlotComparison = ValueCheck.IsEqual;

		[ORKEditorHelp("Slot Count", "The value that will be used for the comparison.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int aiSlotCount = 0;

		public BaseStatusRequirement()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("knowsAbility"))
			{
				bool knows = false;
				data.Get("knowsAbility", ref knows);
				bool learned = false;
				data.Get("learned", ref learned);

				if(knows)
				{
					this.abilityCheck = learned ?
						AbilityCheckType.Learned : AbilityCheckType.Known;
					this.abilityValid = true;
				}
				else
				{
					this.abilityCheck = AbilityCheckType.Known;
					this.abilityValid = false;
				}
			}
			if(data.Contains<bool>("turnEnded"))
			{
				data.Get("turnEnded", ref this.isTurnStateValid);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.statusNeeded.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckRequirement(Combatant combatant)
		{
			if(combatant != null)
			{
				if(StatusNeeded.StatusValue == this.statusNeeded)
				{
					return combatant.Status[this.selectionID].CompareTo(this.svGetValue,
						this.compareWithOther ?
							combatant.Status[this.otherStatusValueID].GetTypeValue(this.svOtherGetValue) :
							(int)this.value,
						this.comparison, this.setter);
				}
				else if(StatusNeeded.StatusEffect == this.statusNeeded)
				{
					return this.applied == combatant.Status.IsEffectSet(this.selectionID) &&
						(!this.checkStacked || ValueHelper.CheckValue(
							combatant.Status.GetStackedEffectCount(this.selectionID),
							this.stackedQuantity, this.stackComparison));
				}
				else if(StatusNeeded.StatusEffectType == this.statusNeeded)
				{
					return this.appliedEffectType == combatant.Status.IsEffectTypeSet(this.selectionID);
				}
				else if(StatusNeeded.AttackAttribute == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						combatant.Status.GetAttackAttribute(this.selectionID).
							GetTypeValue(this.selectionID2, this.attrGetValue),
						this.value, this.comparison);
				}
				else if(StatusNeeded.DefenceAttribute == this.statusNeeded)
				{
					if(this.checkDefAttrVal)
					{
						return ValueHelper.CheckValue(
							combatant.Status.GetDefenceAttribute(this.selectionID).
								GetTypeValue(this.selectionID2, this.attrGetValue),
							this.value, this.comparison);
					}
					else
					{
						return combatant.Status.GetDefenceAttributeID(this.selectionID).GetID() == this.selectionID2;
					}
				}
				else if(StatusNeeded.Ability == this.statusNeeded)
				{
					if(AbilityCheckType.Known == this.abilityCheck)
					{
						return combatant.Abilities.Has(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.Learned == this.abilityCheck)
					{
						return combatant.Abilities.HasLearned(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.GroupAbility == this.abilityCheck)
					{
						return combatant.Group.Abilities.HasLearned(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.Temporary == this.abilityCheck)
					{
						return combatant.Abilities.HasTemporary(this.selectionID, this.level) == this.abilityValid;
					}
				}
				else if(StatusNeeded.Level == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.classLevel ?
							(this.checkDefinedClassLevel ?
								combatant.GetLevelOfClass(this.classLevelID) :
								combatant.ClassLevel) :
							combatant.Level,
						this.value, this.comparison);
				}
				else if(StatusNeeded.Class == this.statusNeeded)
				{
					return (combatant.ClassID == this.selectionID) == this.isClass;
				}
				else if(StatusNeeded.CombatantType == this.statusNeeded)
				{
					return (combatant.TypeID == this.selectionID) == this.isCombatantType;
				}
				else if(StatusNeeded.Death == this.statusNeeded)
				{
					if(MenuCombatantScope.Current == this.deadScope)
					{
						return combatant.Dead == this.isDead;
					}
					else if(MenuCombatantScope.Battle == this.deadScope)
					{
						return combatant.Group.AllDeadBattle() == this.isDead;
					}
					else if(MenuCombatantScope.Group == this.deadScope)
					{
						return combatant.Group.AllDead() == this.isDead;
					}
				}
				else if(StatusNeeded.Weapon == this.statusNeeded)
				{
					return combatant.Equipment.IsEquipped(EquipSet.Weapon, this.selectionID, this.level) == this.isEquipped;
				}
				else if(StatusNeeded.Armor == this.statusNeeded)
				{
					return combatant.Equipment.IsEquipped(EquipSet.Armor, this.selectionID, this.level) == this.isEquipped;
				}
				else if(StatusNeeded.Combatant == this.statusNeeded)
				{
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						return (combatant.ID == this.selectionID) == this.isCombatant;
					}
					else if(MenuCombatantScope.Battle == this.combatantScope)
					{
						return combatant.Group.IsBattleMember(this.selectionID) == this.isCombatant;
					}
					else if(MenuCombatantScope.Group == this.combatantScope)
					{
						return combatant.Group.IsMember(this.selectionID) == this.isCombatant;
					}
				}
				else if(StatusNeeded.GroupLeader == this.statusNeeded)
				{
					return this.isLeader == combatant.IsLeader;
				}
				else if(StatusNeeded.GroupSize == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.battleGroup ? combatant.Group.BattleSize : combatant.Group.Size,
						this.groupSize, this.groupSizeComparison);
				}
				else if(StatusNeeded.Inventory == this.statusNeeded)
				{
					return this.inInventory == this.itemCheck.Has(combatant.Inventory);
				}
				else if(StatusNeeded.WeaponItemType == this.statusNeeded)
				{
					return combatant.Equipment.IsTypeEquipped(EquipSet.Weapon, this.selectionID) == this.isEquipped;
				}
				else if(StatusNeeded.ArmorItemType == this.statusNeeded)
				{
					return combatant.Equipment.IsTypeEquipped(EquipSet.Armor, this.selectionID) == this.isEquipped;
				}
				else if(StatusNeeded.InBattle == this.statusNeeded)
				{
					return combatant.Battle.InBattle == this.isInBattle;
				}
				else if(StatusNeeded.InAction == this.statusNeeded)
				{
					return (combatant.Actions.ActionState != CombatantActionState.Available) == this.isInAction;
				}
				else if(StatusNeeded.IsCasting == this.statusNeeded)
				{
					return combatant.Actions.IsCastingAbility == this.isCasting;
				}
				else if(StatusNeeded.IsChoosing == this.statusNeeded)
				{
					return combatant.Actions.IsChoosing == this.isChoosing;
				}
				else if(StatusNeeded.TurnState == this.statusNeeded)
				{
					return (combatant.Battle.TurnState == this.turnState) == this.isTurnStateValid;
				}
				else if(StatusNeeded.GridMoveRange == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.maxGridMoveRange ? combatant.Battle.GridMoveRangeMax : combatant.Battle.GridMoveRange,
						this.value, this.comparison);
				}
				else if(StatusNeeded.ResearchTree == this.statusNeeded)
				{
					return combatant.Research.CheckTreeState(this.selectionID, this.researchTreeState);
				}
				else if(StatusNeeded.ResearchItem == this.statusNeeded)
				{
					return this.checkResearchCount ?
						combatant.Research.CheckItemResearchCount(
							this.selectionID, this.researchItem, this.researchCount, this.researchCountComparison) :
						combatant.Research.CheckItemState(
							this.selectionID, this.researchItem, this.researchItemState);
				}
				else if(StatusNeeded.AIType == this.statusNeeded)
				{
					return combatant.AI.IsAITypeEquipped(this.selectionID, false) == this.aiEquipped;
				}
				else if(StatusNeeded.AIBehaviour == this.statusNeeded)
				{
					return combatant.AI.IsAIBehaviourEquipped(this.selectionID) == this.aiEquipped;
				}
				else if(StatusNeeded.AIRuleset == this.statusNeeded)
				{
					return combatant.AI.IsAIRulesetEquipped(this.selectionID) == this.aiEquipped;
				}
				else if(StatusNeeded.AIBehaviourSlotCount == this.statusNeeded)
				{
					return ValueHelper.CheckValue(combatant.AI.AIBehaviourSlot.Length,
						this.aiSlotCount, this.aiSlotComparison);
				}
				else if(StatusNeeded.AIRulesetSlotCount == this.statusNeeded)
				{
					return ValueHelper.CheckValue(combatant.AI.AIRulesetSlot.Length,
						this.aiSlotCount, this.aiSlotComparison);
				}
			}
			return false;
		}

		public bool CheckRequirementPreview(Combatant combatant)
		{
			if(combatant != null)
			{
				if(StatusNeeded.StatusValue == this.statusNeeded)
				{
					return combatant.Status[this.selectionID].CompareToPreview(
						this.compareWithOther ?
							combatant.Status[this.otherStatusValueID].GetPreviewValue(false) :
							(int)this.value,
						this.comparison, this.setter);
				}
				else if(StatusNeeded.StatusEffect == this.statusNeeded)
				{
					return this.applied == combatant.Status.IsEffectSet(this.selectionID) &&
						(!this.checkStacked || ValueHelper.CheckValue(
							combatant.Status.GetStackedEffectCount(this.selectionID),
							this.stackedQuantity, this.stackComparison));
				}
				else if(StatusNeeded.StatusEffectType == this.statusNeeded)
				{
					return this.appliedEffectType == combatant.Status.IsEffectTypeSet(this.selectionID);
				}
				else if(StatusNeeded.AttackAttribute == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						combatant.Status.GetAttackAttribute(this.selectionID).GetPreviewValue(this.selectionID2),
						this.value, this.comparison);
				}
				else if(StatusNeeded.DefenceAttribute == this.statusNeeded)
				{
					if(this.checkDefAttrVal)
					{
						return ValueHelper.CheckValue(
							combatant.Status.GetDefenceAttribute(this.selectionID).GetPreviewValue(this.selectionID2),
							this.value, this.comparison);
					}
					else
					{
						return combatant.Status.GetDefenceAttributeID(this.selectionID).GetID() == this.selectionID2;
					}
				}
				else if(StatusNeeded.Ability == this.statusNeeded)
				{
					if(AbilityCheckType.Known == this.abilityCheck)
					{
						return combatant.Abilities.Has(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.Learned == this.abilityCheck)
					{
						return combatant.Abilities.HasLearned(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.GroupAbility == this.abilityCheck)
					{
						return combatant.Group.Abilities.HasLearned(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.Temporary == this.abilityCheck)
					{
						return combatant.Abilities.HasTemporary(this.selectionID, this.level) == this.abilityValid;
					}
				}
				else if(StatusNeeded.Level == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.classLevel ?
							(this.checkDefinedClassLevel ?
								combatant.GetLevelOfClass(this.classLevelID) :
								combatant.ClassLevel) :
							combatant.Level,
						this.value, this.comparison);
				}
				else if(StatusNeeded.Class == this.statusNeeded)
				{
					return (combatant.ClassID == this.selectionID) == this.isClass;
				}
				else if(StatusNeeded.CombatantType == this.statusNeeded)
				{
					return (combatant.TypeID == this.selectionID) == this.isCombatantType;
				}
				else if(StatusNeeded.Death == this.statusNeeded)
				{
					if(MenuCombatantScope.Current == this.deadScope)
					{
						return combatant.Dead == this.isDead;
					}
					else if(MenuCombatantScope.Battle == this.deadScope)
					{
						return combatant.Group.AllDeadBattle() == this.isDead;
					}
					else if(MenuCombatantScope.Group == this.deadScope)
					{
						return combatant.Group.AllDead() == this.isDead;
					}
				}
				else if(StatusNeeded.Weapon == this.statusNeeded)
				{
					return combatant.Equipment.IsEquipped(EquipSet.Weapon, this.selectionID, this.level) == this.isEquipped;
				}
				else if(StatusNeeded.Armor == this.statusNeeded)
				{
					return combatant.Equipment.IsEquipped(EquipSet.Armor, this.selectionID, this.level) == this.isEquipped;
				}
				else if(StatusNeeded.Combatant == this.statusNeeded)
				{
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						return (combatant.ID == this.selectionID) == this.isCombatant;
					}
					else if(MenuCombatantScope.Battle == this.combatantScope)
					{
						return combatant.Group.IsBattleMember(this.selectionID) == this.isCombatant;
					}
					else if(MenuCombatantScope.Group == this.combatantScope)
					{
						return combatant.Group.IsMember(this.selectionID) == this.isCombatant;
					}
				}
				else if(StatusNeeded.GroupLeader == this.statusNeeded)
				{
					return this.isLeader == combatant.IsLeader;
				}
				else if(StatusNeeded.GroupSize == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.battleGroup ? combatant.Group.BattleSize : combatant.Group.Size,
						this.groupSize, this.groupSizeComparison);
				}
				else if(StatusNeeded.Inventory == this.statusNeeded)
				{
					return this.inInventory == this.itemCheck.Has(combatant.Inventory);
				}
				else if(StatusNeeded.WeaponItemType == this.statusNeeded)
				{
					return combatant.Equipment.IsTypeEquipped(EquipSet.Weapon, this.selectionID) == this.isEquipped;
				}
				else if(StatusNeeded.ArmorItemType == this.statusNeeded)
				{
					return combatant.Equipment.IsTypeEquipped(EquipSet.Armor, this.selectionID) == this.isEquipped;
				}
				else if(StatusNeeded.InBattle == this.statusNeeded)
				{
					return combatant.Battle.InBattle == this.isInBattle;
				}
				else if(StatusNeeded.InAction == this.statusNeeded)
				{
					return (combatant.Actions.ActionState != CombatantActionState.Available) == this.isInAction;
				}
				else if(StatusNeeded.IsCasting == this.statusNeeded)
				{
					return combatant.Actions.IsCastingAbility == this.isCasting;
				}
				else if(StatusNeeded.IsChoosing == this.statusNeeded)
				{
					return combatant.Actions.IsChoosing == this.isChoosing;
				}
				else if(StatusNeeded.TurnState == this.statusNeeded)
				{
					return (combatant.Battle.TurnState == this.turnState) == this.isTurnStateValid;
				}
				else if(StatusNeeded.GridMoveRange == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.maxGridMoveRange ? combatant.Battle.GridMoveRangeMax : combatant.Battle.GridMoveRange,
						this.value, this.comparison);
				}
				else if(StatusNeeded.ResearchTree == this.statusNeeded)
				{
					return combatant.Research.CheckTreeState(this.selectionID, this.researchTreeState);
				}
				else if(StatusNeeded.ResearchItem == this.statusNeeded)
				{
					return this.checkResearchCount ?
						combatant.Research.CheckItemResearchCount(
							this.selectionID, this.researchItem, this.researchCount, this.researchCountComparison) :
						combatant.Research.CheckItemState(
							this.selectionID, this.researchItem, this.researchItemState);
				}
				else if(StatusNeeded.AIType == this.statusNeeded)
				{
					return combatant.AI.IsAITypeEquipped(this.selectionID, false) == this.aiEquipped;
				}
				else if(StatusNeeded.AIBehaviour == this.statusNeeded)
				{
					return combatant.AI.IsAIBehaviourEquipped(this.selectionID) == this.aiEquipped;
				}
				else if(StatusNeeded.AIRuleset == this.statusNeeded)
				{
					return combatant.AI.IsAIRulesetEquipped(this.selectionID) == this.aiEquipped;
				}
				else if(StatusNeeded.AIBehaviourSlotCount == this.statusNeeded)
				{
					return ValueHelper.CheckValue(combatant.AI.AIBehaviourSlot.Length,
						this.aiSlotCount, this.aiSlotComparison);
				}
				else if(StatusNeeded.AIRulesetSlotCount == this.statusNeeded)
				{
					return ValueHelper.CheckValue(combatant.AI.AIRulesetSlot.Length,
						this.aiSlotCount, this.aiSlotComparison);
				}
			}
			return false;
		}

		public bool CheckRequirementBestiary(Combatant combatant)
		{
			if(combatant != null)
			{
				combatant.FindBestiaryEntry();

				if(StatusNeeded.StatusValue == this.statusNeeded)
				{
					if(combatant.Bestiary != null &&
						(combatant.Bestiary.IsComplete || combatant.Bestiary.status.statusValues))
					{
						return combatant.Status[this.selectionID].CompareTo(this.svGetValue,
							this.compareWithOther ?
								combatant.Status[this.otherStatusValueID].GetTypeValue(this.svOtherGetValue) :
								(int)this.value,
							this.comparison, this.setter);
					}
				}
				else if(StatusNeeded.StatusEffect == this.statusNeeded)
				{
					return this.applied == combatant.Status.IsEffectSet(this.selectionID) &&
						(!this.checkStacked || ValueHelper.CheckValue(
							combatant.Status.GetStackedEffectCount(this.selectionID),
							this.stackedQuantity, this.stackComparison));
				}
				else if(StatusNeeded.StatusEffectType == this.statusNeeded)
				{
					return this.appliedEffectType == combatant.Status.IsEffectTypeSet(this.selectionID);
				}
				else if(StatusNeeded.AttackAttribute == this.statusNeeded)
				{
					if(combatant.Bestiary != null &&
						(combatant.Bestiary.IsComplete ||
						combatant.Bestiary.status.attackAttribute[this.selectionID].attribute[this.selectionID2]))
					{
						return ValueHelper.CheckValue(
							combatant.Status.GetAttackAttribute(this.selectionID).
								GetTypeValue(this.selectionID2, this.attrGetValue),
							this.value, this.comparison);
					}
				}
				else if(StatusNeeded.DefenceAttribute == this.statusNeeded)
				{
					if(combatant.Bestiary != null)
					{
						if(this.checkDefAttrVal)
						{
							if(combatant.Bestiary.IsComplete ||
								combatant.Bestiary.status.defenceAttribute[this.selectionID].attribute[this.selectionID2])
							{
								return ValueHelper.CheckValue(
									combatant.Status.GetDefenceAttribute(this.selectionID).
										GetTypeValue(this.selectionID2, this.attrGetValue),
									this.value, this.comparison);
							}
						}
						else if(combatant.Bestiary.IsComplete ||
							combatant.Bestiary.status.defAttrID[this.selectionID])
						{
							return combatant.Status.GetDefenceAttributeID(this.selectionID).GetID() == this.selectionID2;
						}
					}
				}
				else if(StatusNeeded.Ability == this.statusNeeded)
				{
					if(AbilityCheckType.Known == this.abilityCheck)
					{
						return combatant.Abilities.Has(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.Learned == this.abilityCheck)
					{
						return combatant.Abilities.HasLearned(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.GroupAbility == this.abilityCheck)
					{
						return combatant.Group.Abilities.HasLearned(this.selectionID, this.level) == this.abilityValid;
					}
					else if(AbilityCheckType.Temporary == this.abilityCheck)
					{
						return combatant.Abilities.HasTemporary(this.selectionID, this.level) == this.abilityValid;
					}
				}
				else if(StatusNeeded.Level == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.classLevel ?
							(this.checkDefinedClassLevel ?
								combatant.GetLevelOfClass(this.classLevelID) :
								combatant.ClassLevel) :
							combatant.Level,
						this.value, this.comparison);
				}
				else if(StatusNeeded.Class == this.statusNeeded)
				{
					return (combatant.ClassID == this.selectionID) == this.isClass;
				}
				else if(StatusNeeded.CombatantType == this.statusNeeded)
				{
					return (combatant.TypeID == this.selectionID) == this.isCombatantType;
				}
				else if(StatusNeeded.Death == this.statusNeeded)
				{
					if(MenuCombatantScope.Current == this.deadScope)
					{
						return combatant.Dead == this.isDead;
					}
					else if(MenuCombatantScope.Battle == this.deadScope)
					{
						return combatant.Group.AllDeadBattle() == this.isDead;
					}
					else if(MenuCombatantScope.Group == this.deadScope)
					{
						return combatant.Group.AllDead() == this.isDead;
					}
				}
				else if(StatusNeeded.Weapon == this.statusNeeded)
				{
					if(combatant.Bestiary != null &&
						(combatant.Bestiary.IsComplete ||
						combatant.Bestiary.status.equipment))
					{
						return combatant.Equipment.IsEquipped(EquipSet.Weapon, this.selectionID, this.level) == this.isEquipped;
					}
				}
				else if(StatusNeeded.Armor == this.statusNeeded)
				{
					if(combatant.Bestiary != null &&
						(combatant.Bestiary.IsComplete ||
						combatant.Bestiary.status.equipment))
					{
						return combatant.Equipment.IsEquipped(EquipSet.Armor, this.selectionID, this.level) == this.isEquipped;
					}
				}
				else if(StatusNeeded.Combatant == this.statusNeeded)
				{
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						return (combatant.ID == this.selectionID) == this.isCombatant;
					}
					else if(MenuCombatantScope.Battle == this.combatantScope)
					{
						return combatant.Group.IsBattleMember(this.selectionID) == this.isCombatant;
					}
					else if(MenuCombatantScope.Group == this.combatantScope)
					{
						return combatant.Group.IsMember(this.selectionID) == this.isCombatant;
					}
				}
				else if(StatusNeeded.GroupLeader == this.statusNeeded)
				{
					return this.isLeader == combatant.IsLeader;
				}
				else if(StatusNeeded.GroupSize == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.battleGroup ? combatant.Group.BattleSize : combatant.Group.Size,
						this.groupSize, this.groupSizeComparison);
				}
				else if(StatusNeeded.Inventory == this.statusNeeded)
				{
					return this.inInventory == this.itemCheck.Has(combatant.Inventory);
				}
				else if(StatusNeeded.WeaponItemType == this.statusNeeded)
				{
					if(combatant.Bestiary != null &&
						(combatant.Bestiary.IsComplete ||
						combatant.Bestiary.status.equipment))
					{
						return combatant.Equipment.IsTypeEquipped(EquipSet.Weapon, this.selectionID) == this.isEquipped;
					}
				}
				else if(StatusNeeded.ArmorItemType == this.statusNeeded)
				{
					if(combatant.Bestiary != null &&
						(combatant.Bestiary.IsComplete ||
						combatant.Bestiary.status.equipment))
					{
						return combatant.Equipment.IsTypeEquipped(EquipSet.Armor, this.selectionID) == this.isEquipped;
					}
				}
				else if(StatusNeeded.InBattle == this.statusNeeded)
				{
					return combatant.Battle.InBattle == this.isInBattle;
				}
				else if(StatusNeeded.InAction == this.statusNeeded)
				{
					return (combatant.Actions.ActionState != CombatantActionState.Available) == this.isInAction;
				}
				else if(StatusNeeded.IsCasting == this.statusNeeded)
				{
					return combatant.Actions.IsCastingAbility == this.isCasting;
				}
				else if(StatusNeeded.IsChoosing == this.statusNeeded)
				{
					return combatant.Actions.IsChoosing == this.isChoosing;
				}
				else if(StatusNeeded.TurnState == this.statusNeeded)
				{
					return (combatant.Battle.TurnState == this.turnState) == this.isTurnStateValid;
				}
				else if(StatusNeeded.GridMoveRange == this.statusNeeded)
				{
					return ValueHelper.CheckValue(
						this.maxGridMoveRange ? combatant.Battle.GridMoveRangeMax : combatant.Battle.GridMoveRange,
						this.value, this.comparison);
				}
				else if(StatusNeeded.ResearchTree == this.statusNeeded)
				{
					return combatant.Research.CheckTreeState(this.selectionID, this.researchTreeState);
				}
				else if(StatusNeeded.ResearchItem == this.statusNeeded)
				{
					return this.checkResearchCount ?
						combatant.Research.CheckItemResearchCount(
							this.selectionID, this.researchItem, this.researchCount, this.researchCountComparison) :
						combatant.Research.CheckItemState(
							this.selectionID, this.researchItem, this.researchItemState);
				}
				else if(StatusNeeded.AIType == this.statusNeeded)
				{
					return combatant.AI.IsAITypeEquipped(this.selectionID, false) == this.aiEquipped;
				}
				else if(StatusNeeded.AIBehaviour == this.statusNeeded)
				{
					return combatant.AI.IsAIBehaviourEquipped(this.selectionID) == this.aiEquipped;
				}
				else if(StatusNeeded.AIRuleset == this.statusNeeded)
				{
					return combatant.AI.IsAIRulesetEquipped(this.selectionID) == this.aiEquipped;
				}
				else if(StatusNeeded.AIBehaviourSlotCount == this.statusNeeded)
				{
					return ValueHelper.CheckValue(combatant.AI.AIBehaviourSlot.Length,
						this.aiSlotCount, this.aiSlotComparison);
				}
				else if(StatusNeeded.AIRulesetSlotCount == this.statusNeeded)
				{
					return ValueHelper.CheckValue(combatant.AI.AIRulesetSlot.Length,
						this.aiSlotCount, this.aiSlotComparison);
				}
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public void RegisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			if(combatant != null)
			{
				if(StatusNeeded.StatusValue == this.statusNeeded)
				{
					StatusValue sv = combatant.Status[this.selectionID];
					sv.Changed += notify.StatusValueChanged;
					if(sv.IsConsumable())
					{
						combatant.Status[sv.Setting.maxStatusID].Changed += notify.StatusValueChanged;
					}
				}
				else if(StatusNeeded.StatusEffect == this.statusNeeded ||
					StatusNeeded.StatusEffectType == this.statusNeeded)
				{
					combatant.Status.StatusEffectChanged += notify.StatusEffectChanged;
				}
				else if(StatusNeeded.AttackAttribute == this.statusNeeded)
				{
					combatant.Status.GetAttackAttribute(this.selectionID).Changed += notify.AttackAttributeChanged;
				}
				else if(StatusNeeded.DefenceAttribute == this.statusNeeded)
				{
					if(this.checkDefAttrVal)
					{
						combatant.Status.GetDefenceAttribute(this.selectionID).Changed += notify.DefenceAttributeChanged;
					}
					else
					{
						combatant.Status.GetDefenceAttributeID(this.selectionID).Changed += notify.DefenceAttributeIDChanged;
					}
				}
				else if(StatusNeeded.Ability == this.statusNeeded)
				{
					combatant.Abilities.AbilitiesChanged += notify.AbilitiesChanged;
				}
				else if(StatusNeeded.Level == this.statusNeeded)
				{
					if(this.classLevel)
					{
						combatant.ClassLevelChanged += notify.ClassLevelChanged;
					}
					else
					{
						combatant.LevelChanged += notify.LevelChanged;
					}
				}
				else if(StatusNeeded.Class == this.statusNeeded)
				{
					combatant.ClassChanged += notify.ClassChanged;
				}
				else if(StatusNeeded.Weapon == this.statusNeeded ||
					StatusNeeded.Armor == this.statusNeeded ||
					StatusNeeded.WeaponItemType == this.statusNeeded ||
					StatusNeeded.ArmorItemType == this.statusNeeded)
				{
					combatant.Equipment.Changed += notify.EquipmentChanged;
				}
				else if(StatusNeeded.GroupLeader == this.statusNeeded)
				{
					combatant.GroupChanged += notify.CombatantGroupChanged;
				}
				else if(StatusNeeded.GroupSize == this.statusNeeded)
				{
					combatant.GroupChanged += notify.CombatantGroupChanged;
				}
				else if(StatusNeeded.Inventory == this.statusNeeded)
				{
					combatant.InventoryChanged += notify.CombatantInventoryChanged;
				}
				else if(StatusNeeded.InBattle == this.statusNeeded)
				{
					combatant.Battle.BattleStateChanged += notify.CombatantBattleStateChanged;
				}
				else if(StatusNeeded.InAction == this.statusNeeded)
				{
					combatant.Actions.ActionStateChanged += notify.CombatantActionStateChanged;
				}
				else if(StatusNeeded.IsCasting == this.statusNeeded)
				{
					combatant.Actions.CastingStateChanged += notify.CombatantCastingStateChanged;
				}
				else if(StatusNeeded.IsChoosing == this.statusNeeded)
				{
					combatant.Actions.ChoosingStateChanged += notify.CombatantChoosingStateChanged;
				}
				else if(StatusNeeded.TurnState == this.statusNeeded)
				{
					combatant.Battle.TurnStateChanged += notify.CombatantTurnStateChanged;
				}
				else if(StatusNeeded.GridMoveRange == this.statusNeeded)
				{
					combatant.Battle.GridMoveRangeChanged += notify.CombatantGridMoveRangeChanged;
				}
				else if(StatusNeeded.ResearchTree == this.statusNeeded ||
					StatusNeeded.ResearchItem == this.statusNeeded)
				{
					combatant.Research.Changed += notify.CombatantResearchChanged;
				}
				else if(StatusNeeded.AIType == this.statusNeeded ||
					StatusNeeded.AIBehaviour == this.statusNeeded ||
					StatusNeeded.AIRuleset == this.statusNeeded ||
					StatusNeeded.AIBehaviourSlotCount == this.statusNeeded ||
					StatusNeeded.AIRulesetSlotCount == this.statusNeeded)
				{
					combatant.AI.Changed += notify.CombatantAIChanged;
				}
			}
		}

		public void UnregisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			if(combatant != null)
			{
				if(StatusNeeded.StatusValue == this.statusNeeded)
				{
					StatusValue sv = combatant.Status[this.selectionID];
					sv.Changed -= notify.StatusValueChanged;
					if(sv.IsConsumable())
					{
						combatant.Status[sv.Setting.maxStatusID].Changed -= notify.StatusValueChanged;
					}
				}
				else if(StatusNeeded.StatusEffect == this.statusNeeded ||
					StatusNeeded.StatusEffectType == this.statusNeeded)
				{
					combatant.Status.StatusEffectChanged -= notify.StatusEffectChanged;
				}
				else if(StatusNeeded.AttackAttribute == this.statusNeeded)
				{
					combatant.Status.GetAttackAttribute(this.selectionID).Changed -= notify.AttackAttributeChanged;
				}
				else if(StatusNeeded.DefenceAttribute == this.statusNeeded)
				{
					if(this.checkDefAttrVal)
					{
						combatant.Status.GetDefenceAttribute(this.selectionID).Changed -= notify.DefenceAttributeChanged;
					}
					else
					{
						combatant.Status.GetDefenceAttributeID(this.selectionID).Changed -= notify.DefenceAttributeIDChanged;
					}
				}
				else if(StatusNeeded.Ability == this.statusNeeded)
				{
					combatant.Abilities.AbilitiesChanged -= notify.AbilitiesChanged;
				}
				else if(StatusNeeded.Level == this.statusNeeded)
				{
					if(this.classLevel)
					{
						combatant.ClassLevelChanged -= notify.ClassLevelChanged;
					}
					else
					{
						combatant.LevelChanged -= notify.LevelChanged;
					}
				}
				else if(StatusNeeded.Class == this.statusNeeded)
				{
					combatant.ClassChanged -= notify.ClassChanged;
				}
				else if(StatusNeeded.Weapon == this.statusNeeded ||
					StatusNeeded.Armor == this.statusNeeded ||
					StatusNeeded.WeaponItemType == this.statusNeeded ||
					StatusNeeded.ArmorItemType == this.statusNeeded)
				{
					combatant.Equipment.Changed -= notify.EquipmentChanged;
				}
				else if(StatusNeeded.GroupLeader == this.statusNeeded)
				{
					combatant.GroupChanged -= notify.CombatantGroupChanged;
				}
				else if(StatusNeeded.GroupSize == this.statusNeeded)
				{
					combatant.GroupChanged -= notify.CombatantGroupChanged;
				}
				else if(StatusNeeded.Inventory == this.statusNeeded)
				{
					combatant.InventoryChanged -= notify.CombatantInventoryChanged;
				}
				else if(StatusNeeded.InBattle == this.statusNeeded)
				{
					combatant.Battle.BattleStateChanged -= notify.CombatantBattleStateChanged;
				}
				else if(StatusNeeded.InAction == this.statusNeeded)
				{
					combatant.Actions.ActionStateChanged -= notify.CombatantActionStateChanged;
				}
				else if(StatusNeeded.IsCasting == this.statusNeeded)
				{
					combatant.Actions.CastingStateChanged -= notify.CombatantCastingStateChanged;
				}
				else if(StatusNeeded.IsChoosing == this.statusNeeded)
				{
					combatant.Actions.ChoosingStateChanged -= notify.CombatantChoosingStateChanged;
				}
				else if(StatusNeeded.TurnState == this.statusNeeded)
				{
					combatant.Battle.TurnStateChanged -= notify.CombatantTurnStateChanged;
				}
				else if(StatusNeeded.GridMoveRange == this.statusNeeded)
				{
					combatant.Battle.GridMoveRangeChanged -= notify.CombatantGridMoveRangeChanged;
				}
				else if(StatusNeeded.ResearchTree == this.statusNeeded ||
					StatusNeeded.ResearchItem == this.statusNeeded)
				{
					combatant.Research.Changed -= notify.CombatantResearchChanged;
				}
				else if(StatusNeeded.AIType == this.statusNeeded ||
					StatusNeeded.AIBehaviour == this.statusNeeded ||
					StatusNeeded.AIRuleset == this.statusNeeded ||
					StatusNeeded.AIBehaviourSlotCount == this.statusNeeded ||
					StatusNeeded.AIRulesetSlotCount == this.statusNeeded)
				{
					combatant.AI.Changed -= notify.CombatantAIChanged;
				}
			}
		}
	}
}
