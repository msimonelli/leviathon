
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LookAtSettings : BaseData
	{
		[ORKEditorHelp("Enable", "Use this 'look at' action.", "")]
		public bool enable = false;

		[ORKEditorHelp("Time (s)", "The time in seconds this look at will be active.\n" +
			"Set to 0 if you don't want the look at to end automatically.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("enable", true)]
		public float time = 0;

		[ORKEditorHelp("Chance (%)", "The chance this look at action will be used.\n" +
			"The target will be used if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) " +
			"is less or equal to chance defined here.", "")]
		public float chance = 100;

		[ORKEditorHelp("Look At Type", "Select how the look at action will be performed:\n" +
			"- Simple Look: The camera will simply look at the target.\n" +
			"- Camera Position: A camera position will be used.\n" +
			"- Camera Control Target: Changes the camera control target.", "")]
		public CameraLookAtType type = CameraLookAtType.CameraPosition;

		[ORKEditorHelp("Look At Child", "The camera will look at the defined child object " +
			"(e.g. Path/to/Child) of the target.\n" +
			"If the child object can't be found, the target object itself is used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string pathToChild = "";


		// conditions
		[ORKEditorInfo(separator=true)]
		public LookAtRequirement requirement = new LookAtRequirement();


		// camera position
		[ORKEditorInfo(separator=true)]
		[ORKEditorArray(false, "Add Camera Position", "Adds a camera position to this 'look at' action.\n" +
			"You can add as much camera positions per target as you want, the used camera position is chosen randomly.", "",
			"Remove", "Removes the camera position", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Camera Position", "Define the used camera position and if the camera should rotate around the target.", ""})]
		[ORKEditorLayout("type", CameraLookAtType.CameraPosition, endCheckGroup=true, endGroups=2)]
		public CamPosRotation[] camPos = new CamPosRotation[0];


		// camera control target
		[ORKEditorHelp("Reset Current Target", "If the new target is already the camera control target, the camera control will reset.\n" +
			"This will trigger a transition based on the distance between the target and the camera and " +
			"call the 'CameraTargetChanged' function of the camera control (must be descending from 'BaseCameraContrl').", "")]
		[ORKEditorInfo(separator=true, labelText="Transition Settings")]
		[ORKEditorLayout("type", CameraLookAtType.CameraControlTarget)]
		public bool cameraControlTargetReset = false;

		[ORKEditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		public bool ownControlTargetTransition = false;

		[ORKEditorLayout("ownControlTargetTransition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public CameraControlTargetTransition controlTargetTransition;


		// ingame
		private int index = 0;

		private Transform target = null;

		public LookAtSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("simpleLook"))
			{
				bool tmp = false;
				data.Get("simpleLook", ref tmp);
				if(tmp)
				{
					this.type = CameraLookAtType.SimpleLook;
				}
			}
		}

		public bool IsSimpleLook
		{
			get { return CameraLookAtType.SimpleLook == this.type; }
		}

		public bool IsCameraPosition
		{
			get { return CameraLookAtType.CameraPosition == this.type; }
		}

		public bool IsCameraControlTarget
		{
			get { return CameraLookAtType.CameraControlTarget == this.type; }
		}

		public bool CheckTarget(Camera camera, Transform user, Transform target)
		{
			return this.enable &&
				this.target != target &&
				ORK.GameSettings.CheckRandom(this.chance) && 
				this.requirement.Check(camera, user, target);
		}

		public bool SetTarget(Transform camera, Transform target, ref float timeout)
		{
			this.Target = target;
			if(this.target != null)
			{
				if(this.time > 0)
				{
					timeout = this.time;
				}
				return this.Set(camera);
			}
			return false;
		}

		public Transform Target
		{
			get { return this.target; }
			set
			{
				if(this.target != value)
				{
					this.target = value;

					if(this.target != null &&
						this.pathToChild != "")
					{
						this.target = TransformHelper.GetChild(this.pathToChild, this.target);
					}
				}
			}
		}

		public bool Set(Transform camera)
		{
			if(this.target != null)
			{
				if(this.IsCameraPosition)
				{
					if(this.camPos.Length > 0)
					{
						this.index = Random.Range(0, this.camPos.Length);
						ORK.CameraPositions.Get(this.camPos[this.index].camPosID).Use(camera, this.target);
						return true;
					}
				}
				else if(this.IsCameraControlTarget)
				{
					if(!ORK.Control.SetCameraControlTarget(this.target.gameObject,
							this.ownControlTargetTransition ? this.controlTargetTransition : null) &&
						this.cameraControlTargetReset)
					{
						ORK.Control.ResetCameraControlTarget(
							this.ownControlTargetTransition ? this.controlTargetTransition : null);
					}
					return true;
				}
			}
			return false;
		}

		public bool CheckCamPos()
		{
			if(this.IsCameraPosition)
			{
				return this.camPos.Length > 0 &&
					this.index < this.camPos.Length;
			}
			return true;
		}

		public void Rotate(Transform camera)
		{
			if(this.IsCameraPosition)
			{
				this.camPos[this.index].Rotate(camera, this.target.position);
			}
		}
	}
}

