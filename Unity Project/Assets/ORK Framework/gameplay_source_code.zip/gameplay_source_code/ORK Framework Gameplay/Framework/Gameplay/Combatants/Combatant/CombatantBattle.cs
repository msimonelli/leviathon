﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantBattle
	{
		private Combatant owner;


		// states
		private bool inBattle = false;

		private bool isDefending = false;

		private bool enableAutoAttack = true;

		private bool itemStolen = false;

		private bool moneyStolen = false;

		private GridMoveState gridMoveState = GridMoveState.Available;


		// turn
		private CombatantTurnState turnState = CombatantTurnState.BeforeTurn;

		private int currentTurn = 0;

		private float turnValue = 0;

		private float turnValueDummy = 0;

		private int lastTurnIndex = -1;

		private bool receiveActionsPerTurn = false;

		private AllowTurnControl turnControlAllowed = AllowTurnControl.None;

		private AllowTurnControl turnCameraControlAllowed = AllowTurnControl.None;


		// actions
		private bool timeBarRunning = true;

		private float actionBar = 0;

		private float usedActionBar = 0;

		private float delayTime = 0;

		private float delayTimeMax = 0;


		// action time
		private bool actionTimeRunning = false;

		private float actionTime = 0;

		private float actionTimeMax = 0;


		// grid
		private float gridMoveRange = 0;

		private float gridMoveRangeMax = 0;


		// blocks/temporary
		private List<UseBlock> reuseBlock = new List<UseBlock>();

		private List<RemoveTemporaryAbility> removeTemporaryAbility = new List<RemoveTemporaryAbility>();


		// targets
		private List<Combatant> lastTargets = new List<Combatant>();

		private List<Combatant> attackedByCombatant = new List<Combatant>();

		private List<int> attackedByFaction = new List<int>();

		public CombatantBattle(Combatant owner)
		{
			this.owner = owner;
		}


		/*
		============================================================================
		Event handler functions
		============================================================================
		*/
		private CombatantChanged gridMoveRangeChangeHandler;
		public event CombatantChanged GridMoveRangeChanged
		{
			add { this.gridMoveRangeChangeHandler += value; }
			remove { this.gridMoveRangeChangeHandler -= value; }
		}

		private CombatantChanged battleStateChangedHandler;
		public event CombatantChanged BattleStateChanged
		{
			add { this.battleStateChangedHandler += value; }
			remove { this.battleStateChangedHandler -= value; }
		}

		private CombatantChanged turnStateChangeHandler;
		public event CombatantChanged TurnStateChanged
		{
			add { this.turnStateChangeHandler += value; }
			remove { this.turnStateChangeHandler -= value; }
		}

		/// <summary>
		/// Notifies all battle state change listeners that the battle state changed.
		/// </summary>
		public void FireBattleStateChanged()
		{
			if(this.battleStateChangedHandler != null)
			{
				this.battleStateChangedHandler(this.owner);
			}
		}


		/*
		============================================================================
		State properties
		============================================================================
		*/
		public bool InBattle
		{
			get { return this.inBattle; }
		}

		public bool Defending
		{
			get { return this.isDefending; }
			set { this.isDefending = value; }
		}

		public bool EnableAutoAttack
		{
			get { return this.enableAutoAttack; }
			set { this.enableAutoAttack = value; }
		}

		public bool ItemStolen
		{
			get { return this.itemStolen; }
			set { this.itemStolen = value; }
		}

		public bool MoneyStolen
		{
			get { return this.moneyStolen; }
			set { this.moneyStolen = value; }
		}

		public CombatantTurnState TurnState
		{
			get { return this.turnState; }
			set
			{
				if(this.turnState != value)
				{
					this.turnState = value;

					if(this.turnStateChangeHandler != null)
					{
						this.turnStateChangeHandler(this.owner);
					}
				}
			}
		}

		public AllowTurnControl TurnControlAllowed
		{
			get { return this.turnControlAllowed; }
			set { this.turnControlAllowed = value; }
		}

		public AllowTurnControl TurnCameraControlAllowed
		{
			get { return this.turnCameraControlAllowed; }
			set { this.turnCameraControlAllowed = value; }
		}

		public bool ReceiveActionsPerTurn
		{
			get { return this.receiveActionsPerTurn; }
			set { this.receiveActionsPerTurn = value; }
		}

		public GridMoveState GridMoveState
		{
			get { return this.gridMoveState; }
			set { this.gridMoveState = value; }
		}


		/*
		============================================================================
		Value properties
		============================================================================
		*/
		public int LastTurnIndex
		{
			get { return this.lastTurnIndex; }
			set { this.lastTurnIndex = value; }
		}

		public int Turn
		{
			get { return this.currentTurn; }
		}

		public float TurnValue
		{
			get { return this.turnValue; }
			set
			{
				if(this.turnValue != value)
				{
					this.turnValue = value;
					this.owner.MarkHUDUpdate();
				}
			}
		}

		public float TurnValueDummy
		{
			get { return this.turnValueDummy; }
			set { this.turnValueDummy = value; }
		}

		public bool TimeBarRunning
		{
			get { return this.timeBarRunning; }
			set { this.timeBarRunning = value; }
		}

		public float ActionBar
		{
			get { return this.actionBar; }
			set
			{
				if(this.actionBar != value)
				{
					this.actionBar = value;
					if(this.actionBar < 0)
					{
						this.actionBar = 0;
					}
					if(this.usedActionBar > this.actionBar)
					{
						this.usedActionBar = this.actionBar;
					}
					this.owner.MarkHUDUpdate();
				}
			}
		}

		public float UsedActionBar
		{
			get { return this.usedActionBar; }
			set
			{
				if(this.usedActionBar != value)
				{
					this.usedActionBar = value;
					if(this.usedActionBar < 0)
					{
						this.usedActionBar = 0;
					}
					this.owner.MarkHUDUpdate();
				}
			}
		}

		public float DelayTime
		{
			get { return this.delayTime; }
			set
			{
				if(this.delayTime != value)
				{
					this.delayTime = value;
					if(this.delayTime < 0)
					{
						this.delayTime = 0;
					}
					this.delayTimeMax = this.delayTime;
					this.owner.MarkHUDUpdate();
				}
			}
		}

		public float DelayTimeMax
		{
			get { return this.delayTimeMax; }
		}

		public bool ActionTimeRunning
		{
			get { return this.actionTimeRunning; }
			set { this.actionTimeRunning = value; }
		}

		public float ActionTime
		{
			get { return this.actionTime; }
			set
			{
				this.actionTime = value;
				if(this.actionTime < 0)
				{
					this.actionTime = 0;
				}
				if(this.actionTime > this.actionTimeMax)
				{
					this.actionTimeMax = this.actionTime;
				}
				this.owner.MarkHUDUpdate();
			}
		}

		public float ActionTimeMax
		{
			get { return this.actionTimeMax; }
		}

		public void InitActionTime(float time, bool keepUnusedTime)
		{
			if(keepUnusedTime)
			{
				this.actionTime += time;
			}
			else
			{
				this.actionTime = time;
			}
			if(this.actionTime < 0)
			{
				this.actionTime = 0;
			}
			this.actionTimeMax = this.actionTime;
			this.owner.MarkHUDUpdate();
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public List<Combatant> LastTargets
		{
			get
			{
				return this.lastTargets;
			}
			set
			{
				this.lastTargets.Clear();
				if(value != null)
				{
					this.lastTargets.AddRange(value);
				}
			}
		}

		public void SetAttackedBy(Combatant c, bool addFaction)
		{
			if(!this.attackedByCombatant.Contains(c))
			{
				this.attackedByCombatant.Add(c);
			}
			if(addFaction && !this.attackedByFaction.Contains(c.Group.FactionID))
			{
				this.attackedByFaction.Add(c.Group.FactionID);
			}
		}

		public List<Combatant> GetAttackedBy()
		{
			return this.attackedByCombatant;
		}

		public void ClearAttackedBy()
		{
			this.attackedByCombatant.Clear();
			this.attackedByFaction.Clear();
		}

		public bool CheckAttackedByFaction(int factionID)
		{
			return this.attackedByFaction.Contains(factionID);
		}


		/*
		============================================================================
		Grid functions
		============================================================================
		*/
		public float GridMoveRange
		{
			get { return this.gridMoveRange; }
			set
			{
				if(this.gridMoveRange != value)
				{
					this.gridMoveRange = value;
					if(this.gridMoveRange > this.gridMoveRangeMax)
					{
						this.gridMoveRange = this.gridMoveRangeMax;
					}

					this.owner.MarkHUDUpdate();
					if(this.gridMoveRangeChangeHandler != null)
					{
						this.gridMoveRangeChangeHandler(this.owner);
					}
				}
			}
		}

		public float GridMoveRangeMax
		{
			get { return this.gridMoveRangeMax; }
			set
			{
				if(this.gridMoveRangeMax != value)
				{
					this.gridMoveRangeMax = value;

					this.owner.MarkHUDUpdate();
					if(this.gridMoveRangeChangeHandler != null)
					{
						this.gridMoveRangeChangeHandler(this.owner);
					}
				}
			}
		}

		public void InitGridMoveRange()
		{
			this.GridMoveRangeMax = (this.owner.Setting.ownGridMoveRange ?
					this.owner.Setting.gridMoveRange.GetValue(this.owner, this.owner) :
					ORK.BattleSystem.gridSettings.moveCommand.moveRange.GetValue(this.owner, this.owner)) +
				this.owner.Status.GetGridMoveRangeBonus();
			this.GridMoveRange = this.GridMoveRangeMax;
			this.owner.MarkHUDUpdate();
		}

		public void ChooseGridOrientation(Notify callback, bool canCancel)
		{
			if(this.owner.Dead ||
				this.owner.Status.StopMove ||
				this.owner.Status.StopMovement)
			{
				if(callback != null)
				{
					callback();
				}
			}
			else if(this.owner.IsAIControlled())
			{
				Combatant target = null;
				if(this.owner.Setting.attackLastTarget &&
					this.LastTargets.Count > 0)
				{
					target = TargetHelper.GetNearestTarget(this.owner, this.lastTargets, Consider.No);
				}
				if(target == null)
				{
					List<Combatant> list = ORK.Game.Combatants.Get(this.owner, true,
						Range.Battle, Consider.Yes, Consider.No, Consider.Yes);
					if(this.owner.Setting.aiNearestTarget)
					{
						target = TargetHelper.GetNearestTarget(this.owner, list, Consider.No);
					}
					if(target == null)
					{
						target = TargetHelper.GetRandomTarget(list, Consider.No);
					}
				}
				if(target != null &&
					target.GameObject != null)
				{
					BattleGridHelper.RotateToPosition(this.owner, target.GameObject.transform.position);
				}
				if(callback != null)
				{
					callback();
				}
			}
			else if(this.owner.IsPlayerControlled())
			{
				ORK.BattleSystem.gridSettings.orientationSelection.Start(this.owner, null,
					delegate (bool finished)
				{
					if(callback != null)
					{
						callback();
					}
				}, canCancel);
			}
			else if(callback != null)
			{
				callback();
			}
		}


		/*
		============================================================================
		Reuse functions
		============================================================================
		*/
		public void AddUseBlock(UseBlock block)
		{
			this.reuseBlock.Add(block);
		}

		public void RemoveUseBlock(UseBlockType type, int id)
		{
			bool removed = false;
			for(int i = 0; i < this.reuseBlock.Count; i++)
			{
				if(this.reuseBlock[i].type == type &&
					this.reuseBlock[i].id == id)
				{
					this.reuseBlock.RemoveAt(i--);
					removed = true;
				}
			}
			if(removed)
			{
				this.owner.FireChanged();
			}
		}

		public bool IsReuseBlocked(UseBlockType type, int id)
		{
			for(int i = 0; i < this.reuseBlock.Count; i++)
			{
				if(this.reuseBlock[i].IsBlocked(type, id))
				{
					return true;
				}
			}
			return false;
		}

		public string GetReuseTimeText(UseBlockType type, int id, int decimals)
		{
			for(int i = 0; i < this.reuseBlock.Count; i++)
			{
				if(this.reuseBlock[i].IsBlocked(type, id))
				{
					return this.reuseBlock[i].GetReuseTimeText(decimals);
				}
			}
			return "";
		}

		public void ClearUseBlock()
		{
			this.reuseBlock.Clear();
		}

		public void ClearUseBlock(UseBlockType type)
		{
			bool removed = false;
			for(int i = 0; i < this.reuseBlock.Count; i++)
			{
				if(this.reuseBlock[i].type == type)
				{
					this.reuseBlock.RemoveAt(i--);
					removed = true;
				}
			}
			if(removed)
			{
				this.owner.FireChanged();
			}
		}


		/*
		============================================================================
		Temporary ability functions
		============================================================================
		*/
		public void AddAutoRemoveTemporaryAbility(RemoveTemporaryAbility remove)
		{
			bool found = false;
			for(int i = 0; i < this.removeTemporaryAbility.Count; i++)
			{
				if(this.removeTemporaryAbility[i].id == remove.id)
				{
					found = false;
					this.removeTemporaryAbility[i] = remove;
					break;
				}
			}
			if(!found)
			{
				this.removeTemporaryAbility.Add(remove);
			}
		}

		public void RemoveAutoRemoveTemporaryAbility(int abilityID)
		{
			for(int i = 0; i < this.removeTemporaryAbility.Count; i++)
			{
				if(this.removeTemporaryAbility[i].id == abilityID)
				{
					this.removeTemporaryAbility.RemoveAt(i);
					break;
				}
			}
		}

		public void ClearAutoRemoveTemporaryAbility()
		{
			this.removeTemporaryAbility.Clear();
		}


		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public void ClearBattle(bool start)
		{
			this.ClearAttackedBy();
			this.owner.EndBattleMenu(true);
			this.owner.Actions.Clear(start);

			this.TurnState = CombatantTurnState.BeforeTurn;
			this.ReceiveActionsPerTurn = true;
			this.ActionTimeRunning = false;
			this.itemStolen = false;
			this.moneyStolen = false;
			this.gridMoveState = GridMoveState.Available;

			this.currentTurn = 0;
			this.lastTurnIndex = -1;
			this.TurnValue = 0;
			this.ActionBar = 0;
			this.UsedActionBar = 0;
			this.DelayTime = 0;

			this.lastTargets.Clear();

			this.inBattle = start;
			this.owner.MarkResetStatus();

			if(this.owner.MoveAI != null)
			{
				this.owner.MoveAI.ClearTarget(false);
			}
			if(start)
			{
				this.InitGridMoveRange();
			}
			else
			{
				this.owner.GridCell = null;
			}

			if(this.owner.Setting.useMoveAI &&
				this.owner.Setting.useBattleMoveAI &&
				this.owner.MoveAI != null)
			{
				this.owner.MoveAI.ChangeMoveAI(start ?
					this.owner.Setting.battleMoveID :
					this.owner.MoveAI.originalMoveID);
			}

			this.owner.MarkHUDUpdate();
			this.FireBattleStateChanged();
			this.owner.SetStartEffects();
		}

		public void StartBattle()
		{
			this.ClearBattle(true);
		}

		public void EndBattle()
		{
			this.owner.BattleSpot = null;
			this.owner.Status.EndBattle();

			bool removed = false;
			for(int i = 0; i < this.reuseBlock.Count; i++)
			{
				if(this.reuseBlock[i].IsRemoveOnBattleEnd())
				{
					this.reuseBlock.RemoveAt(i--);
					removed = true;
				}
			}
			for(int i = 0; i < this.removeTemporaryAbility.Count; i++)
			{
				if(this.removeTemporaryAbility[i].IsRemoveOnBattleEnd())
				{
					this.removeTemporaryAbility[i].Remove(this.owner);
					this.removeTemporaryAbility.RemoveAt(i--);
				}
			}

			this.ClearBattle(false);

			if(removed)
			{
				this.owner.FireChanged();
			}
			else
			{
				this.owner.MarkHUDUpdate();
			}
		}

		public void Escape()
		{
			if(this.owner.Group.IsPlayerControlled())
			{
				ORK.Battle.BattleEscaped();
			}
			else
			{
				ORK.Battle.RemoveCombatant(this.owner, false);
			}
		}

		public void Death()
		{
			this.TurnValue = 0;
			this.ActionBar = 0;
			this.UsedActionBar = 0;
			this.DelayTime = 0;
			this.gridMoveState = GridMoveState.Available;

			for(int i = 0; i < this.attackedByFaction.Count; i++)
			{
				ORK.Game.Faction.MemberKilled(this.owner.Group.FactionID,
					this.attackedByFaction[i], this.owner.Setting.sympathyChange);
			}
		}

		public bool CanUse(float actionCost)
		{
			// turn based, phase > only while choosing and if actions per turn allow it
			if(ORK.Battle.IsTurnBased() ||
				ORK.Battle.IsPhase())
			{
				if(!this.owner.Actions.IsChoosing ||
					this.UsedActionBar + actionCost > this.ActionBar)
				{
					return false;
				}
			}
			// active time > only if timebar allows it
			else if(ORK.Battle.IsActiveTime())
			{
				if(this.UsedActionBar + actionCost > ORK.BattleSystem.activeTime.maxTimebar)
				{
					return false;
				}
			}
			// real time or in field > always
			return true;
		}

		public bool Tick(float battleTime)
		{
			// ability reuse
			bool removed = false;
			for(int i = 0; i < this.reuseBlock.Count; i++)
			{
				if(this.reuseBlock[i].ReduceTime(battleTime, this.owner))
				{
					this.reuseBlock.RemoveAt(i--);
					removed = true;
				}
			}
			for(int i = 0; i < this.removeTemporaryAbility.Count; i++)
			{
				if(this.removeTemporaryAbility[i].ReduceTime(battleTime))
				{
					this.removeTemporaryAbility[i].Remove(this.owner);
					this.removeTemporaryAbility.RemoveAt(i--);
				}
			}

			// delay time
			if(this.delayTime > 0)
			{
				this.delayTime -= battleTime;
				if(this.delayTime < 0)
				{
					this.delayTime = 0;
					this.delayTimeMax = 0;
				}
				this.owner.MarkHUDUpdate();
			}

			this.TickActionTime();

			return removed;
		}

		public void TickActionTime()
		{
			// action time
			if(ORK.Battle.CanDecreaseActionTime(this.owner))
			{
				this.actionTime -= ORK.Core.GUITimeDelta;
				if(this.actionTime < 0)
				{
					this.actionTime = 0;
					this.ActionTimeRunning = false;
					this.ReceiveActionsPerTurn = true;
					if(this.owner.Actions.IsChoosing)
					{
						this.EndTurnCommand(true);
					}
				}
				this.owner.MarkHUDUpdate();
			}
		}


		/*
		============================================================================
		Turn functions
		============================================================================
		*/
		public bool InitNewTurn(bool canPerform)
		{
			this.currentTurn++;
			this.gridMoveState = GridMoveState.Available;
			this.owner.MarkHUDUpdate();

			// ability blocks turn
			bool removed = false;
			for(int i = 0; i < this.reuseBlock.Count; i++)
			{
				if(this.reuseBlock[i].ReduceTurn(this.owner))
				{
					this.reuseBlock.RemoveAt(i--);
					removed = true;
				}
			}
			for(int i = 0; i < this.removeTemporaryAbility.Count; i++)
			{
				if(this.removeTemporaryAbility[i].ReduceTurn())
				{
					this.removeTemporaryAbility[i].Remove(this.owner);
					this.removeTemporaryAbility.RemoveAt(i--);
				}
			}

			this.owner.Status.CheckEffectsTurn(true);

			if(canPerform)
			{
				this.TurnState = CombatantTurnState.InTurn;
				this.owner.Actions.IsWaiting = true;
				this.isDefending = false;
				ORK.Battle.TransferPlayerControl(this.owner, false);
				ORK.Battle.AllowPlayerTurnControl(-1, this.owner, AllowTurnControl.Always);

				// turn bonuses
				ORK.Battle.TurnBonus(this.owner);

				this.InitGridMoveRange();

				if(ORK.MenuSettings.useTurnFlash && ORK.MenuSettings.hudTurnFlash != null)
				{
					this.owner.HUDStartFade(ORK.MenuSettings.hudTurnFlash, false);
				}
			}
			else
			{
				this.TurnState = CombatantTurnState.BeforeTurn;
			}

			if(removed)
			{
				this.owner.FireChanged();
			}

			return !this.owner.CheckDeath();
		}

		public void EndTurnCommand(bool isSilent)
		{
			this.owner.EndBattleMenu(false);
			this.owner.Actions.IsChoosing = false;
			this.ActionTimeRunning = false;

			if(ORK.Battle.Grid != null)
			{
				ORK.BattleSystem.gridSettings.CloseSelections(this.owner);
			}

			if(ORK.Battle.IsTurnBased() ||
				ORK.Battle.IsPhase())
			{
				this.owner.Actions.FinishedChoosing = true;
				this.owner.Actions.Add(new NoneAction(this.owner, isSilent), false);
				this.usedActionBar = this.actionBar;
			}
			else if(ORK.Battle.IsActiveTime())
			{
				this.owner.Actions.FinishedChoosing = true;
				if(this.owner.Actions.Count > 0 || this.owner.Actions.Fired)
				{
					if(!this.owner.Actions.Fired)
					{
						this.owner.Actions.DequeueNextAction();
					}
				}
				else
				{
					this.owner.Actions.Add(new NoneAction(this.owner, isSilent), false);
				}
			}
			else if(ORK.Battle.IsRealTime())
			{
				this.owner.Actions.Add(new NoneAction(this.owner, isSilent), false);
			}
		}

		/// <summary>
		/// Gets a value indicating wheter the combatant can end the turn.
		/// </summary>
		/// <value>
		/// <c>true</c> if the combatant can end the turn; otherwise, <c>false</c>.
		/// </value>
		public bool CanEndTurn
		{
			get
			{
				return (ORK.Battle.IsRealTime() || !this.owner.Actions.CanChoose) &&
					!this.owner.Actions.IsChoosing &&
					!this.owner.Actions.IsWaiting &&
					(this.owner.Actions.ActionState == CombatantActionState.Available ||
						this.owner.Actions.ActionState == CombatantActionState.EndingAction) &&
					this.owner.Actions.Count == 0;
			}
		}

		public void EndTurn(Notify callback)
		{
			this.ActionTimeRunning = false;
			this.TimeBarRunning = false;
			this.owner.Actions.FinishedChoosing = false;
			this.owner.Status.CheckEffectsTurn(false);
			ORK.Battle.AllowPlayerTurnControl(1, this.owner, AllowTurnControl.Always);
			ORK.Battle.TransferPlayerControl(this.owner, true);

			if(this.owner.TurnEndEvents.HasEvent(this.owner))
			{
				this.owner.TurnEndEvents.StartEvent(this.owner, delegate ()
				{
					this.EndTurn2(callback);
				});
			}
			else
			{
				this.EndTurn2(callback);
			}
		}

		private void EndTurn2(Notify callback)
		{
			bool done = false;

			Notify newCallback = delegate()
			{
				this.TimeBarRunning = true;
				this.TurnState = CombatantTurnState.AfterTurn;
				if(callback != null)
				{
					callback();
				}
			};

			if(ORK.Battle.IsBattleRunning() &&
				ORK.Battle.Grid != null &&
				this.owner.GridCell != null)
			{
				Notify eventCallback = delegate()
				{
					List<GridCellEventCall> cellEvents = new List<GridCellEventCall>();
					GridCellEventHandler eventHandler = new GridCellEventHandler(this.owner.GridCell, GridCellEventStartType.EndTurn);
					if(eventHandler.HasEvents)
					{
						eventHandler.Start(this.owner, callback);
					}
					else
					{
						newCallback();
					}
				};

				if(ORK.Battle.System.gridTurnEndOrientation)
				{
					done = true;
					this.ChooseGridOrientation(eventCallback, true);
				}
				else if(eventCallback != null)
				{
					done = true;
					eventCallback();
				}
			}

			if(!done)
			{
				newCallback();
			}
		}
	}
}
