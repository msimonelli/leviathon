﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate bool GridCellCheck(BattleGridCellComponent cell);

	public delegate bool GridCellOriginCheck(BattleGridCellComponent origin, BattleGridCellComponent cell);

	public static class BattleGridHelper
	{
		private static CubeCoord[] SquareDirectionsNonDiagonal = new CubeCoord[]
		{
			new CubeCoord(-1, 0, 0), new CubeCoord(0, 1, 0),
			new CubeCoord(1, 0, 0), new CubeCoord(0, -1, 0)
		};

		private static CubeCoord[] SquareDirectionsDiagonal = new CubeCoord[]
		{
			new CubeCoord(-1, 0, 0), new CubeCoord(-1, 1, 0),
			new CubeCoord(0, 1, 0), new CubeCoord(1, 1, 0),
			new CubeCoord(1, 0, 0), new CubeCoord(1, -1, 0),
			new CubeCoord(0, -1, 0), new CubeCoord(-1, -1, 0)
		};

		private static CubeCoord[] HexagonalDirections = new CubeCoord[]
		{
			new CubeCoord(0, 1, -1), new CubeCoord(1, 0, -1), new CubeCoord(1, -1, 0),
			new CubeCoord(0, -1, 1), new CubeCoord(-1, 0, 1), new CubeCoord(-1, 1, 0)
		};

		private static CubeCoord[] SquareDirections
		{
			get
			{
				if(ORK.BattleSystem.gridSettings.squareDiagonalDistanceOne)
				{
					return BattleGridHelper.SquareDirectionsDiagonal;
				}
				return BattleGridHelper.SquareDirectionsNonDiagonal;
			}
		}

		public static CubeCoord GetDirection(int direction)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				if(direction < 0)
				{
					direction += (int)(Mathf.Ceil((-direction) / (float)BattleGridHelper.SquareDirections.Length)) *
						BattleGridHelper.SquareDirections.Length;
				}
				else if(direction > BattleGridHelper.SquareDirections.Length - 1)
				{
					direction -= (int)(Mathf.Floor(direction / (float)BattleGridHelper.SquareDirections.Length)) *
						BattleGridHelper.SquareDirections.Length;
				}
				return BattleGridHelper.SquareDirections[direction];
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				if(direction < 0)
				{
					direction += (int)(Mathf.Ceil((-direction) / 6.0f)) * 6;
				}
				else if(direction > 5)
				{
					direction -= (int)(Mathf.Floor(direction / 6.0f)) * 6;
				}
				return BattleGridHelper.HexagonalDirections[direction];
			}
			return new CubeCoord(0, 0, 0);
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public static void Highlight(List<BattleGridCellComponent> list, GridHighlightType type)
		{
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						list[i].Highlight(type);
					}
				}
			}
		}

		public static void StopHighlight(List<BattleGridCellComponent> list, GridHighlightType type)
		{
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						list[i].StopHighlight(type);
					}
				}
			}
		}


		/*
		============================================================================
		Cell check functions
		============================================================================
		*/
		public static bool IsUnblockedCell(BattleGridCellComponent cell)
		{
			return cell != null && !cell.IsBlocked;
		}

		public static bool IsPassableCell(BattleGridCellComponent cell)
		{
			return cell != null && cell.IsPassable;
		}

		public static bool IsFreeCell(BattleGridCellComponent cell)
		{
			return cell != null && !cell.IsBlocked && cell.IsEmpty;
		}

		public static BattleGridCellComponent GetNearestDeploymentCell(Combatant combatant)
		{
			if(combatant != null && combatant.GameObject != null)
			{
				BattleGridCellComponent[] cells = GameObject.FindObjectsOfType<BattleGridCellComponent>();
				int nearest = -1;
				float distance = Mathf.Infinity;

				for(int i = 0; i < cells.Length; i++)
				{
					if(cells[i] != null && cells[i].enabled &&
						cells[i].gameObject.activeInHierarchy &&
						cells[i].CanDeploy(combatant))
					{
						float tmp = Vector3.Distance(combatant.GameObject.transform.position, cells[i].transform.position);
						if(tmp < distance)
						{
							nearest = i;
							distance = tmp;
						}
					}
				}

				if(nearest >= 0 && nearest < cells.Length)
				{
					return cells[nearest];
				}
			}
			return null;
		}


		/*
		============================================================================
		Get cell functions
		============================================================================
		*/
		public static BattleGridCellComponent GetCell(GameObject gameObject)
		{
			BattleGridCellComponent cell = null;
			if(gameObject != null)
			{
				cell = gameObject.GetComponentInChildren<BattleGridCellComponent>();
				if(cell == null)
				{
					CombatantComponent cc = gameObject.GetComponentInChildren<CombatantComponent>();
					if(cc != null)
					{
						cell = cc.combatant.GridCell;
					}
				}
			}
			return cell;
		}

		public static BattleGridCellComponent GetCell(List<GameObject> list)
		{
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						BattleGridCellComponent cell = BattleGridHelper.GetCell(list[i]);
						if(cell != null)
						{
							return cell;
						}
					}
				}
			}
			return null;
		}

		public static List<BattleGridCellComponent> GetCells(List<GameObject> list)
		{
			List<BattleGridCellComponent> cells = new List<BattleGridCellComponent>();
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						BattleGridCellComponent cell = BattleGridHelper.GetCell(list[i]);
						if(cell != null)
						{
							cells.Add(cell);
						}
					}
				}
			}
			return cells;
		}


		/*
		============================================================================
		Rotation functions
		============================================================================
		*/
		public static int GetCombatantDirection(Combatant combatant)
		{
			if(combatant != null &&
				combatant.GridCell != null &&
				combatant.GameObject != null)
			{
				return BattleGridHelper.AngleToDirection(
					combatant.GameObject.transform.eulerAngles.y);
			}
			return 0;
		}

		public static int AngleToDirection(float angle)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				float tmp = 360.0f / BattleGridHelper.SquareDirections.Length;
				angle += tmp / 2;
				ValueHelper.SecureRotation(ref angle);
				return (int)(angle / tmp);
			}
			else if(ORK.BattleSystem.gridSettings.IsHorizontalHex)
			{
				angle += 60.0f;
				ValueHelper.SecureRotation(ref angle);
				return (int)(angle / 60.0f);
			}
			else if(ORK.BattleSystem.gridSettings.IsVerticalHex)
			{
				angle += 30.0f;
				ValueHelper.SecureRotation(ref angle);
				return (int)(angle / 60.0f);
			}
			return 0;
		}

		public static float DirectionToAngle(int direction)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				if(direction < 0)
				{
					direction += BattleGridHelper.SquareDirections.Length;
				}
				else if(direction > BattleGridHelper.SquareDirections.Length - 1)
				{
					direction -= BattleGridHelper.SquareDirections.Length;
				}
				float angle = direction * (360.0f / BattleGridHelper.SquareDirections.Length);
				ValueHelper.SecureRotation(ref angle);
				return angle;
			}
			else if(ORK.BattleSystem.gridSettings.IsHorizontalHex)
			{
				if(direction < 0)
				{
					direction += 6;
				}
				else if(direction > 5)
				{
					direction -= 6;
				}
				float angle = direction * 60.0f;
				angle -= 30.0f;
				ValueHelper.SecureRotation(ref angle);
				return angle;
			}
			else if(ORK.BattleSystem.gridSettings.IsVerticalHex)
			{
				if(direction < 0)
				{
					direction += 6;
				}
				else if(direction > 5)
				{
					direction -= 6;
				}
				float angle = direction * 60.0f;
				ValueHelper.SecureRotation(ref angle);
				return angle;
			}
			return 0;
		}

		public static float GetDirectionRotation(GameObject gameObject, GridDirectionRotationType type)
		{
			if(gameObject != null)
			{
				int direction = BattleGridHelper.AngleToDirection(gameObject.transform.eulerAngles.y);
				if(GridDirectionRotationType.Nearest == type)
				{
					return BattleGridHelper.DirectionToAngle(direction);
				}
				else if(GridDirectionRotationType.Left == type)
				{
					return BattleGridHelper.DirectionToAngle(direction - 1);
				}
				else if(GridDirectionRotationType.Right == type)
				{
					return BattleGridHelper.DirectionToAngle(direction + 1);
				}
			}
			return 0;
		}

		public static float GetPositionRotation(Combatant combatant, Vector3 position)
		{
			if(combatant != null &&
				combatant.GameObject != null &&
				combatant.GridCell != null)
			{
				Vector3 rotation = combatant.GameObject.transform.eulerAngles;
				rotation.y = VectorHelper.HorizontalAngle(combatant.GridCell.transform,
					position, HorizontalPlaneType.XZ);
				int direction = BattleGridHelper.AngleToDirection(rotation.y);
				return BattleGridHelper.DirectionToAngle(direction);
			}
			return 0;
		}

		public static void RotateToPosition(Combatant combatant, Vector3 position)
		{
			if(combatant != null &&
				combatant.GameObject != null &&
				combatant.GridCell != null)
			{
				Vector3 rotation = combatant.GameObject.transform.eulerAngles;
				rotation.y = VectorHelper.HorizontalAngle(combatant.GridCell.transform,
					position, HorizontalPlaneType.XZ);
				int direction = BattleGridHelper.AngleToDirection(rotation.y);
				rotation.y = BattleGridHelper.DirectionToAngle(direction);
				combatant.GameObject.transform.eulerAngles = rotation;
			}
		}

		public static void RotateToDirection(Combatant combatant, int direction)
		{
			if(combatant != null &&
				combatant.GameObject != null &&
				combatant.GridCell != null)
			{
				Vector3 rotation = combatant.GameObject.transform.eulerAngles;
				rotation.y = BattleGridHelper.DirectionToAngle(direction);
				combatant.GameObject.transform.eulerAngles = rotation;
			}
		}


		/*
		============================================================================
		Neighbour functions
		============================================================================
		*/
		public static float GetNeighbourAngle()
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return 90.0f;
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				return 60.0f;
			}
			return 360.0f;
		}

		public static float GetNeighbourAngleOffset()
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return 0.0f;
			}
			else if(ORK.BattleSystem.gridSettings.IsHorizontalHex)
			{
				return 0.0f;
			}
			else if(ORK.BattleSystem.gridSettings.IsVerticalHex)
			{
				return 30.0f;
			}
			return 0.0f;
		}

		public static BattleGridCellComponent GetNeighbourCell(BattleGridCellComponent cell, int index)
		{
			if(cell != null && index >= 0)
			{
				if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
				{
					if(index < BattleGridHelper.SquareDirections.Length)
					{
						return cell.parentGrid.GetCell(
							cell.CubeCoord + BattleGridHelper.SquareDirections[index]);
					}
				}
				else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
				{
					if(index < BattleGridHelper.HexagonalDirections.Length)
					{
						return cell.parentGrid.GetCell(
							cell.CubeCoord + BattleGridHelper.HexagonalDirections[index]);
					}
				}
			}
			return cell;
		}

		public static void GetNeighbourCells(BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list,
			bool addBlocked, bool addNotPassable, bool allowSquareDiagonal,
			GridCellCheck check, GridCellCheck checkDiagonal, List<BattleGridCellComponent> ignore)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetNeighbourCellsSquare(origin, ref list,
					addBlocked, addNotPassable, allowSquareDiagonal, check, checkDiagonal, ignore);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetNeighbourCellsHexagonal(origin, ref list,
					addBlocked, addNotPassable, check, ignore);
			}
		}

		public static void GetNeighbourCellsSquare(BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list,
			bool addBlocked, bool addNotPassable, bool allowSquareDiagonal,
			GridCellCheck check, GridCellCheck checkDiagonal, List<BattleGridCellComponent> ignore)
		{
			CubeCoord coord = new CubeCoord();
			if(allowSquareDiagonal)
			{
				for(int i = 0; i < BattleGridHelper.SquareDirectionsDiagonal.Length; i++)
				{
					coord.Set(origin.CubeCoord);
					coord.Add(BattleGridHelper.SquareDirectionsDiagonal[i]);
					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord.x, coord.y);

					if(cell != null)
					{
						BattleGridCellComponent cell2 = null;
						BattleGridCellComponent cell3 = null;
						if(CubeCoord.IsSquareDiagonal(origin.CubeCoord, cell.CubeCoord))
						{
							coord.Set(origin.CubeCoord);
							coord.Add(BattleGridHelper.SquareDirectionsDiagonal[i - 1 < 0 ?
								BattleGridHelper.SquareDirectionsDiagonal.Length - 1 : i - 1]);
							cell2 = origin.parentGrid.GetCell(coord.x, coord.y);
							coord.Set(origin.CubeCoord);
							coord.Add(BattleGridHelper.SquareDirectionsDiagonal[
								i + 1 >= BattleGridHelper.SquareDirectionsDiagonal.Length ?
									0 : i + 1]);
							cell3 = origin.parentGrid.GetCell(coord.x, coord.y);
						}

						if((addBlocked || !cell.IsBlocked) &&
							(addNotPassable || cell.IsPassable) &&
							(cell2 == null || (!cell2.BlockDiagonalMove &&
								(checkDiagonal == null || checkDiagonal(cell2)))) &&
							(cell3 == null || (!cell3.BlockDiagonalMove &&
								(checkDiagonal == null || checkDiagonal(cell3)))) &&
							(check == null || check(cell)) &&
							!list.Contains(cell) &&
							(ignore == null || !ignore.Contains(cell)))
						{
							list.Add(cell);
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < BattleGridHelper.SquareDirectionsNonDiagonal.Length; i++)
				{
					coord.Set(origin.CubeCoord);
					coord.Add(BattleGridHelper.SquareDirectionsNonDiagonal[i]);
					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord.x, coord.y);

					if(cell != null &&
						(addBlocked || !cell.IsBlocked) &&
						(addNotPassable || cell.IsPassable) &&
						(check == null || check(cell)) &&
						!list.Contains(cell) &&
						(ignore == null || !ignore.Contains(cell)))
					{
						list.Add(cell);
					}
				}
			}
		}

		public static void GetNeighbourCellsHexagonal(BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list, bool addBlocked, bool addNotPassable,
			GridCellCheck check, List<BattleGridCellComponent> ignore)
		{
			CubeCoord coord = new CubeCoord();
			for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
			{
				coord.Set(origin.CubeCoord);
				coord.Add(BattleGridHelper.HexagonalDirections[i]);
				BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

				if(cell != null &&
					(addBlocked || !cell.IsBlocked) &&
					(addNotPassable || cell.IsPassable) &&
					(check == null || check(cell)) &&
					!list.Contains(cell) &&
					(ignore == null || !ignore.Contains(cell)))
				{
					list.Add(cell);
				}
			}
		}

		public static void GetNeighbourCells(BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list, ref List<BattleGridCellComponent> blockedList,
			bool addBlocked, bool addNotPassable, bool allowSquareDiagonal,
			GridCellCheck check, GridCellCheck checkDiagonal, List<BattleGridCellComponent> ignore)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetNeighbourCellsSquare(origin, ref list, ref blockedList,
					addBlocked, addNotPassable, allowSquareDiagonal, check, checkDiagonal, ignore);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetNeighbourCellsHexagonal(origin, ref list, ref blockedList,
					addBlocked, addNotPassable, check, ignore);
			}
		}

		public static void GetNeighbourCellsSquare(BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list, ref List<BattleGridCellComponent> blockedList,
			bool addBlocked, bool addNotPassable, bool allowSquareDiagonal,
			GridCellCheck check, GridCellCheck checkDiagonal, List<BattleGridCellComponent> ignore)
		{
			CubeCoord coord = new CubeCoord();

			if(allowSquareDiagonal)
			{
				for(int i = 0; i < BattleGridHelper.SquareDirectionsDiagonal.Length; i++)
				{
					coord.Set(origin.CubeCoord);
					coord.Add(BattleGridHelper.SquareDirectionsDiagonal[i]);
					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

					if(cell != null)
					{
						BattleGridCellComponent cell2 = null;
						BattleGridCellComponent cell3 = null;
						if(CubeCoord.IsSquareDiagonal(origin.CubeCoord, cell.CubeCoord))
						{
							coord.Set(origin.CubeCoord);
							coord.Add(BattleGridHelper.SquareDirectionsDiagonal[i - 1 < 0 ?
								BattleGridHelper.SquareDirectionsDiagonal.Length - 1 : i - 1]);
							cell2 = origin.parentGrid.GetCell(coord);

							coord.Set(origin.CubeCoord);
							coord.Add(BattleGridHelper.SquareDirectionsDiagonal[
								i + 1 >= BattleGridHelper.SquareDirectionsDiagonal.Length ?
									0 : i + 1]);
							cell3 = origin.parentGrid.GetCell(coord);
						}

						if((cell2 == null || (!cell2.BlockDiagonalMove &&
								(checkDiagonal == null || checkDiagonal(cell2)))) &&
							(cell3 == null || (!cell3.BlockDiagonalMove &&
								(checkDiagonal == null || checkDiagonal(cell3)))) &&
							(ignore == null || !ignore.Contains(cell)))
						{
							if((addBlocked || !cell.IsBlocked) &&
								(addNotPassable || cell.IsPassable) &&
								(check == null || check(cell)))
							{
								if(!list.Contains(cell))
								{
									list.Add(cell);
								}
							}
							else if(!blockedList.Contains(cell))
							{
								blockedList.Add(cell);
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < BattleGridHelper.SquareDirectionsNonDiagonal.Length; i++)
				{
					coord.Set(origin.CubeCoord);
					coord.Add(BattleGridHelper.SquareDirectionsNonDiagonal[i]);
					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

					if(cell != null &&
						(ignore == null || !ignore.Contains(cell)))
					{
						if((addBlocked || !cell.IsBlocked) &&
							(addNotPassable || cell.IsPassable) &&
							(check == null || check(cell)))
						{
							if(!list.Contains(cell))
							{
								list.Add(cell);
							}
						}
						else if(!blockedList.Contains(cell))
						{
							blockedList.Add(cell);
						}
					}
				}
			}
		}

		public static void GetNeighbourCellsHexagonal(BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list, ref List<BattleGridCellComponent> blockedList,
			bool addBlocked, bool addNotPassable, GridCellCheck check,
			List<BattleGridCellComponent> ignore)
		{
			CubeCoord coord = new CubeCoord();
			for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
			{
				coord.Set(origin.CubeCoord);
				coord.Add(BattleGridHelper.HexagonalDirections[i]);
				BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

				if(cell != null &&
					(ignore == null || !ignore.Contains(cell)))
				{
					if((addBlocked || !cell.IsBlocked) &&
						(addNotPassable || cell.IsPassable) &&
						(check == null || check(cell)))
					{
						if(!list.Contains(cell))
						{
							list.Add(cell);
						}
					}
					else if(!blockedList.Contains(cell))
					{
						blockedList.Add(cell);
					}
				}
			}
		}

		public static bool IsNeighbourCell(BattleGridCellComponent origin,
			BattleGridCellComponent cell, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return BattleGridHelper.IsNeighbourCellSquare(origin, cell, allowSquareDiagonal, check);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				return BattleGridHelper.IsNeighbourCellHexagonal(origin, cell, check);
			}
			return false;
		}

		public static bool IsNeighbourCellSquare(BattleGridCellComponent origin,
			BattleGridCellComponent cell, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(origin != null && cell != null)
			{
				CubeCoord[] directions = allowSquareDiagonal ?
					BattleGridHelper.SquareDirectionsDiagonal :
					BattleGridHelper.SquareDirectionsNonDiagonal;
				CubeCoord coord = new CubeCoord();

				for(int i = 0; i < directions.Length; i++)
				{
					coord.Set(origin.CubeCoord);
					coord.Add(directions[i]);
					BattleGridCellComponent tmpCell = origin.parentGrid.GetCell(coord);

					if(cell == tmpCell &&
						(check == null || check(cell)))
					{
						return true;
					}
				}
			}
			return false;
		}

		public static bool IsNeighbourCellHexagonal(BattleGridCellComponent origin,
			BattleGridCellComponent cell, GridCellCheck check)
		{
			if(origin != null && cell != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
				{
					coord.Set(origin.CubeCoord);
					coord.Add(BattleGridHelper.HexagonalDirections[i]);
					BattleGridCellComponent tmpCell = origin.parentGrid.GetCell(coord);

					if(cell == tmpCell &&
						(check == null || check(cell)))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public static void GetRange(BattleGridCellComponent origin, int range,
			ref List<BattleGridCellComponent> list, bool addOrigin, bool addBlocked, bool addNotPassable, GridCellCheck check)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetRangeSquare(origin, range, ref list, addOrigin, addBlocked, addNotPassable, check);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetRangeHexagonal(origin, range, ref list, addOrigin, addBlocked, addNotPassable, check);
			}
		}

		public static void GetRangeSquare(BattleGridCellComponent origin, int range,
			ref List<BattleGridCellComponent> list, bool addOrigin, bool addBlocked, bool addNotPassable,
			GridCellCheck check)
		{
			if(origin != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int dx = -range; dx <= range; dx++)
				{
					for(int dy = -range; dy <= range; dy++)
					{
						coord.Set(origin.CubeCoord);
						coord.Add(dx, dy, 0);
						if(origin.CubeCoord.DistanceSquare(coord) <= range)
						{
							BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

							if(cell != null &&
								(addOrigin || origin != cell) &&
								(addBlocked || !cell.IsBlocked) &&
								(addNotPassable || cell.IsPassable) &&
								(check == null || check(cell)) &&
								!list.Contains(cell))
							{
								list.Add(cell);
							}
						}
					}
				}
			}
		}

		public static void GetRangeHexagonal(BattleGridCellComponent origin, int range,
			ref List<BattleGridCellComponent> list, bool addOrigin, bool addBlocked, bool addNotPassable,
			GridCellCheck check)
		{
			if(origin != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int dx = -range; dx <= range; dx++)
				{
					int max = Mathf.Max(-range, -dx - range);
					int min = Mathf.Min(range, -dx + range);

					for(int dy = max; dy <= min; dy++)
					{
						coord.Set(origin.CubeCoord);
						coord.Add(dx, dy, -dx - dy);
						BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

						if(cell != null &&
							(addOrigin || origin != cell) &&
							(addBlocked || !cell.IsBlocked) &&
							(addNotPassable || cell.IsPassable) &&
							(check == null || check(cell)) &&
							!list.Contains(cell))
						{
							list.Add(cell);
						}
					}
				}
			}
		}
		public static void GetRangeCombatants(BattleGridCellComponent origin, int range,
		   ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable, GridCellCheck check)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetRangeCombatantsSquare(origin, range, ref list, addOrigin, addBlocked, addNotPassable, check);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetRangeCombatantsHexagonal(origin, range, ref list, addOrigin, addBlocked, addNotPassable, check);
			}
		}

		public static void GetRangeCombatantsSquare(BattleGridCellComponent origin, int range,
			ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable, GridCellCheck check)
		{
			CubeCoord coord = new CubeCoord();
			for(int dx = -range; dx <= range; dx++)
			{
				for(int dy = -range; dy <= range; dy++)
				{
					coord.Set(origin.CubeCoord);
					coord.Add(dx, dy, 0);
					if(origin.CubeCoord.DistanceSquare(coord) <= range)
					{
						BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

						if(cell != null &&
							!cell.IsEmpty &&
							(addOrigin || origin != cell) &&
							(addBlocked || !cell.IsBlocked) &&
							(addNotPassable || cell.IsPassable) &&
							(check == null || check(cell)))
						{
							cell.GetCombatants(ref list, null);
						}
					}
				}
			}
		}

		public static void GetRangeCombatantsHexagonal(BattleGridCellComponent origin, int range,
			ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable, GridCellCheck check)
		{
			CubeCoord coord = new CubeCoord();
			for(int dx = -range; dx <= range; dx++)
			{
				int max = Mathf.Max(-range, -dx - range);
				int min = Mathf.Min(range, -dx + range);

				for(int dy = max; dy <= min; dy++)
				{
					coord.Set(origin.CubeCoord);
					coord.Add(dx, dy, -dx - dy);
					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

					if(cell != null &&
						!cell.IsEmpty &&
						(addOrigin || origin != cell) &&
						(addBlocked || !cell.IsBlocked) &&
						(addNotPassable || cell.IsPassable) &&
						(check == null || check(cell)))
					{
						cell.GetCombatants(ref list, null);
					}
				}
			}
		}


		/*
		============================================================================
		Ring functions
		============================================================================
		*/
		public static void GetRing(BattleGridCellComponent center, int radius,
			ref List<BattleGridCellComponent> list, bool addOrigin, bool addBlocked, bool addNotPassable, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					list.Add(center);
				}
				else
				{
					if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
					{
						if(ORK.BattleSystem.gridSettings.squareDiagonalDistanceOne)
						{
							CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(5) * radius;
							radius *= 2;

							for(int i = 0; i < 4; i++)
							{
								for(int j = 0; j < radius; j++)
								{
									BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
									if(cell != null &&
										(addOrigin || center != cell) &&
										(addBlocked || !cell.IsBlocked) &&
										(addNotPassable || cell.IsPassable) &&
										(check == null || check(cell)) &&
										!list.Contains(cell))
									{
										list.Add(cell);
									}
									coord.Add(BattleGridHelper.GetDirection(i * 2));
								}
							}
						}
						else
						{
							CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(3) * radius;

							for(int i = 0; i < BattleGridHelper.SquareDirections.Length; i++)
							{
								for(int j = 0; j < radius; j++)
								{
									BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
									if(cell != null &&
										(addOrigin || center != cell) &&
										(addBlocked || !cell.IsBlocked) &&
										(addNotPassable || cell.IsPassable) &&
										(check == null || check(cell)) &&
										!list.Contains(cell))
									{
										list.Add(cell);
									}
									coord.Add(BattleGridHelper.GetDirection(i));
									coord.Add(BattleGridHelper.GetDirection(i + 1));
								}
							}
						}
					}
					else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
					{
						CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(4) * radius;

						for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
						{
							for(int j = 0; j < radius; j++)
							{
								BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
								if(cell != null &&
									(addOrigin || center != cell) &&
									(addBlocked || !cell.IsBlocked) &&
									(addNotPassable || cell.IsPassable) &&
									(check == null || check(cell)) &&
									!list.Contains(cell))
								{
									list.Add(cell);
								}
								coord.Add(BattleGridHelper.GetDirection(i));
							}
						}
					}
				}
			}
		}

		public static void GetRingCombatants(BattleGridCellComponent center, int radius,
			ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					center.GetCombatants(ref list, null);
				}
				else
				{
					if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
					{
						if(ORK.BattleSystem.gridSettings.squareDiagonalDistanceOne)
						{
							CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(5) * radius;
							radius *= 2;

							for(int i = 0; i < 4; i++)
							{
								for(int j = 0; j < radius; j++)
								{
									BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
									if(cell != null &&
										!cell.IsEmpty &&
										(addOrigin || center != cell) &&
										(addBlocked || !cell.IsBlocked) &&
										(addNotPassable || cell.IsPassable) &&
										(check == null || check(cell)))
									{
										cell.GetCombatants(ref list, null);
									}
									coord.Add(BattleGridHelper.GetDirection(i * 2));
								}
							}
						}
						else
						{
							CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(3) * radius;

							for(int i = 0; i < BattleGridHelper.SquareDirections.Length; i++)
							{
								for(int j = 0; j < radius; j++)
								{
									BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
									if(cell != null &&
										!cell.IsEmpty &&
										(addOrigin || center != cell) &&
										(addBlocked || !cell.IsBlocked) &&
										(addNotPassable || cell.IsPassable) &&
										(check == null || check(cell)))
									{
										cell.GetCombatants(ref list, null);
									}
									coord.Add(BattleGridHelper.GetDirection(i));
									coord.Add(BattleGridHelper.GetDirection(i + 1));
								}
							}
						}
					}
					else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
					{
						CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(4) * radius;

						for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
						{
							for(int j = 0; j < radius; j++)
							{
								BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
								if(cell != null &&
									!cell.IsEmpty &&
									(addOrigin || center != cell) &&
									(addBlocked || !cell.IsBlocked) &&
									(addNotPassable || cell.IsPassable) &&
									(check == null || check(cell)))
								{
									cell.GetCombatants(ref list, null);
								}
								coord.Add(BattleGridHelper.GetDirection(i));
							}
						}
					}
				}
			}
		}

		public static BattleGridCellComponent GetRingCell(
			BattleGridCellComponent userCell, BattleGridCellComponent center, int radius,
			AIGridMoveTargetType type, bool addOrigin, bool addBlocked, bool addNotPassable, GridCellCheck check)
		{
			if(userCell != null && center != null)
			{
				List<BattleGridCellComponent> list = new List<BattleGridCellComponent>();
				BattleGridHelper.GetRing(center, radius, ref list, addOrigin, addBlocked, addNotPassable, null);

				if(AIGridMoveTargetType.Nearest == type)
				{
					if(list.Contains(userCell))
					{
						return userCell;
					}
					else
					{
						int index = 0;
						int distance = userCell.CubeCoord.Distance(center.CubeCoord);

						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null &&
								(addOrigin || center != list[i]) &&
								(addBlocked || !list[i].IsBlocked) &&
								(addNotPassable || list[i].IsPassable) &&
								(check == null || check(list[i])))
							{
								int tmpDistance = userCell.CubeCoord.Distance(list[i].CubeCoord);
								if(tmpDistance < distance)
								{
									distance = tmpDistance;
									index = i;
								}
							}
						}
						return list[index];
					}
				}
				// global orientation
				else if(AIGridMoveTargetType.North == type ||
					AIGridMoveTargetType.East == type ||
					AIGridMoveTargetType.South == type ||
					AIGridMoveTargetType.West == type)
				{
					Orientation checkOrientation = Orientation.None;
					if(AIGridMoveTargetType.North == type)
					{
						checkOrientation = Orientation.Front;
					}
					else if(AIGridMoveTargetType.East == type)
					{
						checkOrientation = Orientation.Right;
					}
					else if(AIGridMoveTargetType.South == type)
					{
						checkOrientation = Orientation.Back;
					}
					else if(AIGridMoveTargetType.West == type)
					{
						checkOrientation = Orientation.Left;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null &&
							(addOrigin || center != list[i]) &&
							(list[i] == userCell ||
							((addBlocked || !list[i].IsBlocked) &&
								(addNotPassable || list[i].IsPassable) &&
								(check == null || check(list[i])))))
						{
							Orientation orientation = VectorHelper.GetOrientationGlobal(
								center.transform, list[i].transform, HorizontalPlaneType.XZ);
							if(checkOrientation == orientation)
							{
								return list[i];
							}
						}
					}
				}
				// local orientation
				else // global orientation
				if(AIGridMoveTargetType.Front == type ||
					AIGridMoveTargetType.Back == type ||
					AIGridMoveTargetType.Left == type ||
					AIGridMoveTargetType.Right == type)
				{
					Transform origin = center.Combatant != null && center.Combatant.GameObject != null ?
						center.Combatant.GameObject.transform :
						center.transform;
					Orientation checkOrientation = Orientation.None;
					if(AIGridMoveTargetType.Front == type)
					{
						checkOrientation = Orientation.Front;
					}
					else if(AIGridMoveTargetType.Right == type)
					{
						checkOrientation = Orientation.Right;
					}
					else if(AIGridMoveTargetType.Back == type)
					{
						checkOrientation = Orientation.Back;
					}
					else if(AIGridMoveTargetType.Left == type)
					{
						checkOrientation = Orientation.Left;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null &&
							(addOrigin || center != list[i]) &&
							(list[i] == userCell ||
							((addBlocked || !list[i].IsBlocked) &&
								(addNotPassable || list[i].IsPassable) &&
								(check == null || check(list[i])))))
						{
							Orientation orientation = VectorHelper.GetOrientation(
								origin, list[i].transform, HorizontalPlaneType.XZ);
							if(checkOrientation == orientation)
							{
								return list[i];
							}
						}
					}
				}
			}
			return center;
		}


		/*
		============================================================================
		Line functions
		============================================================================
		*/
		public static void GetLine(BattleGridCellComponent origin, BattleGridCellComponent target,
			ref List<BattleGridCellComponent> list, bool ignoreBlocked)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetLineSquare(origin, target, ref list, ignoreBlocked);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				BattleGridHelper.GetLineHexagonal(origin, target, ref list, ignoreBlocked);
			}
		}

		public static void GetLineSquare(BattleGridCellComponent origin, BattleGridCellComponent target,
			ref List<BattleGridCellComponent> list, bool ignoreBlocked)
		{
			int dx = Mathf.Abs(target.row - origin.row);
			int dy = Mathf.Abs(target.column - origin.column);
			int x = origin.row;
			int y = origin.column;
			int n = 1 + dx + dy;
			int x_inc = (target.row > origin.row) ? 1 : -1;
			int y_inc = (target.column > origin.column) ? 1 : -1;
			int error = dx - dy;
			dx *= 2;
			dy *= 2;

			for(; n > 0; --n)
			{
				BattleGridCellComponent cell = origin.parentGrid.GetCell(x, y);

				if(cell != null)
				{
					if(!ignoreBlocked && cell.IsBlocked)
					{
						return;
					}
					else if(!list.Contains(cell))
					{
						list.Add(cell);
					}
				}

				if(error > 0)
				{
					x += x_inc;
					error -= dy;
				}
				else
				{
					y += y_inc;
					error += dx;
				}
			}
		}

		public static void GetLineHexagonal(BattleGridCellComponent origin, BattleGridCellComponent target,
			ref List<BattleGridCellComponent> list, bool ignoreBlocked)
		{
			int distance = origin.CubeCoord.Distance(target.CubeCoord);
			for(int i = 0; i <= distance; i++)
			{
				BattleGridCellComponent cell = origin.parentGrid.GetCell(
					CubeCoord.Round(CubeCoord.Lerp(
						origin.CubeCoord, target.CubeCoord,
						1.0f / distance * i)));

				if(cell != null)
				{
					if(!ignoreBlocked && cell.IsBlocked)
					{
						return;
					}
					else if(!list.Contains(cell))
					{
						list.Add(cell);
					}
				}
			}
		}


		/*
		============================================================================
		Line of sight functions
		============================================================================
		*/
		/*public static bool CheckLineOfSight(BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return BattleGridHelper.CheckLineOfSightSquare(origin, target, blockLOS);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				return BattleGridHelper.CheckLineOfSightHexagonal(origin, target, blockLOS);
			}
			return true;
		}

		public static bool CheckLineOfSightSquare(BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS)
		{
			if(origin != target)
			{
				int distanceRow = Mathf.Abs(target.row - origin.row);
				int distanceColumn = Mathf.Abs(target.column - origin.column);
				int row = origin.row;
				int column = origin.column;
				int n = 1 + distanceRow + distanceColumn;
				int increaseRow = (target.row > origin.row) ? 1 : -1;
				int increaseColumn = (target.column > origin.column) ? 1 : -1;
				int error = distanceRow - distanceColumn;
				distanceRow *= 2;
				distanceColumn *= 2;

				for(; n > 0; --n)
				{
					BattleGridCellComponent cell = origin.parentGrid.GetCell(row, column);
					if(cell != null &&
						cell != origin &&
						cell != target &&
						blockLOS != null &&
						blockLOS(origin, cell))
					{
						return false;
					}
					if(error > 0)
					{
						row += increaseRow;
						error -= distanceColumn;
					}
					else
					{
						column += increaseColumn;
						error += distanceRow;
					}
				}
			}
			return true;
		}

		public static bool CheckLineOfSightHexagonal(BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS)
		{
			if(origin != target)
			{
				int distance = origin.CubeCoord.Distance(target.CubeCoord);
				for(int i = 0; i <= distance; i++)
				{
					BattleGridCellComponent cell = origin.parentGrid.GetCell(
						CubeCoord.Round(CubeCoord.Lerp(
							origin.CubeCoord, target.CubeCoord,
							1.0f / distance * i)));

					if(cell != null &&
						cell != origin &&
						cell != target &&
						blockLOS != null &&
						blockLOS(origin, cell))
					{
						return false;
					}
				}
			}
			return true;
		}*/


		/*
		============================================================================
		Line of sight functions
		============================================================================
		*/
		public static bool CheckLineOfSight(BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, float cellArea)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return BattleGridHelper.CheckLineOfSightSquare(origin, target, blockLOS, cellArea);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				return BattleGridHelper.CheckLineOfSightHexagonal(origin, target, blockLOS, cellArea);
			}
			return true;
		}

		public static bool CheckLineOfSightSquare(BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, float cellArea)
		{
			bool valid = true;
			if(origin != target)
			{
				int distanceRow = Mathf.Abs(target.row - origin.row);
				int distanceColumn = Mathf.Abs(target.column - origin.column);
				int row = origin.row;
				int column = origin.column;
				int nStart = 1 + distanceRow + distanceColumn;
				int increaseRow = (target.row > origin.row) ? 1 : -1;
				int increaseColumn = (target.column > origin.column) ? 1 : -1;
				int error = distanceRow - distanceColumn;
				distanceRow *= 2;
				distanceColumn *= 2;

				for(int n = nStart; n > 0; --n)
				{
					BattleGridCellComponent cell = origin.parentGrid.GetCell(row, column);
					if(cell != null &&
						cell != origin &&
						cell != target &&
						blockLOS != null &&
						blockLOS(origin, cell))
					{
						valid = false;
						break;
					}
					if(error > 0)
					{
						row += increaseRow;
						error -= distanceColumn;
					}
					else
					{
						column += increaseColumn;
						error += distanceRow;
					}
				}

				if(!valid && cellArea > 0)
				{
					valid = true;

					// row+
					if(!BattleGridHelper.CheckLineOfSightSquareOffset(origin, target, blockLOS,
							nStart, increaseRow, increaseColumn, cellArea, 0) &&
						// row-
						!BattleGridHelper.CheckLineOfSightSquareOffset(origin, target, blockLOS,
							nStart, increaseRow, increaseColumn, -cellArea, 0) &&
						// column+
						!BattleGridHelper.CheckLineOfSightSquareOffset(origin, target, blockLOS,
							nStart, increaseRow, increaseColumn, 0, cellArea) &&
						// column-
						!BattleGridHelper.CheckLineOfSightSquareOffset(origin, target, blockLOS,
							nStart, increaseRow, increaseColumn, 0, -cellArea))
					{
						valid = false;
					}
				}
			}
			return valid;
		}

		private static bool CheckLineOfSightSquareOffset(BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, int nStart, int increaseRow, int increaseColumn, float rowOffset, float columnOffset)
		{
			float distanceRow = Mathf.Abs((target.row + rowOffset) - origin.row);
			float distanceColumn = Mathf.Abs((target.column + columnOffset) - origin.column);
			int row = origin.row;
			int column = origin.column;
			float error = distanceRow - distanceColumn;
			distanceRow *= 2;
			distanceColumn *= 2;

			for(int n = nStart; n > 0; --n)
			{
				BattleGridCellComponent cell = origin.parentGrid.GetCell(row, column);
				if(cell != null &&
					cell != origin &&
					cell != target &&
					blockLOS != null &&
					blockLOS(origin, cell))
				{
					return false;
				}
				if(error > 0)
				{
					row += increaseRow;
					error -= distanceColumn;
				}
				else
				{
					column += increaseColumn;
					error += distanceRow;
				}
			}
			return true;
		}

		public static bool CheckLineOfSightHexagonal(BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, float cellArea)
		{
			bool valid = true;
			if(origin != target)
			{
				int distance = origin.CubeCoord.Distance(target.CubeCoord);
				Vector3 targetV3 = target.CubeCoord.ToVector3();

				if(!BattleGridHelper.CheckLineOfSightHexagonalOffset(
					origin, target, blockLOS, distance, targetV3))
				{
					valid = false;
				}

				if(!valid && cellArea > 0)
				{
					valid = true;

					// X+
					if(!BattleGridHelper.CheckLineOfSightHexagonalOffset(origin, target, blockLOS,
							distance, targetV3 + new Vector3(cellArea, 0, 0)) &&
						// X-
						!BattleGridHelper.CheckLineOfSightHexagonalOffset(origin, target, blockLOS,
							distance, targetV3 + new Vector3(-cellArea, 0, 0)) &&
						// Y+
						!BattleGridHelper.CheckLineOfSightHexagonalOffset(origin, target, blockLOS,
							distance, targetV3 + new Vector3(0, cellArea, 0)) &&
						// Y-
						!BattleGridHelper.CheckLineOfSightHexagonalOffset(origin, target, blockLOS,
							distance, targetV3 + new Vector3(0, -cellArea, 0)) &&
						// Z+
						!BattleGridHelper.CheckLineOfSightHexagonalOffset(origin, target, blockLOS,
							distance, targetV3 + new Vector3(0, 0, cellArea)) &&
						// Z-
						!BattleGridHelper.CheckLineOfSightHexagonalOffset(origin, target, blockLOS,
							distance, targetV3 + new Vector3(0, 0, -cellArea)))
					{
						valid = false;
					}
				}
			}
			return valid;
		}

		private static bool CheckLineOfSightHexagonalOffset(BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, int distance, Vector3 targetV3)
		{
			for(int i = 0; i <= distance; i++)
			{
				BattleGridCellComponent cell = origin.parentGrid.GetCell(
					CubeCoord.Round(CubeCoord.Lerp(
						origin.CubeCoord, targetV3,
						1.0f / distance * i)));

				if(cell != null &&
					cell != origin &&
					cell != target &&
					blockLOS != null &&
					blockLOS(origin, cell))
				{
					return false;
				}
			}
			return true;
		}


		/*
		============================================================================
		Editor tool functions
		============================================================================
		*/
		public static BattleGridCellComponent GetPreviousCell(BattleGridCellComponent cell)
		{
			if(cell != null && cell.parentGrid != null)
			{
				int row = cell.row;
				int column = cell.column;
				column--;
				if(column < 0)
				{
					row--;
					if(row < 0)
					{
						row = cell.parentGrid.cellRow.Length - 1;
					}
					column = cell.parentGrid.cellRow[row].Length - 1;
				}
				return cell.parentGrid.GetCell(row, column);
			}
			return null;
		}

		public static BattleGridCellComponent GetNextCell(BattleGridCellComponent cell)
		{
			if(cell != null && cell.parentGrid != null)
			{
				int row = cell.row;
				int column = cell.column;
				column++;
				if(column >= cell.parentGrid.cellRow[row].Length)
				{
					row++;
					if(row >= cell.parentGrid.cellRow.Length)
					{
						row = 0;
					}
					column = 0;
				}
				return cell.parentGrid.GetCell(row, column);
			}
			return null;
		}
	}
}
