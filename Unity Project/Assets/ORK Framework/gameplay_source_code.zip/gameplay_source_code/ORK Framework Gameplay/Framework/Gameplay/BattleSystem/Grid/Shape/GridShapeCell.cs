﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridShapeCell : BaseData
	{
		public bool selected = false;

		public CubeCoord coord;

		public GridShapeCell()
		{
			
		}

		public GridShapeCell(CubeCoord coord)
		{
			this.coord = coord;
		}
	}
}
