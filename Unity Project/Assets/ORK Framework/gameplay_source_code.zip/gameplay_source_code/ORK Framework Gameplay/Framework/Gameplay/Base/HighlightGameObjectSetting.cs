﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HighlightGameObjectSetting : BaseData
	{
		// cursor
		[ORKEditorHelp("Use Cursor", "A cursor game object is used to highlighted the game object.", "")]
		[ORKEditorInfo("Cursor Settings", "A cursor game object can be used to highlight the game object.", "")]
		public bool useCursor = false;

		[ORKEditorHelp("Prefab", "Select the prefab used as cursor.", "")]
		[ORKEditorLayout("useCursor", true)]
		public GameObject cursorPrefab;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings cursorMount = new MountSettings();


		// blink
		[ORKEditorHelp("Use Blink", "The highlighted game object will blink.", "")]
		[ORKEditorInfo("Blink Settings", "The highlighted game object can blink.", "")]
		public bool useBlink = false;

		[ORKEditorHelp("Blink Children", "All child objects of the highlighted game object will blink.", "")]
		[ORKEditorLayout("useBlink", true)]
		public bool blinkChildren = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FadeColorSettings blink;


		// HUD blink
		[ORKEditorHelp("Use HUD Blink", "HUDs of the highlighted game object will blink.", "")]
		[ORKEditorInfo("HUD Blink Settings", "The HUDs of the highlighted game object can blink.", "")]
		public bool useBlinkHUD = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useBlinkHUD", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings blinkHUD;

		public HighlightGameObjectSetting()
		{

		}

		public void Highlight(GameObject gameObject, ref GameObject cursorObject)
		{
			if(gameObject != null)
			{
				if(this.useCursor &&
					this.cursorPrefab != null)
				{
					if(cursorObject == null)
					{
						cursorObject = (GameObject)GameObject.Instantiate(
							this.cursorPrefab);
					}
					if(cursorObject != null)
					{
						cursorObject.SetActive(true);
						this.cursorMount.MountTo(gameObject.transform, cursorObject.transform);
					}
				}
				if(this.useBlink &&
					this.blink != null)
				{
					TargetBlinker comp = gameObject.GetComponent<TargetBlinker>();
					if(!comp)
					{
						comp = gameObject.AddComponent<TargetBlinker>();
					}
					comp.Blink(this.blink, this.blinkChildren);
				}
				if(this.useBlinkHUD &&
					this.blinkHUD != null)
				{
					Combatant combatant = ComponentHelper.GetCombatant(gameObject);
					if(combatant != null)
					{
						combatant.HUDStartFade(this.blinkHUD, true);
					}
				}
			}
		}

		public void StopHighlight(GameObject gameObject, ref GameObject cursorObject)
		{
			if(gameObject != null)
			{
				if(this.useBlinkHUD &&
					this.blinkHUD != null)
				{
					Combatant combatant = ComponentHelper.GetCombatant(gameObject);
					if(combatant != null)
					{
						combatant.HUDStopFade();
					}
				}
				if(this.useBlink &&
					this.blink != null)
				{
					TargetBlinker comp = gameObject.GetComponent<TargetBlinker>();
					if(comp != null)
					{
						comp.StopBlink();
					}
				}
				if(this.useCursor &&
					this.cursorPrefab != null)
				{
					if(cursorObject != null)
					{
						cursorObject.SetActive(false);
					}
				}
			}
		}
	}
}
