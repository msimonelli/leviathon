
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class BattleCombatant : BaseData
	{
		[ORKEditorHelp("Faction", "Select the faction the combatant/group will be part of.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
		
		[ORKEditorHelp("Use Group", "Use a combatant group.\n" + 
			"If disabled, a single combatant will be used.", "")]
		public bool useGroup = true;

		[ORKEditorHelp("Combatant Group", "Select the combatant group that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CombatantGroup)]
		[ORKEditorLayout("useGroup", true)]
		public int id = 0;

		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public CombatantGroupMember member;
		
		public BattleCombatant()
		{

		}

		public Group GetGroup()
		{
			Group group = null;
			if(this.useGroup)
			{
				group = ORK.CombatantGroups.Create(this.id, this.factionID);
			}
			else if(this.member != null)
			{
				group = new Group(this.factionID);
				this.member.Create(group);
			}
			return group;
		}

		public Group GetGroup(CombatantSpawner spawner, int spawnerIndex, bool respawn)
		{
			Group group = this.GetGroup();
			if(group != null)
			{
				group.SetSpawner(spawner, spawnerIndex, respawn);
			}
			return group;
		}

		public string GetInfoText()
		{
			return this.useGroup ? 
				ORK.CombatantGroups.GetName(this.id) : 
				this.member.GetInfoText();
		}
	}
}
