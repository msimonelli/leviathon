
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public class TurnBasedBattle : BaseBattle
	{
		// battle mode
		[ORKEditorHelp("Turn Based Mode", "Select the mode of the turn based battle system:" +
			"\n\n<b>Classic</b>\n" +
			"Actions are selected at the beginning of each turn and executed " +
			"after all combatants chose their actions.\n" +
			"\n\n<b>Active</b>\n" +
			"Actions are executed right after selecting them, resulting in " +
			"each combatant selecting his action after the previous combatant finished its action.\n" +
			"\n\n<b>Multi Turns</b>\n" +
			"A combatant can have multiple turns before another combatant had a turn. " +
			"A combatant's turn value will be reset to 0 after finishing the turn, " +
			"and the turn value of all combatants will be increased (using the 'Turn Calculation'). " +
			"The combatant with the highest turn value will have the next turn.", "")]
		[ORKEditorInfo("Turn Based Settings", "Settings for the turn based battle system.\n" +
			"A combatant will perform actions when it's his turn.", "",
			labelText="Battle Mode")]
		public TurnBasedMode mode = TurnBasedMode.Classic;

		[ORKEditorHelp("Use Dynamic Combat", "Multiple actions are allowed at the same time.\n" +
			"Combatants will attack as soon as they can, the strict turn based battle order isn't followed.\n" +
			"Please note that only camera changes from the latest battle action (battle animations) will be performed.", "")]
		public bool dynamicCombat = false;

		[ORKEditorHelp("Time Between Actions (s)", "The minimum time in seconds between two battle actions.", "")]
		[ORKEditorLayout("dynamicCombat", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minTimeBetween = 0;


		// turn calculation
		[ORKEditorHelp("Turn Calculation", "Select the formula used to calculate a turn value for every combatant.\n" +
			"Afterwards the values are sorted descending - the combatant with the highest turn value performs the first action, " +
			"followed by the combatant with the next (lower) value.", "")]
		[ORKEditorInfo(ORKDataType.Formula, separator=true, labelText="Turn Calculation")]
		public int turnFormulaID = 0;

		[ORKEditorHelp("Initial Value (Turn)", "The initial value passed to the turn formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		public float initialValueTurn = 0;

		[ORKEditorHelp("Invert Turn Order", "Inverts the order of turns, the values will be sorted ascending.\n" +
			"The combatant with the lowest turn value performs the first action.\n" +
			"If disabled, the turn order is sorted descending.\n\n" +
			"<b>Multi Turns</b>\n" +
			"In 'Multi Turns' mode, the combatant's turn value will be increased after the combatant's turn.\n" +
			"The other combatants turn values will not be increased, the combatant with the lowest turn value will have the next turn.", "")]
		public bool invertTurnOrder = false;


		// battle menu settings
		[ORKEditorHelp("Auto Call Menu", "Automatically call the battle menu when a player controlled combatant's turn starts.\n" +
			"If disabled, the battle menu can be called through an input key during the combatant's turn, " +
			"or rely on other methods to select battle actions (e.g. control maps or shortcut HUDs).", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Menu Settings")]
		public bool autoCallBattleMenu = true;

		[ORKEditorHelp("Battle Menu Key", "Key to call the battle menu.\n" +
			"The key is only used in 'Real Time' type battles.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("autoCallBattleMenu", false)]
		public int battleMenuKey = 0;

		[ORKEditorHelp("2nd Press Closes", "A second press on the battle menu key closes the battle menu.", "")]
		public bool battleMenuKeyCloses = false;

		[ORKEditorHelp("Close Ends Turn", "Closing the battle menu with the 2nd key press ends the combatant's turn.", "")]
		[ORKEditorLayout("battleMenuKeyCloses", true, endCheckGroup=true, endGroups=2)]
		public bool battleMenuKeyEndsTurn = false;


		// options
		[ORKEditorHelp("Can Counter", "Combatants can counter attack in 'Turn Based' battles.\n" +
			"If disabled, combatants can't counter attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Options")]
		public bool canCounter = true;

		[ORKEditorHelp("Defeat on Player Death", "The player is defeated if the player combatant is dead.\n" +
			"If disabled, the whole player battle group has to be dead.", "")]
		public bool defeatPlayerDead = false;

		[ORKEditorHelp("Death Immediately", "A combatant's death action will be performed immediately when dying.\n" +
			"If disabled, the death action will be performed after the current action ends.", "")]
		public bool deathImmediately = false;

		[ORKEditorHelp("End Immediately", "The battle will end immediately, stopping the actions that are still performing.\n" +
			"If disabled, the battle will wait for all active actions to end.", "")]
		public bool endImmediately = false;

		[ORKEditorHelp("Defend First", "The defend command will perform before other actions.\n" +
			"Doesn't take already performing actions into account.", "")]
		public bool defendFirst = false;

		[ORKEditorHelp("Selecting Control Map", "The control map of the currently selecting player group member is used (and only while selecting).\n" +
			"If disabled, the control map of the player is used at all times.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool selectingControlMap = false;


		// auto attack settings
		[ORKEditorHelp("Can Auto Attack", "Combatants can perform auto attacks.", "")]
		[ORKEditorInfo("Auto Attack Settings", "Set if combatants can use auto attacks in a battle of this system type.", "")]
		public bool canAutoAttack = true;

		[ORKEditorHelp("Menu Block Auto Atk", "A combatant's auto attack is blocked while his battle menu is opened.\n" +
			"Another combatant's menu wont block auto attacks.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("canAutoAttack", true, endCheckGroup=true)]
		public bool blockAutoAttackMenu = false;


		// actions settings
		[ORKEditorInfo("Actions Settings", "Define how many actions a combatant can perform each turn and the default action costs.", "",
			endFoldout=true)]
		public ActionsPerTurnSettings actionsPerTurn = new ActionsPerTurnSettings();


		// action time settings
		[ORKEditorInfo("Action Time Settings", "Optionally use action time, " +
			"allowing a combatant to select actions only for a defined amount of time.", "",
			endFoldout=true)]
		public ActionTimeSettings actionTime = new ActionTimeSettings();


		// turn order display
		[ORKEditorHelp("Turn Order Counter", "Select how the turn order is displayed in HUDs when using the '%to' text code:\n" +
			"- None: No counter is added.\n" +
			"- Letters: Letters are used (A, B, C, ...).\n" +
			"- Numbers: Numbers are used (1, 2, 3, ...).", "")]
		[ORKEditorInfo("Turn Order Counter", "Define how turn order counter will be displayed by HUDs when using the '%to' text code.\n" +
			"The turn order counter defines the number of turns until a combatant can take action (e.g. 1 means the next turn).", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public EnemyCounting turnOrderCounter = EnemyCounting.None;

		[ORKEditorHelp("Selecting Combatant Text", "The text used for the currently selecting (and in action) combatant when using the '%to' text code.", "")]
		[ORKEditorInfo("Selecting Combatant Text", "The text used for the currently selecting (and in action) combatant when using the '%to' text code.", "",
			endFoldout=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] turnOrderSelectingInfo = ArrayHelper.CreateArray(ORK.Languages.Count, "");

		[ORKEditorHelp("None Text", "The text used for combatants that aren't in the turn order " +
			"(e.g. already had their turn) when using the '%to' text code.", "")]
		[ORKEditorInfo("None Text", "The text used for combatants that aren't in the turn order " +
			"(e.g. already had their turn) when using the '%to' text code.", "",
			endFoldout=true, endFolds=2, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] turnOrderNoneInfo = ArrayHelper.CreateArray(ORK.Languages.Count, "");


		// ingame
		protected Combatant selectingCombatant;

		private List<Combatant> turnOrder = new List<Combatant>();

		private List<Combatant> performedOrder = new List<Combatant>();

		private int firstMoveRounds = 1;

		private bool performingActions = false;

		private bool isFirstTurn = false;


		// turn order HUD updates
		private Notify updateHUDHandler;
		public event Notify UpdateHUD
		{
			add { this.updateHUDHandler += value; }
			remove { this.updateHUDHandler -= value; }
		}

		public TurnBasedBattle()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("activeCommand"))
			{
				bool tmpActive = false;
				bool tmpMulti = false;
				data.Get("activeCommand", ref tmpActive);
				data.Get("useMultiTurns", ref tmpMulti);
				if(tmpActive && tmpMulti)
				{
					this.mode = TurnBasedMode.MultiTurns;
				}
				else if(tmpActive)
				{
					this.mode = TurnBasedMode.Active;
				}
				else
				{
					this.mode = TurnBasedMode.Classic;
				}
			}
			// action costs
			if(data.Contains<bool>("addActionsPerTurn"))
			{
				this.actionsPerTurn.SetData(data);
			}
			else if(data.Contains<DataObject>("defaultActionCost"))
			{
				this.actionsPerTurn.defaultActionCostSetting.cost.SetData(data.GetFile("defaultActionCost"));
				if(this.actionsPerTurn.ownAbilityCost)
				{
					this.actionsPerTurn.defaultAbilityCostSetting = new ActionCost();
					this.actionsPerTurn.defaultAbilityCostSetting.cost.SetData(data.GetFile("defaultAbilityCost"));
				}
				if(this.actionsPerTurn.ownItemCost)
				{
					this.actionsPerTurn.defaultItemCostSetting = new ActionCost();
					this.actionsPerTurn.defaultItemCostSetting.cost.SetData(data.GetFile("defaultItemCost"));
				}
				if(this.actionsPerTurn.ownDefendCost)
				{
					this.actionsPerTurn.defendCostSetting = new ActionCost();
					this.actionsPerTurn.defendCostSetting.cost.SetData(data.GetFile("defendCost"));
				}
				if(this.actionsPerTurn.ownEscapeCost)
				{
					this.actionsPerTurn.escapeCostSetting = new ActionCost();
					this.actionsPerTurn.escapeCostSetting.cost.SetData(data.GetFile("escapeCost"));
				}
				if(this.actionsPerTurn.ownNoneCost)
				{
					this.actionsPerTurn.noneCostSetting = new ActionCost();
					this.actionsPerTurn.noneCostSetting.cost.SetData(data.GetFile("noneCost"));
				}
				if(this.actionsPerTurn.ownChangeMemberCost)
				{
					this.actionsPerTurn.changeMemberCostSetting = new ActionCost();
					this.actionsPerTurn.changeMemberCostSetting.cost.SetData(data.GetFile("changeMemberCost"));
				}
				if(this.actionsPerTurn.ownGridMoveCost)
				{
					this.actionsPerTurn.gridMoveCostSetting = new ActionCost();
					this.actionsPerTurn.gridMoveCostSetting.cost.SetData(data.GetFile("gridMoveCost"));
				}
			}
		}

		public void FireHUDUpdate()
		{
			if(this.updateHUDHandler != null)
			{
				this.updateHUDHandler();
			}
		}

		public override bool CanCounter
		{
			get { return this.canCounter; }
		}

		public override bool DeathImmediately
		{
			get { return this.deathImmediately; }
		}

		public override bool EndImmediately
		{
			get { return this.endImmediately; }
		}

		public override bool DefeatOnPlayerDeath
		{
			get { return this.defeatPlayerDead; }
		}

		public override bool DefendFirst
		{
			get { return this.defendFirst; }
		}

		public override Combatant SelectingCombatant
		{
			get { return this.selectingCombatant; }
			set { this.selectingCombatant = value; }
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool IsDynamicCombat()
		{
			return this.dynamicCombat;
		}

		public override bool CanChoose(Combatant combatant)
		{
			return combatant.Battle.UsedActionBar < combatant.Battle.ActionBar &&
				(!this.actionTime.useActionTime || combatant.Battle.ActionTime > 0);
		}

		public override bool CanDecreaseActionTime(Combatant combatant)
		{
			return this.actionTime.CanDecrease(combatant);
		}

		public override bool MenuBlockAutoAttack
		{
			get
			{
				return this.blockAutoAttackMenu;
			}
		}

		public override bool CanAutoAttack
		{
			get
			{
				return this.canAutoAttack;
			}
		}


		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		public override void Tick()
		{
			// battle menu key
			if(!this.autoCallBattleMenu &&
				this.selectingCombatant != null)
			{
				if(ORK.InputKeys.Get(this.battleMenuKey).GetButton() &&
					!this.selectingCombatant.Dead &&
					this.selectingCombatant.Actions.IsChoosing &&
					this.selectingCombatant.IsPlayerControlled() &&
					!this.selectingCombatant.IsAIControlled())
				{
					if(!this.selectingCombatant.BattleMenu.IsOpen)
					{
						this.selectingCombatant.Actions.Choose(false, true);
					}
					else if(this.battleMenuKeyCloses)
					{
						this.selectingCombatant.EndBattleMenu(this.battleMenuKeyEndsTurn);
					}
				}
			}
		}


		/*
		============================================================================
		Action cost functions
		============================================================================
		*/
		public override float GetDefendActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownDefendCost)
			{
				return this.actionsPerTurn.defendCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetEscapeActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownEscapeCost)
			{
				return this.actionsPerTurn.escapeCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetNoneActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownNoneCost)
			{
				return this.actionsPerTurn.noneCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetChangeMemberActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownChangeMemberCost)
			{
				return this.actionsPerTurn.changeMemberCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetGridMoveActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownGridMoveCost)
			{
				return this.actionsPerTurn.gridMoveCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public override void StartBattle(bool changed)
		{
			base.StartBattle(changed);
			this.selectingCombatant = null;
			this.turnOrder.Clear();
			this.performedOrder.Clear();
			this.performingActions = false;
			this.FireHUDUpdate();

			if(!changed)
			{
				this.isFirstTurn = true;
				this.firstMoveRounds = 0;
				if(GroupAdvantageType.Player == ORK.Battle.Advantage)
				{
					if(ORK.BattleSettings.playerAdvantage.playerGroupCondition.firstMove)
					{
						this.firstMoveRounds = ORK.BattleSettings.playerAdvantage.playerGroupCondition.firstMoveRounds;
					}
					else if(ORK.BattleSettings.playerAdvantage.enemyGroupCondition.firstMove)
					{
						this.firstMoveRounds = ORK.BattleSettings.playerAdvantage.enemyGroupCondition.firstMoveRounds;
					}
				}
				else if(GroupAdvantageType.Enemy == ORK.Battle.Advantage)
				{
					if(ORK.BattleSettings.enemyAdvantage.playerGroupCondition.firstMove)
					{
						this.firstMoveRounds = ORK.BattleSettings.enemyAdvantage.playerGroupCondition.firstMoveRounds;
					}
					else if(ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.firstMove)
					{
						this.firstMoveRounds = ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.firstMoveRounds;
					}
				}
			}
			this.StartTurn();
		}

		private void StartTurn()
		{
			ORK.Battle.CheckBattleEnd();
			if(!ORK.Battle.BattleEnd && !ORK.Battle.WaitForLastAction)
			{
				ORK.Battle.Turn++;
				this.performingActions = false;
				this.selectingCombatant = null;

				if(!this.dynamicCombat)
				{
					ORK.Battle.Actions.ClearStack();
				}

				// determine the order of actions
				List<Combatant> order = new List<Combatant>();
				List<Combatant> allyOrder = null;
				List<Combatant> enemyOrder = null;
				if(GroupAdvantageType.None != ORK.Battle.Advantage &&
					this.firstMoveRounds > 0)
				{
					allyOrder = new List<Combatant>();
					enemyOrder = new List<Combatant>();
				}

				Combatant player = ORK.Game.ActiveGroup.Leader;
				// player group and allies
				this.GroupTurnInit(ORK.Game.Combatants.Get(player, true, Range.Infinity,
					Consider.No, Consider.Ignore, Consider.Yes),
					ref order, ref allyOrder);
				// enemies
				this.GroupTurnInit(ORK.Game.Combatants.Get(player, true, Range.Infinity,
					Consider.Yes, Consider.Ignore, Consider.Yes),
					ref order, ref enemyOrder);

				if(GroupAdvantageType.None == ORK.Battle.Advantage ||
					this.firstMoveRounds < 1)
				{
					order.Sort(new TurnSorter(this.invertTurnOrder));
				}
				else
				{
					allyOrder.Sort(new TurnSorter(this.invertTurnOrder));
					enemyOrder.Sort(new TurnSorter(this.invertTurnOrder));
					if(GroupAdvantageType.Player == ORK.Battle.Advantage)
					{
						for(int i = 0; i < allyOrder.Count; i++)
						{
							order.Add(allyOrder[i]);
						}
						for(int i = 0; i < enemyOrder.Count; i++)
						{
							order.Add(enemyOrder[i]);
						}
					}
					else if(GroupAdvantageType.Enemy == ORK.Battle.Advantage)
					{
						for(int i = 0; i < enemyOrder.Count; i++)
						{
							order.Add(enemyOrder[i]);
						}
						for(int i = 0; i < allyOrder.Count; i++)
						{
							order.Add(allyOrder[i]);
						}
					}
					this.firstMoveRounds--;
				}

				this.isFirstTurn = false;
				this.turnOrder.Clear();
				this.performedOrder.Clear();
				for(int i = 0; i < order.Count; i++)
				{
					order[i].Battle.LastTurnIndex = i;
					this.turnOrder.Add(order[i]);
				}
				this.FireHUDUpdate();
				this.GetNextAction();
			}
		}

		public float GetTurnCalculation(Combatant combatant)
		{
			return ORK.Formulas.Get(this.turnFormulaID).Calculate(
				new FormulaCall(this.initialValueTurn, combatant, combatant));
		}

		private void GroupTurnInit(List<Combatant> group,
			ref List<Combatant> order,
			ref List<Combatant> groupOrder)
		{
			for(int i = 0; i < group.Count; i++)
			{
				if(!group[i].Dead)
				{
					if(TurnBasedMode.MultiTurns == this.mode)
					{
						if(!this.invertTurnOrder || this.isFirstTurn)
						{
							group[i].Battle.TurnValue += ORK.Formulas.Get(this.turnFormulaID).
								Calculate(new FormulaCall(this.initialValueTurn, group[i], group[i]));
						}
						group[i].Battle.TurnState = CombatantTurnState.BeforeTurn;
					}
					else if(group[i].Battle.TurnState != CombatantTurnState.InTurn)
					{
						group[i].Battle.TurnValue += ORK.Formulas.Get(this.turnFormulaID).
							Calculate(new FormulaCall(this.initialValueTurn, group[i], group[i]));
						group[i].Battle.TurnState = CombatantTurnState.BeforeTurn;
					}
					else
					{
						group[i].Battle.TurnValue = 0 - this.turnOrder.Count + group[i].Battle.LastTurnIndex;
					}

					if(GroupAdvantageType.None == ORK.Battle.Advantage ||
						this.firstMoveRounds < 1)
					{
						order.Add(group[i]);
					}
					else
					{
						groupOrder.Add(group[i]);
					}
				}
			}
		}

		public override void RemoveFromOrder(Combatant combatant)
		{
			if(!combatant.Status.NoTurnRemove)
			{
				if(TurnBasedMode.MultiTurns == this.mode)
				{
					combatant.Battle.TurnValue = 0;
					this.turnOrder.Sort(new TurnSorter(this.invertTurnOrder));
				}
				else
				{
					// action not yet selected
					if(this.turnOrder.Contains(combatant))
					{
						this.turnOrder.Remove(combatant);
					}
					// remove action
					else
					{
						ORK.Battle.Actions.RemoveFromUser(combatant);
					}
				}
				this.FireHUDUpdate();
			}
		}

		public override void OrderChange(Combatant combatant, int change)
		{
			if(!combatant.Status.NoTurnOrderChange)
			{
				if(TurnBasedMode.MultiTurns == this.mode)
				{
					combatant.Battle.TurnValue -= change;
					this.turnOrder.Sort(new TurnSorter(this.invertTurnOrder));
				}
				else
				{
					// action not yet selected
					if(this.turnOrder.Contains(combatant))
					{
						int newIndex = this.turnOrder.IndexOf(combatant) + change;
						newIndex = Mathf.Max(newIndex, 0);
						newIndex = Mathf.Min(newIndex, this.turnOrder.Count - 1);

						this.turnOrder.Remove(combatant);
						this.turnOrder.Insert(newIndex, combatant);
					}
					// move action
					else
					{
						ORK.Battle.Actions.ChangeOrderFromUser(combatant, change);
					}
				}
				this.FireHUDUpdate();
			}
		}

		public void TurnValuesUpdated()
		{
			if(TurnBasedMode.MultiTurns == this.mode)
			{
				this.turnOrder.Sort(new TurnSorter(this.invertTurnOrder));
				this.FireHUDUpdate();
			}
		}

		public override void BattleMenuCanceled(Combatant user)
		{
			if(user != null && this.selectingCombatant == user)
			{
				this.selectingCombatant = null;
				ORK.Battle.Actions.Add(null);
			}
		}

		public override bool UseControlMap()
		{
			if(this.selectingControlMap)
			{
				if(this.selectingCombatant != null &&
					this.selectingCombatant.IsPlayerControlled() &&
					!this.selectingCombatant.IsAIControlled())
				{
					this.selectingCombatant.ControlMapTick();
				}
				return true;
			}
			return false;
		}

		public override void CombatantChanged(Combatant oldCombatant, Combatant newCombatant)
		{
			if(this.selectingCombatant == oldCombatant)
			{
				this.selectingCombatant = newCombatant;
				if(this.performedOrder.Contains(oldCombatant))
				{
					this.performedOrder[this.performedOrder.IndexOf(oldCombatant)] = newCombatant;
				}
			}
			else
			{
				for(int i = 0; i < this.turnOrder.Count; i++)
				{
					if(this.turnOrder[i] == oldCombatant)
					{
						this.turnOrder[i] = newCombatant;
					}
				}
			}
		}


		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		protected bool TurnOrderFinished()
		{
			return this.turnOrder.Count == 0 &&
				(this.selectingCombatant == null ||
					(!this.selectingCombatant.Actions.IsChoosing &&
					!this.selectingCombatant.Actions.CanChoose));
		}

		protected void GetNextAction()
		{
			ORK.StartCoroutine(this.GetNextAction2());
		}

		protected IEnumerator GetNextAction2()
		{
			yield return null;
			if(ORK.Battle.IsBattleRunning() &&
				!ORK.Battle.BattleEnd &&
				!ORK.Battle.WaitForLastAction)
			{
				// still has actions per turn
				if(this.selectingCombatant != null &&
					this.selectingCombatant.Actions.CanChoose)
				{
					if(this.IsGroupAuto(this.selectingCombatant))
					{
						this.selectingCombatant.Actions.ChooseAuto(false);
					}
					else
					{
						this.selectingCombatant.Actions.Choose(false, this.autoCallBattleMenu);
					}
				}
				// next combatant
				else if(this.turnOrder.Count > 0)
				{
					this.selectingCombatant = this.GetNextSelectingCombatant();
					this.FireHUDUpdate();

					if(this.selectingCombatant != null)
					{
						if(TurnBasedMode.MultiTurns == this.mode &&
							this.invertTurnOrder)
						{
							for(int i = 0; i < this.turnOrder.Count; i++)
							{
								this.turnOrder[i].Battle.TurnValue -= this.selectingCombatant.Battle.TurnValue;
							}
							this.selectingCombatant.Battle.TurnValue = 0;
						}

						if(!this.performedOrder.Contains(this.selectingCombatant))
						{
							this.performedOrder.Add(this.selectingCombatant);
						}
						if(this.IsGroupAuto(this.selectingCombatant))
						{
							this.selectingCombatant.Actions.ChooseAuto(true);
						}
						else
						{
							this.selectingCombatant.Actions.Choose(true, this.autoCallBattleMenu);
						}
					}
					// no combatants left
					else if(ORK.Battle.Actions.Has())
					{
						this.PerformNextAction();
					}
					else
					{
						this.StartTurn();
					}
				}
				// no combatants left
				else if(ORK.Battle.Actions.Has())
				{
					this.PerformNextAction();
				}
				else
				{
					this.StartTurn();
				}
			}
		}

		private Combatant GetNextSelectingCombatant()
		{
			if(this.turnOrder.Count > 0)
			{
				Combatant combatant = this.turnOrder[0];
				this.turnOrder.RemoveAt(0);

				if(combatant != null &&
					combatant.Battle.ReceiveActionsPerTurn)
				{
					this.actionTime.SetActionTime(combatant);
					this.actionsPerTurn.SetActionsPerTurn(combatant);
				}

				if(combatant != null &&
					combatant.Actions.CanChoose)
				{
					return combatant;
				}
				else
				{
					if(combatant != null)
					{
						if(combatant.Actions.ActionState == CombatantActionState.Available)
						{
							combatant.Battle.InitNewTurn(false);
						}
					}
					return this.GetNextSelectingCombatant();
				}
			}
			return null;
		}

		public override void ActionAdded(BaseAction action)
		{
			if(TurnBasedMode.Active == this.mode ||
				TurnBasedMode.MultiTurns == this.mode ||
				(!this.performingActions && this.TurnOrderFinished()))
			{
				this.performingActions = true;
				this.PerformNextAction();
			}
			else
			{
				this.GetNextAction();
			}
		}

		protected override void PerformNextAction3()
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					BaseAction action = ORK.Battle.Actions.NextPerformable();
					if(action != null)
					{
						if(!action.IsCastingAbility())
						{
							this.PerformAction(action);
						}
						else if(this.dynamicCombat)
						{
							this.PerformingAction(action);
						}
					}
					else
					{
						this.ActionFinished(null);
					}
				}
				else if(TurnBasedMode.Active == this.mode ||
					TurnBasedMode.MultiTurns == this.mode)
				{
					this.GetNextAction();
				}
			}
		}

		public override void PerformingAction(BaseAction action)
		{
			if(this.dynamicCombat &&
				(action == null || !action.isPerforming))
			{
				if(action != null)
				{
					action.isPerforming = true;
				}
				if(this.minTimeBetween > 0)
				{
					ORK.StartCoroutine(this.ActionFinished2(action));
				}
				else
				{
					this.ActionFinished(action);
				}
			}
		}

		protected IEnumerator ActionFinished2(BaseAction action)
		{
			yield return new WaitForSeconds(this.minTimeBetween);
			this.ActionFinished(action);
		}

		public override void ActionFinished(BaseAction action)
		{
			if(!ORK.Battle.BattleEnd &&
				(action == null || !action.notifiedFinished ||
					ORK.Battle.WaitForLastAction))
			{
				if(ORK.Battle.Actions.Has())
				{
					if(action != null)
					{
						action.notifiedFinished = true;
					}
					this.PerformNextAction();
				}
				else if(TurnBasedMode.MultiTurns == this.mode)
				{
					if(action != null)
					{
						action.notifiedFinished = true;
					}
					if(this.selectingCombatant != null &&
						this.selectingCombatant.Actions.CanChoose)
					{
						this.GetNextAction();
					}
					else if(this.selectingCombatant != null &&
						this.selectingCombatant.Battle.CanEndTurn)
					{
						this.selectingCombatant.Battle.EndTurn(this.StartTurn);
					}
					else
					{
						this.StartTurn();
					}
				}
				else if(TurnBasedMode.Active == this.mode)
				{
					if(this.selectingCombatant == null ||
						!this.selectingCombatant.Actions.IsChoosing ||
						!this.selectingCombatant.Actions.CanChoose)
					{
						if(action != null)
						{
							action.notifiedFinished = true;
						}

						if(this.selectingCombatant != null &&
							this.selectingCombatant.Battle.CanEndTurn)
						{
							this.selectingCombatant.Battle.EndTurn(this.GetNextAction);
						}
						else
						{
							this.GetNextAction();
						}
					}
				}
				else if(!this.dynamicCombat || this.TurnOrderFinished())
				{
					if(action != null)
					{
						action.notifiedFinished = true;
					}
					this.TurnEnd();
				}
			}
		}

		private void TurnEnd()
		{
			if(this.performedOrder.Count > 0)
			{
				Combatant combatant = this.performedOrder[0];
				this.performedOrder.RemoveAt(0);
				if(combatant.Battle.CanEndTurn)
				{
					combatant.Battle.EndTurn(this.TurnEnd);
				}
				else
				{
					this.TurnEnd();
				}
			}
			else
			{
				this.StartTurn();
			}
		}


		/*
		============================================================================
		HUD functions
		============================================================================
		*/
		public string GetTurnOrderInfo(Combatant combatant)
		{
			if(this.selectingCombatant == combatant)
			{
				return this.turnOrderSelectingInfo[ORK.Game.Language];
			}
			else
			{
				if(TurnBasedMode.MultiTurns == this.mode)
				{
					List<Combatant> list = this.GetTurnOrder(-1);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] == combatant)
						{
							return TextHelper.GetCounter(this.turnOrderCounter, i - 1);
						}
					}
				}
				// other
				else
				{
					for(int i = 0; i < this.turnOrder.Count; i++)
					{
						if(!this.turnOrder[i].Dead &&
							this.turnOrder[i] == combatant)
						{
							return TextHelper.GetCounter(this.turnOrderCounter, i);
						}
					}
				}
			}

			return this.turnOrderNoneInfo[ORK.Game.Language];
		}

		public List<Combatant> GetTurnOrder(int maximumLength)
		{
			List<Combatant> list = new List<Combatant>();

			// add currently selecting combatant
			if(this.selectingCombatant != null &&
				!this.selectingCombatant.Dead)
			{
				list.Add(this.selectingCombatant);
			}

			// multi-turn battle
			if(TurnBasedMode.MultiTurns == this.mode)
			{
				// create dummy list
				List<Combatant> tmpList = new List<Combatant>();
				if(this.selectingCombatant != null &&
					!this.selectingCombatant.Dead)
				{
					tmpList.Add(this.selectingCombatant);
				}
				// make sure first combatant is added
				else if(this.turnOrder.Count > 0)
				{
					list.Add(this.turnOrder[0]);
				}

				for(int i = 0; i < this.turnOrder.Count; i++)
				{
					if(!this.turnOrder[i].Dead)
					{
						tmpList.Add(this.turnOrder[i]);
						this.turnOrder[i].Battle.TurnValueDummy = this.turnOrder[i].Battle.TurnValue;
					}
				}

				if(tmpList.Count > 0)
				{
					// reset first combatant
					if(!this.invertTurnOrder)
					{
						tmpList[0].Battle.TurnValueDummy = 0;
					}

					// add all at least once
					if(maximumLength < 0)
					{
						List<Combatant> added = new List<Combatant>();
						added.Add(tmpList[0]);

						while(added.Count != tmpList.Count)
						{
							this.MultiTurnsOrderForecast(tmpList);
							list.Add(tmpList[0]);
							if(!this.invertTurnOrder)
							{
								tmpList[0].Battle.TurnValueDummy = 0;
							}
							if(!added.Contains(tmpList[0]))
							{
								added.Add(tmpList[0]);
							}
						}
					}
					// repeat dummy cycles until list is full
					else
					{
						while(list.Count < maximumLength)
						{
							this.MultiTurnsOrderForecast(tmpList);
							list.Add(tmpList[0]);
							if(!this.invertTurnOrder)
							{
								tmpList[0].Battle.TurnValueDummy = 0;
							}
						}
					}
				}
			}
			// other
			else
			{
				if(maximumLength < 0 || this.turnOrder.Count < maximumLength)
				{
					for(int i = 0; i < this.turnOrder.Count; i++)
					{
						if(!this.turnOrder[i].Dead)
						{
							list.Add(this.turnOrder[i]);
						}
					}
				}
				else
				{
					for(int i = 0; i < maximumLength - 1; i++)
					{
						if(!this.turnOrder[i].Dead)
						{
							list.Add(this.turnOrder[i]);
						}
					}
				}
			}

			return list;
		}

		private void MultiTurnsOrderForecast(List<Combatant> list)
		{
			if(this.invertTurnOrder)
			{
				if(list.Count > 0)
				{
					for(int i = 1; i < list.Count; i++)
					{
						list[i].Battle.TurnValueDummy -= list[0].Battle.TurnValueDummy;
					}
					list[0].Battle.TurnValueDummy = ORK.Formulas.Get(this.turnFormulaID).
							Calculate(new FormulaCall(this.initialValueTurn, list[0], list[0]));
				}
			}
			else
			{
				for(int i = 0; i < list.Count; i++)
				{
					list[i].Battle.TurnValueDummy += ORK.Formulas.Get(this.turnFormulaID).
						Calculate(new FormulaCall(this.initialValueTurn, list[i], list[i]));
				}
			}
			list.Sort(new DummyTurnSorter(this.invertTurnOrder));
		}
	}
}
