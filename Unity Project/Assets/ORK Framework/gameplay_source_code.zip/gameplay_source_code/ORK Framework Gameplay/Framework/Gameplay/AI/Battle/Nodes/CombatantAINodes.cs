
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Check Turn", "Checks a combatant's turn number (i.e. the number of actions/turns performed by the combatant).\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckTurnStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// turn
		[ORKEditorHelp("Every n Turns", "The check is true every set number of turns " +
			"(e.g. every 2nd turn when 'turn' is set to 2).\n" +
			"If disabled, the check is true at the specific turn number " +
			"(e.g. the 5th turn of a combatant).", "")]
		[ORKEditorInfo(separator=true, labelText="Turn")]
		public bool everyTurn = false;

		[ORKEditorHelp("Turn", "Set the turn that will be checked for.", "")]
		[ORKEditorLimit(1, false)]
		public int turn = 1;

		[ORKEditorHelp("Check Type", "Checks if the turn is equal, not equal, less or greater defined turn.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("everyTurn", false, endCheckGroup=true)]
		public ValueCheck check = ValueCheck.IsEqual;

		public CheckTurnStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(ref any,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check turns of all possible targets, add to found targets
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					((this.everyTurn && (list[i].Battle.Turn % this.turn) == 0) ||
					(!this.everyTurn && ValueHelper.CheckValue(list[i].Battle.Turn, this.turn, this.check))))
				{
					any = true;
					if(!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found: " + (this.everyTurn ?
				(this.turn == 1 ? "Every turn" : "Every " + this.turn + " turns") :
				this.check + " " + this.turn);
		}
	}

	[ORKEditorHelp("Check Turn Value", "Checks a combatant's turn value.\n" +
		"The turn value is used in to generate the turn order in 'Turn Based Battles' using 'Multi Turns'." +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckTurnValueStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;


		[ORKEditorHelp("Check Type", "Checks if the turn value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the turn value is between two defined values, including the values.\n" +
			"Range exclusive checks if the turn value is between two defined values, excluding the values.\n" +
			"Approximately checks if the turn value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public AIFloat turn = new AIFloat();

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public AIFloat turn2;

		public CheckTurnValueStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, user, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(ref any, user,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check turns of all possible targets, add to found targets
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					ValueHelper.CheckVariableValue(
						this.useAverage ?
							(this.onlyBattle ?
								list[i].Group.AverageBattleTurnValue :
								list[i].Group.AverageTurnValue) :
							list[i].Battle.TurnValue,
						this.turn.GetValue(user, list[i]),
						this.turn2 != null ? this.turn2.GetValue(user, list[i]) : 0,
						this.check))
				{
					any = true;
					if(!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found: " +
				this.check.ToString() + " " + this.turn.GetInfoText() +
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Check Action Bar", "Checks a combatant's action bar.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckActionBarStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		[ORKEditorHelp("Used Action Bar", "Check the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.\n" +
			"E.g. use this to check if a combatant already chose actions by checking if the used action bar equals 0.", "")]
		public bool usedActionBar = false;

		[ORKEditorHelp("Use Average", "Use the average action bar value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;


		[ORKEditorHelp("Check Type", "Checks if the action bar value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the action bar value is between two defined values, including the values.\n" +
			"Range exclusive checks if the action bar value is between two defined values, excluding the values.\n" +
			"Approximately checks if the action bar value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public AIFloat turn = new AIFloat();

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public AIFloat turn2;

		public CheckActionBarStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, user, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(ref any, user,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check turns of all possible targets, add to found targets
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					ValueHelper.CheckVariableValue(
						this.useAverage ?
							(this.onlyBattle ?
								(this.usedActionBar ?
									list[i].Group.AverageBattleUsedActionBar :
									list[i].Group.AverageBattleActionBar) :
								(this.usedActionBar ?
									list[i].Group.AverageUsedActionBar :
									list[i].Group.AverageActionBar)) :
							(this.usedActionBar ?
								list[i].Battle.UsedActionBar :
								list[i].Battle.ActionBar),
						this.turn.GetValue(user, list[i]),
						this.turn2 != null ? this.turn2.GetValue(user, list[i]) : 0,
						this.check))
				{
					any = true;
					if(!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found: " +
				this.check.ToString() + " " + this.turn.GetInfoText() +
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Check Status", "Checks a combatant on certain status requirements, e.g. status value.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckStatusStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		[ORKEditorHelp("Force Knowledge", "Force status checks to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;


		// status
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[] {new StatusRequirement()};

		public CheckStatusStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, user, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(ref any, user,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					this.CheckRequirements(user, list[i]))
				{
					any = true;
					if(!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckRequirements(Combatant user, Combatant target)
		{
			if(!this.forceKnowledge &&
				ORK.GameSettings.bestiary.useBestiary &&
				ORK.GameSettings.bestiary.useInBattleAI &&
				user.IsPlayerControlled() && user.IsEnemy(target))
			{
				return StatusRequirement.CheckBestiary(target, this.req, this.needed);
			}
			return StatusRequirement.Check(target, this.req, this.needed);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}

	[ORKEditorHelp("Get Status Value", "The combatant with the highest or lowest value of a " +
		"selected status value will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Combatant")]
	public class GetStatusValueStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		[ORKEditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;


		// status
		[ORKEditorHelp("Status Value", "Select the status value that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int statusID = 0;

		[ORKEditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected status value will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the selected status value will be added to the target list.", "")]
		public bool getHighest = false;

		public GetStatusValueStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(user, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(user, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(user,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			currentStep = this.next;
			return null;
		}

		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			int tmpVal = this.getHighest ? int.MinValue : int.MaxValue;

			// check for highest/lowest status value
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge &&
						ORK.GameSettings.bestiary.useBestiary &&
						ORK.GameSettings.bestiary.useInBattleAI &&
						user.IsPlayerControlled() && user.IsEnemy(list[i]))
					{
						list[i].FindBestiaryEntry();
						if(list[i].Bestiary != null &&
							(list[i].Bestiary.IsComplete ||
							list[i].Bestiary.status.statusValues))
						{
							int statVal = list[i].Status[this.statusID].GetValue();
							if((this.getHighest && tmpVal < statVal) ||
								(!this.getHighest && tmpVal > statVal))
							{
								tmpVal = statVal;
								found = i;
							}
						}
					}
					else
					{
						int statVal = list[i].Status[this.statusID].GetValue();
						if((this.getHighest && tmpVal < statVal) ||
							(!this.getHighest && tmpVal > statVal))
						{
							tmpVal = statVal;
							found = i;
						}
					}
				}
			}

			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") +
				ORK.StatusValues.GetName(this.statusID);
		}
	}

	[ORKEditorHelp("Get Attack Attribute", "The combatant with the highest or lowest value of a " +
		"selected attack attribute will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Combatant")]
	public class GetAttackAttributeStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		[ORKEditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;


		// status
		[ORKEditorHelp("Attack Attribute", "Select the attack attribute that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, separator=true)]
		public int attributeID = 0;

		[ORKEditorHelp("Attribute", "Select the attribute that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, idFieldName="attributeID")]
		public int subID = 0;

		[ORKEditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected attack attribute will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"selected attack attribute will be added to the target list.", "")]
		public bool getHighest = false;

		public GetAttackAttributeStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(user, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(user, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(user,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			currentStep = this.next;
			return null;
		}

		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? Mathf.NegativeInfinity : Mathf.Infinity;

			// check for highest/lowest attribute
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge &&
						ORK.GameSettings.bestiary.useBestiary &&
						ORK.GameSettings.bestiary.useInBattleAI &&
						user.IsPlayerControlled() && user.IsEnemy(list[i]))
					{
						list[i].FindBestiaryEntry();
						if(list[i].Bestiary != null &&
							(list[i].Bestiary.IsComplete ||
							list[i].Bestiary.status.attackAttribute[this.attributeID].attribute[this.subID]))
						{
							float attrVal = list[i].Status.GetAttackAttribute(this.attributeID).GetValue(this.subID);
							if((this.getHighest && tmpVal < attrVal) ||
								(!this.getHighest && tmpVal > attrVal))
							{
								tmpVal = attrVal;
								found = i;
							}
						}
					}
					else
					{
						float attrVal = list[i].Status.GetAttackAttribute(this.attributeID).GetValue(this.subID);
						if((this.getHighest && tmpVal < attrVal) ||
							(!this.getHighest && tmpVal > attrVal))
						{
							tmpVal = attrVal;
							found = i;
						}
					}
				}
			}

			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") +
				ORK.AttackAttributes.GetName(this.attributeID, this.subID) +
				" (" + ORK.AttackAttributes.GetName(this.attributeID) + ")";
		}
	}

	[ORKEditorHelp("Get Defence Attribute", "The combatant with the highest or lowest value of a " +
		"selected defence attribute will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Combatant")]
	public class GetDefenceAttributeStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		[ORKEditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;


		// status
		[ORKEditorHelp("Defence Attribute", "Select the defence attribute that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, separator=true)]
		public int attributeID = 0;

		[ORKEditorHelp("Attribute", "Select the attribute that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, idFieldName="attributeID")]
		public int subID = 0;

		[ORKEditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected defence attribute will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"selected defence attribute will be added to the target list.", "")]
		public bool getHighest = false;

		public GetDefenceAttributeStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(user, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(user, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(user,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			currentStep = this.next;
			return null;
		}

		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? Mathf.NegativeInfinity : Mathf.Infinity;

			// check for highest/lowest attribute
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge &&
						ORK.GameSettings.bestiary.useBestiary &&
						ORK.GameSettings.bestiary.useInBattleAI &&
						user.IsPlayerControlled() && user.IsEnemy(list[i]))
					{
						list[i].FindBestiaryEntry();
						if(list[i].Bestiary != null &&
							(list[i].Bestiary.IsComplete ||
							list[i].Bestiary.status.defenceAttribute[this.attributeID].attribute[this.subID]))
						{
							float attrVal = list[i].Status.GetDefenceAttribute(this.attributeID).GetValue(this.subID);
							if((this.getHighest && tmpVal < attrVal) ||
								(!this.getHighest && tmpVal > attrVal))
							{
								tmpVal = attrVal;
								found = i;
							}
						}
					}
					else
					{
						float attrVal = list[i].Status.GetDefenceAttribute(this.attributeID).GetValue(this.subID);
						if((this.getHighest && tmpVal < attrVal) ||
							(!this.getHighest && tmpVal > attrVal))
						{
							tmpVal = attrVal;
							found = i;
						}
					}
				}
			}

			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") +
				ORK.DefenceAttributes.GetName(this.attributeID, this.subID) +
				" (" + ORK.DefenceAttributes.GetName(this.attributeID) + ")";
		}
	}

	[ORKEditorHelp("Compare Status Value", "Checks the status value of targets against the user's value and adds them to the target list.\n" +
		"E.g. add all enemies that have less HP than the user.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Combatant")]
	public class CompareStatusValueStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		[ORKEditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;


		// check failed
		[ORKEditorHelp("Use 'Failed' Next", "Enables using a different 'Next' step when the check fails.\n" +
			"If the check fails, the combatants that failed will be added to the found targets " +
			"(the previously found targets will also be filtered to only contain those who failed when using 'Check' found targets).", "")]
		[ORKEditorInfo(separator=true)]
		public bool useFailedNext = false;

		[ORKEditorInfo(hide=true)]
		[ORKEditorLayout("useFailedNext", true, endCheckGroup=true, setDefault=true, defaultValue=-1)]
		public int nextFail = -1;


		// status
		[ORKEditorHelp("Status Value", "Select the status value that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int statusID = 0;

		[ORKEditorHelp("Check Type", "Checks if target's status value is equal, not equal, less or greater than the user's status value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck check = ValueCheck.IsEqual;


		// percent
		[ORKEditorHelp("Check In", "Check either in percent of the maximum status value or the actual value.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public ValueSetter checkIn = ValueSetter.Value;

		[ORKEditorHelp("Use Percent Value", "Define a percent value that will be checked.\n" +
			"E.g. 50 to check the target's status value against 50 % of the user's status value.", "")]
		[ORKEditorLayout("checkIn", ValueSetter.Percent)]
		public bool usePercentValue = false;

		[ORKEditorInfo(labelText="Percent Value")]
		[ORKEditorLayout("usePercentValue", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public AIFloat percentValue;


		// check other
		[ORKEditorHelp("Check Other SV", "Check a different status value on the targets.\n" +
			"E.g. comparing the user's HP ('Status Value' setting) to the target's MP ('Target Status Value' setting).", "")]
		[ORKEditorInfo(separator=true)]
		public bool checkOther = false;

		[ORKEditorHelp("Target Status Value", "Select the status value that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue)]
		[ORKEditorLayout("checkOther", true, endCheckGroup=true)]
		public int targetStatusID = 0;

		public CompareStatusValueStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}

			bool any = false;
			List<Combatant> targets = this.GetTargetList(this.targetType,
				this.targetExcludeSelf, this.targetExcludeFoundTargets,
				user, allies, enemies, foundTargets);

			if(this.useFailedNext)
			{
				List<Combatant> validFound = new List<Combatant>();
				if(targets.Count == 0 &&
					(FoundTargets.Check == this.foundType ||
						FoundTargets.CheckKeep == this.foundType))
				{
					this.Check(ref any, user, foundTargets, validFound, true);
					validFound.Clear();
				}
				else
				{
					this.Check(ref any, user, targets, validFound, true);
				}

				if(any)
				{
					if(FoundTargets.Check == this.foundType)
					{
						List<Combatant> tmp = new List<Combatant>(foundTargets);
						foundTargets.Clear();
						this.Check(ref any, user, tmp, foundTargets, true);
					}
					else if(FoundTargets.CheckKeep == this.foundType)
					{
						this.Check(ref any, user, foundTargets, foundTargets, true);
					}
					for(int i = 0; i < validFound.Count; i++)
					{
						if(!foundTargets.Contains(validFound[i]))
						{
							foundTargets.Add(validFound[i]);
						}
					}

					currentStep = this.next;
				}
				else
				{
					if(FoundTargets.Check == this.foundType)
					{
						List<Combatant> tmp = new List<Combatant>(foundTargets);
						foundTargets.Clear();
						this.Check(ref any, user, tmp, foundTargets, false);
					}
					else if(FoundTargets.CheckKeep == this.foundType)
					{
						this.Check(ref any, user, foundTargets, foundTargets, false);
					}
					this.Check(ref any, user, targets, foundTargets, false);

					currentStep = this.nextFail;
				}
			}
			else
			{
				if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(foundTargets);
					foundTargets.Clear();
					this.Check(ref any, user, tmp, foundTargets, true);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, user, foundTargets, foundTargets, true);
				}

				// check all possible targets
				this.Check(ref any, user, targets, foundTargets, true);

				currentStep = this.next;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets, bool valid)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					bool doCheck = true;

					if(!this.forceKnowledge &&
						ORK.GameSettings.bestiary.useBestiary &&
						ORK.GameSettings.bestiary.useInBattleAI &&
						user.IsPlayerControlled() && user.IsEnemy(list[i]))
					{
						doCheck = false;
						list[i].FindBestiaryEntry();
						if(list[i].Bestiary != null &&
							(list[i].Bestiary.IsComplete ||
							list[i].Bestiary.status.statusValues))
						{
							doCheck = true;
						}
					}

					if(doCheck)
					{
						if(ValueSetter.Percent == this.checkIn)
						{
							if(this.usePercentValue)
							{
								float tmpValue = user.Status[this.statusID].GetValue() *
									(this.percentValue.GetValue(user, list[i]) / 100.0f);

								if(ValueHelper.CheckValue(
									list[i].Status[this.checkOther ? this.targetStatusID : this.statusID].GetValue(),
									tmpValue, this.check) == valid)
								{
									any = true;
									foundTargets.Add(list[i]);
								}
							}
							else if(ValueHelper.CheckValue(
								list[i].Status[this.checkOther ? this.targetStatusID : this.statusID].Percent,
								user.Status[this.statusID].Percent, this.check) == valid)
							{
								any = true;
								foundTargets.Add(list[i]);
							}
						}
						else
						{
							if(ValueHelper.CheckValue(
								list[i].Status[this.checkOther ? this.targetStatusID : this.statusID].GetValue(),
								user.Status[this.statusID].GetValue(), this.check) == valid)
							{
								any = true;
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.StatusValues.GetName(this.statusID) + " " + this.check +
				(this.checkOther ? " " + ORK.StatusValues.GetName(this.targetStatusID) : "");
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(this.useFailedNext)
			{
				if(index == 0)
				{
					return "Success";
				}
				else if(index == 1)
				{
					return "Failed";
				}
			}
			return "Next";
		}

		public override int GetNextCount()
		{
			return this.useFailedNext ? 2 : 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
	}

	[ORKEditorHelp("Add Temporary Ability", "Adds a temporary ability to a combatant.", "")]
	[ORKNodeInfo("Combatant")]
	public class AddTemporaryAbilityStep : BaseAIStep
	{
		[ORKEditorHelp("Ability", "Select the ability that will be added as temporary ability.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("Level", "The level of the ability that will be added.", "")]
		[ORKEditorLimit(1, false)]
		public int level = 1;

		[ORKEditorHelp("Auto Remove After", "The ability will automatically be removed after:" +
			"- None: Doesn't remove the ability automatically.\n" +
			"- Turn: Removes the ability after a defined amount of turns.\n" +
			"- Time: Removes the ability after a defined amount of time in seconds.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EndAfter removeType = EndAfter.None;

		[ORKEditorLayout("removeType", EndAfter.None, elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public AIFloat removeAfter;


		// target
		[ORKEditorHelp("Use Found Targets", "Add the temporary ability to the targets found by previous steps.\n" +
			"If disabled, you need to define the used target.", "")]
		[ORKEditorInfo(separator=true)]
		public bool onFound = false;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will add the temporary ability:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: Checks no combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("onFound", false, endCheckGroup=true)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public AddTemporaryAbilityStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			this.Change(user,
				this.onFound ?
					foundTargets :
					this.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						user, allies, enemies, foundTargets));
			currentStep = this.next;
			return null;
		}

		private void Change(Combatant user, List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Abilities.AddTemporaryAbility(this.abilityID, this.level, this.removeType,
						EndAfter.None != this.removeType ? this.removeAfter.GetValue(user, list[i]) : -1);
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.onFound ? "Found Targets: " : this.targetType.ToString() + ": ") +
				ORK.Abilities.Get(this.abilityID).GetName(level);
		}
	}

	[ORKEditorHelp("Remove Temporary Ability", "Removes a temporary ability from a combatant.", "")]
	[ORKNodeInfo("Combatant")]
	public class RemoveTemporaryAbilityStep : BaseAIStep
	{
		[ORKEditorHelp("Remove All", "All temporary abilities will be removed.", "")]
		public bool all = false;

		[ORKEditorHelp("Ability", "Select the ability that will be removes from temporary abilities.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int abilityID = 0;


		// target
		[ORKEditorHelp("Use Found Targets", "Remove the temporary ability from the targets found by previous steps.\n" +
			"If disabled, you need to define the used target.", "")]
		[ORKEditorInfo(separator=true)]
		public bool onFound = false;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will remove the temporary ability:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: Checks no combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("onFound", false, endCheckGroup=true)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public RemoveTemporaryAbilityStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			this.Change(this.onFound ?
				foundTargets :
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets));
			currentStep = this.next;
			return null;
		}

		private void Change(List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.all)
					{
						list[i].Abilities.ClearTemporaryAbilities();
					}
					else
					{
						list[i].Abilities.RemoveTemporaryAbility(this.abilityID);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.onFound ? "Found Targets: " : this.targetType.ToString() + ": ") +
				(this.all ? ": All" : ": " + ORK.Abilities.Get(this.abilityID).GetName());
		}
	}
}

