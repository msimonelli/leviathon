﻿
using UnityEngine;
using System.Collections.Generic;
using ORKFramework.Behaviours;

namespace ORKFramework
{
	public class GridCellPrefab : BaseData
	{
		[ORKEditorHelp("Prefab", "Select the prefab used for this grid cell type.", "")]
		public GameObject prefab;

		[ORKEditorHelp("Auto Add Blinker", "Add the component used to blink the prefab when highlighted when the prefab is instantiated.\n" +
			"If disabled, the component will be added when the cell is first highlighted.\n" +
			"Adding and initializing the blinker component on many cells can cause performance to go down shortly, " +
			"this setting lets you decide when to do this task.\n" +
			"If you don't use blink highlights, there's no need to auto add the blinker.", "")]
		public bool autoAddBlinker = false;


		// position
		[ORKEditorHelp("Position Offset", "The offset added to the position of the grid cell.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 positionOffset = Vector3.zero;

		[ORKEditorHelp("Local Position", "The position offset is in local space of the cell's game object.", "")]
		public bool localPosition = false;


		// rotation
		[ORKEditorHelp("Rotation Offset", "The offset added to the rotation of the grid cell.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 rotationOffset = Vector3.zero;

		[ORKEditorHelp("Use Prefab Rotation", "The rotation of the prefab will be added to the cell's rotation.", "")]
		public bool usePrefabRotation = false;


		// scale
		[ORKEditorHelp("Set Scale", "Set the scale of the grid cell.\n" +
			"If disabled, the scale of the prefab will be used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool setScale = false;

		[ORKEditorHelp("Scale", "The scale used for the grid cell.", "")]
		[ORKEditorLayout("setScale", true, endCheckGroup=true)]
		public Vector3 scale = Vector3.one;

		public GridCellPrefab()
		{

		}

		public GameObject CreatePrefabInstance(Transform parent)
		{
			if(parent != null &&
				this.prefab != null)
			{
				GameObject gameObject = (GameObject)GameObject.Instantiate(this.prefab,
					this.localPosition ?
						parent.TransformPoint(this.positionOffset) :
						parent.position + this.positionOffset,
					parent.transform.rotation);

				if(gameObject != null)
				{
					gameObject.transform.parent = parent;
					gameObject.transform.localEulerAngles = this.usePrefabRotation ?
						this.prefab.transform.eulerAngles + this.rotationOffset :
						this.rotationOffset;
					if(this.setScale)
					{
						gameObject.transform.localScale = this.scale;
					}
					gameObject.hideFlags = HideFlags.HideAndDontSave;

					if(this.autoAddBlinker)
					{
						TargetBlinker blinker = gameObject.AddComponent<TargetBlinker>();
						blinker.OneTimeInit();
						blinker.enabled = false;
					}
				}
				return gameObject;
			}
			return null;
		}
	}
}
