
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FactionSetting : BaseLanguageData, IContentSimple
	{
		// sympathy changes
		[ORKEditorHelp("Kill Member", "Killing a member of this faction will change the sympathy " +
			"(for the attacking factions) by this value.\n" +
			"The sympathy for all factions participating in the attack on the member will be changed.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		[ORKEditorInfo("Sympathy Changes", "Define how interactions with a member of a faction " +
			"change the faction's sympathy toward another faction.", "")]
		public float changeKill = -1;

		[ORKEditorHelp("Take Item", "Taking an item that belongs to this faction will change the sympathy by this value.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		public float changeItem = -1;

		[ORKEditorHelp("Take Money", "Taking money that belongs to this faction will change the sympathy by this value.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public float changeMoney = -1;


		// benefits
		[ORKEditorHelp("Benefit", "This benefit will be available for this faction.\n" +
			"If disabled, the benefit wont be available.\n" +
			"The first available benefit with suitable range will be used.", "")]
		[ORKEditorInfo("Sympathy Benefits", "You can add faction benefits to this faction.\n" +
			"A benefit is used if the sympathy value this faction has for the player is within the range of the benefit.", "",
			endFoldout=true)]
		[ORKEditorArray(ORKDataType.FactionBenefit)]
		public bool[] benefits = new bool[ORK.FactionBenefits.Count];


		// phase change events
		[ORKEditorHelp("Phase Start Event", "Select the ORK phase change event that " +
			"will be performed when this faction's phase starts.\n" +
			"Phase change events are used in 'Phase' battles to animate the start and end of a faction's phase.", "")]
		[ORKEditorInfo("Phase Change Events", "Phase change events are used in 'Phase' battles to animate the start and end of a faction's phase.\n" +
			"Define this faction's phase start and phase end events.", "")]
		public ORKPhaseChangeEvent phaseStartAsset;

		[ORKEditorHelp("Phase End Event", "Select the ORK phase change event that " +
			"will be performed when this faction's phase ends.\n" +
			"Phase change events are used in 'Phase' battles to animate the start and end of a faction's phase.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public ORKPhaseChangeEvent phaseEndAsset;

		
		// faction texts
		[ORKEditorInfo("Faction Texts", "Faction texts can be used in different texts to add faction based information or text formats.\n" +
			"You can use the faction texts in other text definitions (e.g. 'Combatant' type HUDs) using the '%ft' text codes.\n" +
			"E.g. %ft0% = faction text 0, %ft1% = faction text 1, etc.\n" +
			"If the faction text codes are available is noted above the texts in their custom text code definitions.", "", label=new string[] {
				"%n = faction name, %d = faction description, %i = faction icon"
		})]
		[ORKEditorArray(false, "Add Faction Text", "Adds a faction text to this faction.", "",
			"Remove", "Removes this faction text.", "",
			foldout=true, foldoutText=new string[] {
				"Text", "Define this faction text.", ""
		})]
		public FactionText[] factionText = new FactionText[0];

		public FactionSetting()
		{

		}

		public FactionSetting(string n) : base(n)
		{

		}


		/*
		============================================================================
		Faction text functions
		============================================================================
		*/
		public string GetFactionText(int index)
		{
			if(index >= 0 &&
				index < this.factionText.Length)
			{
				return this.factionText[index].text[ORK.Game.Language].
					Replace("%n", this.GetName()).
					Replace("%d", this.GetDescription()).
					Replace("%i", this.GetIconTextCode());
			}
			return "";
		}

		public string ReplaceFactionTexts(string text)
		{
			if(text.Contains("%ft"))
			{
				int replace = TextHelper.NextSpecial(ref text, "%ft", 0, "%");
				while(replace != -2)
				{
					text = text.Replace("%ft" + replace + "%", this.GetFactionText(replace));
					replace = TextHelper.NextSpecial(ref text, "%ft", 0, "%");
				}
			}
			return text;
		}

		public static string ReplaceFactionTextsEmpty(string text)
		{
			if(text.Contains("%ft"))
			{
				int replace = TextHelper.NextSpecial(ref text, "%ft", 0, "%");
				while(replace != -2)
				{
					text = text.Replace("%ft" + replace + "%", "");
					replace = TextHelper.NextSpecial(ref text, "%ft", 0, "%");
				}
			}
			return text;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}

		public string GetIconTextCode()
		{
			return TextCode.FactionIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
