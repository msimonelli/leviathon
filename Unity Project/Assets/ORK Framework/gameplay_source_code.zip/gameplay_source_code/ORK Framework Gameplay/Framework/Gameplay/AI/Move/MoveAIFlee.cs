﻿
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveAIFlee : BaseData
	{
		[ORKEditorHelp("Use Flee", "The flee settings are enabled.\n" +
			"The combatant will flee (run into the opposite direction) from a target if certain level conditions are met.", "")]
		public bool enabled = false;

		[ORKEditorHelp("Flee Time (s)", "The time in seconds the combatant will flee from the target.\n" +
			"The combatant will ignore detections and will simply run into the opposite direction.\n" +
			"Set to 0 to ignore flee time and still use detections.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("enabled", true)]
		public float fleeTime = 2;

		[ORKEditorHelp("Prevent Cornered", "The combatant will try to prevent being cornered.\n" +
			"I.e. if the combatant can't move, it'll try to move into different directions, e.g. fleeing toward the enemy.", "")]
		public bool preventCornered = false;


		// flee range
		[ORKEditorHelp("Use Flee Range", "The combatant will only flee within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the flee range, the combatant will return to its start position." +
			"If disabled, there is no limit to the flee range.", "")]
		[ORKEditorInfo("Flee Range", "Optionally only flee within a defined range of the combatant's start position.", "")]
		public bool useRange = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useRange", true, endCheckGroup=true, autoInit=true)]
		public Range range;


		// stop range
		[ORKEditorHelp("Use Stop Range", "The combatant will stop when being outside a defined range to the target it flees from." +
			"If disabled, the combatant will keep fleeing from the target until the flee time is up.", "")]
		[ORKEditorInfo("Stop Range", "Optionally stop when being outside a defined range to the target.", "")]
		public bool useStopRange = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useStopRange", true, endCheckGroup=true, autoInit=true)]
		public Range stopRange;


		// conditions
		[ORKEditorHelp("Conditions Needed", "Select if all or just one condition must be valid to flee from the target.", "")]
		[ORKEditorInfo("Flee Conditions", "Optionally only flee when defined conditions are valid.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorArray(false, "Add Flee Condition", "Adds a flee condition.\n" +
			"You can use multiple conditions to determine if the combatant flees from the target.", "",
			"Remove", "Removes this flee condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Flee Condition", "Flee conditions determine if the combatant flees from the target.", ""
			})]
		public MoveCondition[] condition = new MoveCondition[0];

		public MoveAIFlee()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useFlee"))
			{
				data.Get("useFlee", ref this.enabled);
				data.Get("fleeNeeded", ref this.needed);
				DataObject[] tmpCondition = data.GetFileArray("fleeCondition");
				if(tmpCondition != null)
				{
					this.condition = new MoveCondition[tmpCondition.Length];
					for(int i = 0; i < this.condition.Length; i++)
					{
						this.condition[i] = new MoveCondition();
						this.condition[i].SetData(tmpCondition[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Flee functions
		============================================================================
		*/
		public bool IsFlee(Combatant combatant, Combatant target)
		{
			if(this.enabled)
			{
				if(this.condition != null && this.condition.Length > 0)
				{
					for(int i = 0; i < this.condition.Length; i++)
					{
						if(this.condition[i].IsValid(combatant, target))
						{
							if(Needed.One == this.needed)
							{
								return true;
							}
						}
						else if(Needed.All == this.needed)
						{
							return false;
						}
					}

					if(Needed.All == this.needed)
					{
						return true;
					}
					else if(Needed.One == this.needed)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool IsInRange(Vector3 startPosition, Combatant combatant)
		{
			return !this.useRange ||
				this.range == null ||
				this.range.InRange(startPosition, combatant);
		}

		public bool IsOutOfRange(Vector3 startPosition, Combatant combatant)
		{
			return this.useRange &&
				this.range != null &&
				this.range.OutOfRange(startPosition, combatant);
		}

		public void Use(MoveAIComponent moveAI)
		{
			if(this.fleeTime > 0)
			{
				moveAI.fleeTimeout -= ORK.Game.DeltaMovementTime;

				// out of flee range, back to start position
				if(this.IsOutOfRange(moveAI.startPosition, moveAI.combatant))
				{
					moveAI.fleeTimeout = -1;
					moveAI.ClearTarget(false);

					moveAI.SetMode(MoveAIMode.Waypoint);
					moveAI.SetMovePosition(moveAI.startPosition);
				}
				// time's up, stop
				else if(moveAI.fleeTimeout <= 0 ||
					(this.useStopRange && this.range.OutOfRange(moveAI.combatant, moveAI.TargetCombatant)))
				{
					moveAI.fleeTimeout = -1;
					moveAI.ClearTarget(false);
				}
				else
				{
					if(this.preventCornered)
					{
						moveAI.CheckStuck();
					}
					if(this.useStopRange &&
						this.stopRange.InRange(moveAI.combatant, moveAI.TargetCombatant))
					{
						moveAI.UpdateTargetPosition(true);
					}
				}
			}
		}
	}
}
