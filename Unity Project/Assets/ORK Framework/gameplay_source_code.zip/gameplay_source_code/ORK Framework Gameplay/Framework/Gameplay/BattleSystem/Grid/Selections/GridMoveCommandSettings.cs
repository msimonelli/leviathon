﻿
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridMoveCommandSettings : BaseData
	{
		// settings
		[ORKEditorHelp("Use Only Once", "A combatant can use the move command only once per turn.\n" +
			"If disabled, the combatant can move multiple times (if the move range allows it).", "")]
		public bool useOnlyOnce = false;

		[ORKEditorHelp("Allow Cancel", "The target cell selection can be canceled using the 'Cancel' key defined in the game controls.", "")]
		public bool allowCancel = false;

		[ORKEditorHelp("Block Action Use", "Using actions is blocked for the combatant during the grid cell selection.", "")]
		public bool blockActionUse = false;

		[ORKEditorHelp("Start From User", "The target cell selection will always start from the user's cell.\n" +
			"If disabled, a previously selected cell (also from other cell selections) will be used.", "")]
		public bool startFromUser = true;

		[ORKEditorHelp("Rotate To Cell", "Rotate the user to the selected cell.\n" +
			"If disabled, a previously selected cell (also from other cell selections) will be used.", "")]
		public bool rotateToCell = false;

		[ORKEditorHelp("Grid Rotation", "Limit the rotation to the nearest grid rotation during grid battles.", "")]
		[ORKEditorLayout("rotateToCell", true, endCheckGroup=true)]
		public bool gridRotation = false;

		[ORKEditorHelp("Examine Cell", "Display the cell info text for the selected cell ('Examine Grid' settings).", "")]
		public bool examineCell = false;

		[ORKEditorHelp("Examine Cell Combatant", "Display the combatant info dialogue for the selected cell's combatant ('Examine Grid' settings).\n" +
			"Please note that this only shows the information dialogue and " +
			"doesn't show cell highlights (e.g. move range of a combatant).", "")]
		public bool examineCellCombatant = false;


		// pathfinding
		[ORKEditorHelp("Use Shortest Path", "Use the shortest path to a cell if multiple paths with the same move costs are available.\n" +
			"If disabled, the first path that was found will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Pathfinding Settings")]
		public bool useShortestPath = false;

		[ORKEditorHelp("Move Over Allies", "A combatant can move over cells that are currently occupied by allied combatants.", "")]
		public bool moveOverAllies = false;

		[ORKEditorHelp("Move Over Enemies", "A combatant can move over cells that are currently occupied by enemy combatants.", "")]
		public bool moveOverEnemies = false;

		[ORKEditorHelp("Diagonal Move", "Diagonal movement is allowed in 'Square' type grids.", "")]
		[ORKEditorLayout("battlegrid:square", setDefault=true, defaultValue=false)]
		public bool squareDiagonalMove = false;

		[ORKEditorHelp("Blocking Combatants", "Combatants blocking the path will prevent diagonal movement around them.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("squareDiagonalMove", true, endCheckGroup=true)]
		public bool squareDiagonalMoveBlockingCombatants = true;


		// camera control target
		[ORKEditorHelp("Camera Control Target", "Changes the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[ORKEditorInfo("Camera Control Target", "Optionally change the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		public bool cameraControlTarget = false;

		[ORKEditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		[ORKEditorLayout("cameraControlTarget", true)]
		public bool ownControlTargetTransition = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownControlTargetTransition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public CameraControlTargetTransition controlTargetTransition;


		// default move range
		[ORKEditorInfo("Default Move Range", "Define the default base grid move range for all combatants.\n" +
			"The grid move range defines how far a combatant can move when using the move command in grid battles.\n" +
			"The base move range can be changed through grid move range bonuses applied from status bonuses.\n" +
			"Can be overridden by each individual combatant.", "",
			endFoldout=true)]
		public FloatValue moveRange = new FloatValue();


		// default battle animation
		[ORKEditorHelp("Animate Grid Move", "The grid move command will perform a series of battle events.", "")]
		[ORKEditorInfo("Default Battle Animation", "Define the default battle events used to animate the grid move command.", "")]
		public bool animate = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the grid move animation.\n" +
			"All battle events (passing the chance check) will be performed one by one.", "",
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {"Grid Move Battle Event",
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout("animate", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] battleEvent;


		// info text
		[ORKEditorHelp("Show Info Text", "An info text will be displayed while selecting a target cell for the move command.", "")]
		[ORKEditorInfo("Info Text", "Optionally display an info text box while the player selects a target cell for the move command.", "")]
		public bool showInfo = false;

		[ORKEditorInfo(separator=true, endFoldout=true, label=new string[] {
			"%un = user name, %ud = user description, %ui = user icon",
			"%cn = cell name, %cd = cell description, %ci = cell icon",
			"% = move cost (0), %1 = move cost (0.0), %2 = move cost (0.00)",
			"%r = move range (0), %r1 = move range (0.0), %r2 = move range (0.00)",
			"%m = max range (0), %m1 = max range (0.0), %m2 = max range (0.00)",
			"%new = range after move (0), %new1 = range after move (0.0), %new2 = range after move (0.00)"
		})]
		[ORKEditorLayout("showInfo", true, endCheckGroup=true, autoInit=true)]
		public InfoBoxChoice info;


		// accept dialogue
		[ORKEditorHelp("Show Accept Question", "A question dialogue will be displayed when a cell was accepted.\n" +
			"If the player accepts the question, the cell will be used, otherwise the cell selection will be resumed.", "")]
		[ORKEditorInfo("Accept Question Dialogue", "Optionally display an accept question dialogue to ask " +
			"if the player wants to use the accepted cell.", "")]
		public bool showAcceptQuestion = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showAcceptQuestion", true, endCheckGroup=true, autoInit=true)]
		public QuestionChoice acceptQuestion;


		// own cell selection
		[ORKEditorHelp("Own Cell Selection", "The move target selection uses a different cell selection setup.\n" +
			"If disabled, the cell selection will be used.", "")]
		[ORKEditorInfo("Cell Selection", "The move target selection can optionally override the cell selection settings.", "")]
		public bool ownCellSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCellSelection", true, endCheckGroup=true, autoInit=true)]
		public GridCellSelectionSettings selection;


		// in-game
		private GridMoveShortcut gridMoveShortcut;

		private BattleGridPathFinder path;

		private GameObject previousCameraControlTarget;

		private NotifyBool notify;


		// selection
		private bool canSelect = true;

		private bool isSelecting = false;

		private List<BattleGridCellComponent> selectedPath;

		private SelectGridCellBool selectCellFunction;

		private SelectGridCell acceptCellFunction;

		private GridCellCheck acceptCheckFunction;


		public GridMoveCommandSettings()
		{

		}

		public void Clear()
		{
			this.CloseInfoBox();
			this.StopHighlights();

			if(this.isSelecting)
			{
				if(this.blockActionUse &&
					ORK.BattleSystem.gridSettings.SelectingCombatant != null)
				{
					ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
				}
				ORK.Battle.Grid.GridChanged -= this.GridChanged;
				this.isSelecting = false;
			}

			this.canSelect = true;
			this.gridMoveShortcut = null;
			this.previousCameraControlTarget = null;
		}

		public void GridChanged()
		{
			BattleGridCellComponent tmpCell = ORK.BattleSystem.gridSettings.SelectedCell;
			this.StopHighlights();
			ORK.BattleSystem.gridSettings.SelectedCell = null;
			if(this.selectedPath != null &&
				this.selectedPath.Count > 0)
			{
				this.selectedPath.Clear();
			}

			if(this.path != null)
			{
				this.path.CreateMoveRange(ORK.BattleSystem.gridSettings.SelectingCombatant, false);
				BattleGridHelper.Highlight(this.path.availableTargets, GridHighlightType.MoveRange);
				BattleGridHelper.Highlight(this.path.blockedCells, GridHighlightType.MoveRangeBlocked);
				BattleGridHelper.Highlight(this.path.passableCells, GridHighlightType.MoveRangePassable);
			}
			this.SelectCell(tmpCell, true);
		}


		/*
		============================================================================
		GUI box functions
		============================================================================
		*/
		private string InfoReplace(string text, float cost, float newRange)
		{
			return text.
				Replace("%un", ORK.BattleSystem.gridSettings.SelectingCombatant.GetName()).
				Replace("%ud", ORK.BattleSystem.gridSettings.SelectingCombatant.GetDescription()).
				Replace("%ui", ORK.BattleSystem.gridSettings.SelectingCombatant.GetIconTextCode()).
				Replace("%cn", ORK.BattleSystem.gridSettings.SelectedCell.Settings.GetName()).
				Replace("%cd", ORK.BattleSystem.gridSettings.SelectedCell.Settings.GetDescription()).
				Replace("%ci", ORK.BattleSystem.gridSettings.SelectedCell.Settings.GetIconTextCode()).
				Replace("%new2", newRange.ToString("0.00")).
				Replace("%new1", newRange.ToString("0.0")).
				Replace("%new", newRange.ToString("0")).
				Replace("%m2", ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRangeMax.ToString("0.00")).
				Replace("%m1", ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRangeMax.ToString("0.0")).
				Replace("%m", ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRangeMax.ToString("0")).
				Replace("%r2", ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRange.ToString("0.00")).
				Replace("%r1", ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRange.ToString("0.0")).
				Replace("%r", ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRange.ToString("0")).
				Replace("%2", cost.ToString("0.00")).
				Replace("%1", cost.ToString("0.0")).
				Replace("%", cost.ToString("0"));
		}

		private void ShowInfoBox(float cost)
		{
			if(this.showInfo)
			{
				float newRange = ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRange - cost;
				string tmpTitle = this.info.useTitle ?
					this.InfoReplace(this.info.title[ORK.Game.Language], cost, newRange) : "";
				string tmpText = this.InfoReplace(this.info.infoText[ORK.Game.Language], cost, newRange);

				this.info.Show(tmpTitle, tmpText, null);
			}
		}

		private void CloseInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Close();
			}
		}


		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public bool GetGridMoveBattleEvent(ref List<BattleEvent> list, Combatant user)
		{
			if(this.animate && this.battleEvent != null)
			{
				for(int i = 0; i < this.battleEvent.Length; i++)
				{
					this.battleEvent[i].GetEvent(ref list, user);
				}
			}
			return false;
		}


		/*
		============================================================================
		Move selection functions
		============================================================================
		*/
		public void Start(Combatant combatant, GridMoveShortcut gridMoveShortcut, NotifyBool notify)
		{
			if(this.path == null)
			{
				this.path = new BattleGridPathFinder(
					ORK.BattleSystem.gridHighlights.moveRangeBlockedHighlight.enable ||
					ORK.BattleSystem.gridHighlights.moveRangePassableHighlight.enable);
			}

			ORK.BattleSystem.gridSettings.InitSelection(GridSelectionType.Move, combatant);
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;

			this.notify = notify == null && combatant.BattleMenu.IsOpen ?
				combatant.BattleMenu.EndGridMoveSelectionClose : notify;
			ORK.BattleSystem.gridSettings.SelectingCombatant.BattleMenu.CloseSilent();

			this.gridMoveShortcut = gridMoveShortcut;
			if(this.gridMoveShortcut == null)
			{
				this.gridMoveShortcut = ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.GridMoveShortcut;
			}
			else
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.GridMoveShortcut = this.gridMoveShortcut;
			}
			ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.Active = this.gridMoveShortcut;

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
			}

			if(this.blockActionUse)
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = true;
			}

			this.path.CreateMoveRange(ORK.BattleSystem.gridSettings.SelectingCombatant, false);
			BattleGridHelper.Highlight(this.path.availableTargets, GridHighlightType.MoveRange);
			BattleGridHelper.Highlight(this.path.blockedCells, GridHighlightType.MoveRangeBlocked);
			BattleGridHelper.Highlight(this.path.passableCells, GridHighlightType.MoveRangePassable);

			BattleGridCellComponent tmpCell = ORK.BattleSystem.gridSettings.SelectedCell;
			ORK.BattleSystem.gridSettings.SelectedCell = null;
			this.SelectCell(this.startFromUser || tmpCell == null ?
				this.path.startCell : tmpCell, true);

			this.isSelecting = true;
			ORK.Battle.Grid.GridChanged += this.GridChanged;
		}

		public void Restart(Combatant combatant)
		{
			if(ORK.BattleSystem.gridSettings.SelectingCombatant == combatant)
			{
				BattleGridCellComponent tmpCell = ORK.BattleSystem.gridSettings.SelectedCell;
				ORK.BattleSystem.gridSettings.SelectedCell = null;
				this.SelectCell(tmpCell, true);
			}
		}

		public void Close(bool accepted)
		{
			this.StopHighlights();
			ORK.InputKeys.ResetInputAxes(true);
			if(this.blockActionUse)
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
			}

			ORK.Battle.Grid.GridChanged -= this.GridChanged;
			this.ResetCameraControlTarget();
			this.isSelecting = false;
			if(ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.Active is GridMoveShortcut)
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.Active = null;
			}
			ORK.BattleSystem.gridSettings.ClearCellSelection();

			this.Clear();
			if(this.notify != null)
			{
				this.notify(accepted);
			}
		}

		private void StopHighlights()
		{
			this.StopSelectedCellHighlight();
			if(this.selectedPath != null &&
				this.selectedPath.Count > 0)
			{
				BattleGridHelper.StopHighlight(this.selectedPath, GridHighlightType.MovePath);
				this.selectedPath.Clear();
			}
			if(this.path != null)
			{
				BattleGridHelper.StopHighlight(this.path.availableTargets, GridHighlightType.MoveRange);
				BattleGridHelper.StopHighlight(this.path.blockedCells, GridHighlightType.MoveRangeBlocked);
				BattleGridHelper.StopHighlight(this.path.passableCells, GridHighlightType.MoveRangePassable);
				this.path.Clear();
			}
		}

		private void StopSelectedCellHighlight()
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != null)
			{
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.MoveSelection);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.NoMoveSelection);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.MoveSelectionPlayer);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.MoveSelectionAlly);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.MoveSelectionEnemy);
			}
		}

		private void UseSelectedCell()
		{
			GridMoveAction action = this.path.GetMoveAction(
				ORK.BattleSystem.gridSettings.SelectedCell,
				this.gridMoveShortcut);
			this.Close(true);
			action.User.BattleMenu.AddAction(action);
		}

		private void ResetCameraControlTarget()
		{
			if(this.cameraControlTarget &&
				this.previousCameraControlTarget != null &&
				(ORK.BattleSystem.gridSettings.SelectedCell == null ||
				ORK.Control.CameraControlTarget == ORK.BattleSystem.gridSettings.SelectedCell.gameObject))
			{
				ORK.Control.SetCameraControlTarget(this.previousCameraControlTarget,
					this.ownControlTargetTransition ? this.controlTargetTransition : null);
			}
			this.previousCameraControlTarget = null;
		}


		/*
		============================================================================
		Cell selection functions
		============================================================================
		*/
		public void Tick()
		{
			if(this.canSelect &&
				this.isSelecting &&
				ORK.BattleSystem.gridSettings.SelectingCombatant != null)
			{
				if(this.allowCancel &&
					ORK.InputKeys.Get(ORK.GameControls.menuControls.cancelKeyID).GetButton())
				{
					if(this.ownCellSelection)
					{
						this.selection.PlayCancelAudio();
					}
					else
					{
						ORK.BattleSystem.gridSettings.cellSelection.PlayCancelAudio();
					}

					this.Close(false);
				}
				else
				{
					if(ORK.BattleSystem.gridSettings.SelectedCell == null)
					{
						this.SelectCell(this.path.startCell, true);
					}
					if(this.ownCellSelection)
					{
						this.selection.SelectCell(
							this.path.startCell, ORK.BattleSystem.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false);
					}
					else
					{
						ORK.BattleSystem.gridSettings.cellSelection.SelectCell(
							this.path.startCell, ORK.BattleSystem.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false);
					}
				}
			}
		}

		public void SelectCell(BattleGridCellComponent cell, bool isHover)
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != cell)
			{
				// stop path highlight
				if(ORK.BattleSystem.gridHighlights.movePathHighlight.enable &&
					this.selectedPath != null)
				{
					BattleGridHelper.StopHighlight(this.selectedPath, GridHighlightType.MovePath);
					this.selectedPath.Clear();
				}
				// stop selection highlight
				this.StopSelectedCellHighlight();

				ORK.BattleSystem.gridSettings.SelectedCell = cell;

				// new highlights
				float cost = this.path.GetCost(ORK.BattleSystem.gridSettings.SelectedCell);
				if(ORK.BattleSystem.gridSettings.SelectedCell != null)
				{
					if(this.cameraControlTarget && !isHover)
					{
						ORK.Control.SetCameraControlTarget(ORK.BattleSystem.gridSettings.SelectedCell.gameObject,
							this.ownControlTargetTransition ? this.controlTargetTransition : null);
					}

					// rotation
					if(this.rotateToCell)
					{
						ORK.BattleSystem.gridSettings.RotateToSelectedCell(this.gridRotation);
					}

					if(this.path.availableTargets.Contains(ORK.BattleSystem.gridSettings.SelectedCell) &&
						cost <= ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRange)
					{
						if(ORK.BattleSystem.gridHighlights.movePathHighlight.enable)
						{
							if(this.selectedPath == null)
							{
								this.selectedPath = new List<BattleGridCellComponent>();
							}
							this.path.GetPath(ORK.BattleSystem.gridSettings.SelectedCell, ref this.selectedPath);
							this.selectedPath.Remove(ORK.BattleSystem.gridSettings.SelectedCell);
							BattleGridHelper.Highlight(this.selectedPath, GridHighlightType.MovePath);
						}
						if(ORK.BattleSystem.gridHighlights.moveSelectionHighlight.enable)
						{
							ORK.BattleSystem.gridSettings.SelectedCell.Highlight(
								ORK.BattleSystem.gridHighlights.GetSelectionHighlight(
									GridHighlightType.MoveSelection, ORK.BattleSystem.gridSettings.SelectedCell));
						}
					}
					else if(ORK.BattleSystem.gridHighlights.noMoveSelectionHighlight.enable)
					{
						ORK.BattleSystem.gridSettings.SelectedCell.Highlight(
							ORK.BattleSystem.gridHighlights.GetSelectionHighlight(
								GridHighlightType.NoMoveSelection, ORK.BattleSystem.gridSettings.SelectedCell));
					}
				}
				else
				{
					this.ResetCameraControlTarget();
				}
				this.ShowInfoBox(cost);

				if(this.examineCell ||
					this.examineCellCombatant)
				{
					ORK.BattleSystem.gridSettings.examine.ExternalExamine(
						ORK.BattleSystem.gridSettings.SelectedCell,
						this.examineCell, this.examineCellCombatant);
				}
			}
		}

		public void AcceptCell(BattleGridCellComponent cell)
		{
			if(this.CheckAcceptCell(cell))
			{
				this.canSelect = false;
				this.CloseInfoBox();

				if(ORK.BattleSystem.gridSettings.SelectedCell != cell)
				{
					this.SelectCell(cell, true);
				}
				if(this.showAcceptQuestion)
				{
					this.acceptQuestion.Show(
						ORK.BattleSystem.gridSettings.SelectingCombatant.GetName(),
						this.AcceptQuestionClosed);
				}
				else
				{
					this.UseSelectedCell();
				}
			}
			else
			{
				this.SelectCell(cell, true);
			}
		}

		public void AcceptQuestionClosed(bool accepted)
		{
			if(accepted)
			{
				this.UseSelectedCell();
			}
			else
			{
				this.ShowInfoBox(this.path.GetCost(ORK.BattleSystem.gridSettings.SelectedCell));
				this.canSelect = true;
			}
		}

		public bool CheckAcceptCell(BattleGridCellComponent cell)
		{
			return cell != null &&
				this.path.availableTargets.Contains(cell) &&
				this.path.GetCost(cell) <= ORK.BattleSystem.gridSettings.SelectingCombatant.Battle.GridMoveRange;
		}
	}
}
