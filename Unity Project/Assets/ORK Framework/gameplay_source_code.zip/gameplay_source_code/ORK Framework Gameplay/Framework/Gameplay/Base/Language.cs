
using UnityEngine;

namespace ORKFramework
{
	public class Language : BaseIndexData, IContentSimple
	{
		[ORKEditorHelp("Name", "The name of the language.\n" +
			"It is displayed in editors where you enter texts for this " +
			"language and in the language selection of the main menu.", "")]
		[ORKEditorInfo("Name/Icon", "Set the name and icon of the language.", "", 
			expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Description", "The description of the language.\n" +
			"It can be displayed in the language selection of the main menu.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string description = "";

		[ORKEditorHelp("Icon", "The icon of the language.\n" +
			"It is displayed in the language selection of the main menu.\n" +
			"Select none if no item should be displayed.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public Texture icon;
		
		
		// settings
		[ORKEditorHelp("Initial Language", "This language will be the initially selected language when starting the game.\n" +
			"If no language is set as initial language, the first language (index 0) will be used.", "")]
		[ORKEditorInfo("Language Settings", "Base settings for this language.", "", endFoldout=true, 
			callbackAfter="check:initiallanguage")]
		public bool initialLanguage = false;
		
		public Language()
		{
			
		}
		
		public Language(string n)
		{
			this.name = n;
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get{ return this.realID;}
		}

		public string GetName()
		{
			return this.name;
		}

		public string GetDescription()
		{
			return this.description;
		}
		
		public string GetIconTextCode()
		{
			return TextCode.LanguageIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.icon;
		}

		public GUIContent GetContent()
		{
			return new GUIContent(this.name, this.icon);
		}
	}
}
