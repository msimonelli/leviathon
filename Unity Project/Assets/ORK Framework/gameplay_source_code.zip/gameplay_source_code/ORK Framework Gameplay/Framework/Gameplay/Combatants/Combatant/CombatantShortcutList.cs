
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantShortcutList : ISaveData
	{
		private Combatant owner;


		// slots
		private Dictionary<int, IShortcut> slots;

		public CombatantShortcutList(Combatant owner)
		{
			this.owner = owner;
			this.slots = new Dictionary<int, IShortcut>();
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		private bool CheckShortcut(IShortcut shortcut)
		{
			return shortcut is MoneyShortcut ||
				(shortcut is AbilityShortcut &&
					this.owner.Abilities.Has((AbilityShortcut)shortcut)) ||
				((shortcut is ItemShortcut || shortcut is EquipShortcut) &&
					this.owner.Inventory.Has(shortcut)) ||
				shortcut is AbilityLinkShortcut ||
				shortcut is DefendShortcut ||
				shortcut is EscapeShortcut ||
				shortcut is NoneShortcut ||
				shortcut is GridMoveShortcut ||
				shortcut is GridOrientationShortcut ||
				shortcut is GridExamineShortcut;
		}

		private IShortcut GetRenewedShortcut(IShortcut shortcut)
		{
			if(shortcut is AbilityLinkShortcut)
			{
				((AbilityLinkShortcut)shortcut).UpdateAbility(this.owner);
				return shortcut;
			}
			else if(shortcut is AbilityShortcut)
			{
				return this.owner.Abilities.Get((AbilityShortcut)shortcut);
			}
			else if(shortcut is ItemShortcut)
			{
				if(this.owner.Inventory.Has(shortcut))
				{
					return this.owner.Inventory.GetItem(shortcut.ID);
				}
			}
			else if(shortcut is EquipShortcut)
			{
				if(this.owner.Inventory.Has(shortcut))
				{
					return this.owner.Inventory.GetEquipment((EquipShortcut)shortcut);
				}
			}
			else if(shortcut is MoneyShortcut)
			{
				if(this.owner.Inventory.Has(shortcut))
				{
					return this.owner.Inventory.GetMoneyShortcut(shortcut.ID);
				}
			}
			else if(shortcut is DefendShortcut ||
				shortcut is EscapeShortcut ||
				shortcut is NoneShortcut ||
				shortcut is GridMoveShortcut ||
				shortcut is GridOrientationShortcut ||
				shortcut is GridExamineShortcut)
			{
				return shortcut;
			}
			return null;
		}

		public void UpdateShortcuts()
		{
			if(this.slots != null)
			{
				List<int> keys = new List<int>(this.slots.Keys);
				for(int i = 0; i < keys.Count; i++)
				{
					if(ORK.ShortcutSettings.keepUnavailableShortcuts)
					{
						IShortcut shortcut = this.GetRenewedShortcut(this.slots[keys[i]]);
						if(shortcut != null)
						{
							this.slots[keys[i]] = shortcut;
						}
					}
					else
					{
						this.slots[keys[i]] = this.GetRenewedShortcut(this.slots[keys[i]]);
						if(this.slots[keys[i]] == null)
						{
							this.slots.Remove(keys[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Slot functions
		============================================================================
		*/
		public IShortcut this[int index]
		{
			get
			{
				if(this.slots.ContainsKey(index))
				{
					this.slots[index] = this.GetRenewedShortcut(this.slots[index]);
					return this.slots[index];
				}
				return null;
			}
			set
			{
				if(value == null)
				{
					this.slots.Remove(index);
				}
				else
				{
					if(this.slots.ContainsKey(index))
					{
						this.slots[index] = value;
					}
					else
					{
						this.slots.Add(index, value);
					}
				}
				this.owner.MarkHUDUpdate();
			}
		}

		public bool HasShortcut(int index)
		{
			return this.slots.ContainsKey(index) &&
				this.slots[index] != null &&
				this.CheckShortcut(this.slots[index]);
		}

		public bool Contains(IShortcut shortcut)
		{
			if(this.slots.ContainsValue(shortcut))
			{
				return true;
			}
			foreach(KeyValuePair<int, IShortcut> pair in this.slots)
			{
				if(pair.Value != null &&
					pair.Value.GetType().IsAssignableFrom(shortcut.GetType()) &&
					pair.Value.ID == shortcut.ID)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			foreach(KeyValuePair<int, IShortcut> pair in this.slots)
			{
				if(pair.Value != null)
				{
					data.Set(pair.Key.ToString(), pair.Value.SaveGame());
				}
			}

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.slots = new Dictionary<int, IShortcut>();
			if(data != null)
			{
				Dictionary<string, DataObject> tmp = data.GetData<DataObject>(typeof(DataObject));
				if(tmp != null && tmp.Count > 0)
				{
					foreach(KeyValuePair<string, DataObject> pair in tmp)
					{
						string typeInfo = "";
						pair.Value.Get(DataSerializer.TYPE, ref typeInfo);
						if(typeInfo.EndsWith("Shortcut"))
						{
							IShortcut shortcut = ReflectionTypeHandler.Instance.CreateInstance(
								System.Type.GetType("ORKFramework." + typeInfo)) as IShortcut;
							if(shortcut != null &&
								ShortcutHelper.CheckValidID(shortcut))
							{
								shortcut.LoadGame(pair.Value);
								if(shortcut is AbilityLinkShortcut)
								{
									((AbilityLinkShortcut)shortcut).UpdateAbility(this.owner);
								}
								this.slots.Add(int.Parse(pair.Key), shortcut);
							}
						}
					}
				}
			}
		}
	}
}
