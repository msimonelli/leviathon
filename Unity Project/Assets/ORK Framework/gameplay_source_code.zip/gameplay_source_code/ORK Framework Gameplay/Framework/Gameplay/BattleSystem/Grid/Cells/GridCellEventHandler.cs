﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridCellEventHandler
	{
		private int index = 0;

		private List<GridCellEventCall> cellEvents = new List<GridCellEventCall>();

		private List<Combatant> targets;

		private Notify finishedCallback;

		public GridCellEventHandler(BattleGridCellComponent cell, GridCellEventStartType startType)
		{
			cell.GetCellEvents(ref this.cellEvents, startType);
		}

		public GridCellEventHandler(List<BattleGridCellComponent> cells, GridCellEventStartType startType)
		{
			for(int i = 0; i < cells.Count; i++)
			{
				if(cells[i] != null)
				{
					cells[i].GetCellEvents(ref this.cellEvents, startType);
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public bool HasEvents
		{
			get { return this.cellEvents.Count > 0; }
		}


		/*
		============================================================================
		Event execution functions
		============================================================================
		*/
		public void Start(Combatant target, Notify finishedCallback)
		{
			this.finishedCallback = finishedCallback;
			this.targets = new List<Combatant>();
			this.targets.Add(target);
			this.NextEvent();
		}

		public void Start(List<Combatant> targets, Notify finishedCallback)
		{
			this.finishedCallback = finishedCallback;
			this.targets = targets;
			this.NextEvent();
		}

		private void NextEvent()
		{
			if(this.cellEvents != null &&
				this.index < this.cellEvents.Count &&
				this.cellEvents[this.index] != null)
			{
				this.cellEvents[this.index++].Start(this.targets, this.EventFinished);
			}
		}

		private void EventFinished()
		{
			if(this.index < this.cellEvents.Count)
			{
				this.NextEvent();
			}
			else if(this.finishedCallback != null)
			{
				this.finishedCallback();
			}
		}
	}
}
