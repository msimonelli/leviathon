
using UnityEngine;
using ORKFramework;
using ORKFramework.Formulas;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Status Value", "A combatant's current, base or maximum status value is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class StatusValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Status Value", "Select the status value that will be used as value.\n" +
			"You can use the current value or maximum value of the status value.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int id = 0;

		[ORKEditorHelp("Value Origin", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.", "")]
		public StatusValueOrigin svOrigin = StatusValueOrigin.Current;

		public StatusValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(StatusValueOrigin.Base == this.svOrigin)
				{
					value = c.Status[this.id].GetBaseValue();
				}
				else if(StatusValueOrigin.Current == this.svOrigin)
				{
					value = c.Status[this.id].GetValue();
				}
				else if(StatusValueOrigin.Maximum == this.svOrigin)
				{
					value = c.Status[this.id].GetMaxValue();
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(StatusValueOrigin.Base == this.svOrigin)
				{
					value = c.Status[this.id].GetBaseValue();
				}
				else if(StatusValueOrigin.Current == this.svOrigin)
				{
					value = c.Status[this.id].GetPreviewValue(false);
				}
				else if(StatusValueOrigin.Maximum == this.svOrigin)
				{
					value = c.Status[this.id].GetPreviewMaxValue();
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				this.svOrigin + " " + ORK.StatusValues.GetName(this.id);
		}
	}

	[ORKEditorHelp("Random Status Value", "A random value between two status values of combatants is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class RandomStatusValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorHelp("As Int", "The random value will be used as an integer (i.e. whole number).\n" +
			"If disabled, the random value will be a float.", "")]
		public bool asInt = false;


		// value 1
		[ORKEditorInfo(separator=true, labelText="Status Value 1")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Status Value 1", "Select the status value that will be used as value.\n" +
			"You can use the current value, base value or maximum value of the status value.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int id = 0;

		[ORKEditorHelp("Value Origin 1", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.", "")]
		public StatusValueOrigin svOrigin = StatusValueOrigin.Current;


		// value 2
		[ORKEditorInfo(separator=true, labelText="Status Value 2")]
		public FormulaStatusOrigin origin2 = new FormulaStatusOrigin();

		[ORKEditorHelp("Status Value 2", "Select the status value that will be used as value.\n" +
			"You can use the current value, base value or maximum value of the status value.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int id2 = 0;

		[ORKEditorHelp("Value Origin 2", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.", "")]
		public StatusValueOrigin svOrigin2 = StatusValueOrigin.Current;

		public RandomStatusValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(StatusValueOrigin.Base == this.svOrigin)
				{
					value = c.Status[this.id].GetBaseValue();
				}
				else if(StatusValueOrigin.Current == this.svOrigin)
				{
					value = c.Status[this.id].GetValue();
				}
				else if(StatusValueOrigin.Maximum == this.svOrigin)
				{
					value = c.Status[this.id].GetMaxValue();
				}

				c = this.origin2.GetCombatant(call);
				if(c != null)
				{
					float value2 = 0;
					if(StatusValueOrigin.Base == this.svOrigin2)
					{
						value2 = c.Status[this.id2].GetBaseValue();
					}
					else if(StatusValueOrigin.Current == this.svOrigin2)
					{
						value2 = c.Status[this.id2].GetValue();
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin2)
					{
						value2 = c.Status[this.id2].GetMaxValue();
					}

					if(value < value2)
					{
						ValueHelper.UseOperator(ref call.result,
							this.asInt ? (int)Random.Range(value, value2) : Random.Range(value, value2),
							this.formulaOperator);
					}
					else if(value > value2)
					{
						ValueHelper.UseOperator(ref call.result,
							this.asInt ? (int)Random.Range(value2, value) : Random.Range(value2, value),
							this.formulaOperator);
					}
					else
					{
						ValueHelper.UseOperator(ref call.result, this.asInt ? (int)value : value, this.formulaOperator);
					}
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(StatusValueOrigin.Base == this.svOrigin)
				{
					value = c.Status[this.id].GetBaseValue();
				}
				else if(StatusValueOrigin.Current == this.svOrigin)
				{
					value = c.Status[this.id].GetPreviewValue(false);
				}
				else if(StatusValueOrigin.Maximum == this.svOrigin)
				{
					value = c.Status[this.id].GetPreviewMaxValue();
				}

				c = this.origin2.GetCombatant(call);
				if(c != null)
				{
					float value2 = 0;
					if(StatusValueOrigin.Base == this.svOrigin2)
					{
						value2 = c.Status[this.id2].GetBaseValue();
					}
					else if(StatusValueOrigin.Current == this.svOrigin2)
					{
						value2 = c.Status[this.id2].GetPreviewValue(false);
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin2)
					{
						value2 = c.Status[this.id2].GetPreviewMaxValue();
					}

					if(value < value2)
					{
						ValueHelper.UseOperator(ref call.result,
							this.asInt ? (int)Random.Range(value, value2) : Random.Range(value, value2),
							this.formulaOperator);
					}
					else if(value > value2)
					{
						ValueHelper.UseOperator(ref call.result,
							this.asInt ? (int)Random.Range(value2, value) : Random.Range(value2, value),
							this.formulaOperator);
					}
					else
					{
						ValueHelper.UseOperator(ref call.result, this.asInt ? (int)value : value, this.formulaOperator);
					}
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				this.svOrigin + " " + ORK.StatusValues.GetName(this.id) + " ~ " +
				this.origin2.GetInfoText() + " " + this.svOrigin2 + " " +
				ORK.StatusValues.GetName(this.id2);
		}
	}

	[ORKEditorHelp("Attack Attribute", "A combatant's current attack attribute value is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class AttackAttributeStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Attack Attribute", "Select the attack attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, separator=true)]
		public int id = 0;

		[ORKEditorHelp("Attribute", "Select the attribute that will be used as value.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, idFieldName="id")]
		public int id2 = 0;

		public AttackAttributeStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				ValueHelper.UseOperator(ref call.result,
					c.Status.GetAttackAttribute(this.id).GetValue(this.id2),
					this.formulaOperator);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				ValueHelper.UseOperator(ref call.result,
					c.Status.GetAttackAttribute(this.id).GetPreviewValue(this.id2),
					this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				ORK.AttackAttributes.GetName(this.id) + " " +
				ORK.AttackAttributes.GetName(this.id, this.id2);
		}
	}

	[ORKEditorHelp("Defence Attribute", "A combatant's current defence attribute value is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class DefenceAttributeStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Defence Attribute", "Select the defence attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, separator=true)]
		public int id = 0;

		[ORKEditorHelp("Attribute", "Select the attribute that will be used as value.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, idFieldName="id")]
		public int id2 = 0;

		public DefenceAttributeStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				ValueHelper.UseOperator(ref call.result,
					c.Status.GetDefenceAttribute(this.id).GetValue(this.id2),
					this.formulaOperator);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				ValueHelper.UseOperator(ref call.result,
					c.Status.GetDefenceAttribute(this.id).GetPreviewValue(this.id2),
					this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				ORK.DefenceAttributes.GetName(this.id) + " " +
				ORK.DefenceAttributes.GetName(this.id, this.id2);
		}
	}

	[ORKEditorHelp("Level", "A combatant's current or maximum level (or class level) is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class LevelStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Class Level", "The class level of the combatant is used.\n" +
			"If disabled, the base level is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useClass = false;

		[ORKEditorHelp("Use Maximum", "The maximum level is used.\n" +
			"If disabled, the current level is used.", "")]
		public bool useMax = false;

		[ORKEditorHelp("Use Average", "Use the average level of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public LevelStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useClass)
				{
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ? c.Group.AverageBattleMaxClassLevel : c.Group.AverageBattleClassLevel;
						}
						else
						{
							value = this.useMax ? c.Group.AverageMaxClassLevel : c.Group.AverageClassLevel;
						}
					}
					else
					{
						value = this.useMax ? c.MaxClassLevel : c.ClassLevel;
					}
				}
				else
				{
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ? c.Group.AverageBattleMaxLevel : c.Group.AverageBattleLevel;
						}
						else
						{
							value = this.useMax ? c.Group.AverageMaxLevel : c.Group.AverageLevel;
						}
					}
					else
					{
						value = this.useMax ? c.MaxLevel : c.Level;
					}
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ? " Avg. " : " ") + (this.useMax ? "Max " : "") +
				(this.useClass ? "Class Level" : "Level");
		}
	}

	[ORKEditorHelp("Turn", "A combatant's current turn number is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class TurnStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Average", "Use the average turn number of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public TurnStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = c.Group.AverageBattleTurn;
					}
					else
					{
						value = c.Group.AverageTurn;
					}
				}
				else
				{
					value = c.Battle.Turn;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ? " Avg. Turn" : " Turn");
		}
	}

	[ORKEditorHelp("Check Turn", "Checks a combatant's turn.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckTurnStep : BaseFormulaCheckStep
	{
		// status value
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Average", "Use the average turn number of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;


		[ORKEditorHelp("Check Type", "Checks if the turn is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the turn is between two defined values, including the values.\n" +
			"Range exclusive checks if the turn is between two defined values, excluding the values.\n" +
			"Approximately checks if the turn is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Turn Value")]
		public FormulaFloat turn = new FormulaFloat();

		[ORKEditorInfo(separator=true, labelText="Turn Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FormulaFloat turn2;

		public CheckTurnStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = ValueHelper.CheckVariableValue(
					this.useAverage ?
						(this.onlyBattle ? c.Group.AverageBattleTurn : c.Group.AverageTurn) :
						c.Battle.Turn,
					this.turn.GetValue(call),
					this.turn2 != null ? this.turn2.GetValue(call) : 0,
					this.check);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() +
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Turn Value", "A combatant's current turn value is used.\n" +
		"The turn value is used in to generate the turn order in 'Turn Based Battles' using 'Multi Turns'.", "")]
	[ORKNodeInfo("Combatant")]
	public class TurnValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public TurnValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = c.Group.AverageBattleTurnValue;
					}
					else
					{
						value = c.Group.AverageTurnValue;
					}
				}
				else
				{
					value = c.Battle.TurnValue;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ? " Avg. Turn Value" : " Turn Value");
		}
	}

	[ORKEditorHelp("Check Turn Value", "Checks a combatant's turn value.\n" +
		"The turn value is used in to generate the turn order in 'Turn Based Battles' using 'Multi Turns'." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Check", "Combatant")]
	public class CheckTurnValueStep : BaseFormulaCheckStep
	{
		// status value
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;


		[ORKEditorHelp("Check Type", "Checks if the turn value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the turn value is between two defined values, including the values.\n" +
			"Range exclusive checks if the turn value is between two defined values, excluding the values.\n" +
			"Approximately checks if the turn value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public FormulaFloat turn = new FormulaFloat();

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FormulaFloat turn2;

		public CheckTurnValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = ValueHelper.CheckVariableValue(
					this.useAverage ?
						(this.onlyBattle ? c.Group.AverageBattleTurnValue : c.Group.AverageTurnValue) :
						c.Battle.TurnValue,
					this.turn.GetValue(call),
					this.turn2 != null ? this.turn2.GetValue(call) : 0,
					this.check);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() +
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Action Bar", "A combatant's current action bar is used.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant.", "")]
	[ORKNodeInfo("Combatant")]
	public class ActionBarStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Used Action Bar", "Use the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.", "")]
		public bool usedActionBar = false;

		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public ActionBarStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = this.usedActionBar ?
							c.Group.AverageBattleUsedActionBar :
							c.Group.AverageBattleActionBar;
					}
					else
					{
						value = this.usedActionBar ?
							c.Group.AverageUsedActionBar :
							c.Group.AverageActionBar;
					}
				}
				else
				{
					value = this.usedActionBar ?
						c.Battle.UsedActionBar :
						c.Battle.ActionBar;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ?
					(this.usedActionBar ? " Avg. Used Action Bar" : " Avg. Action Bar") :
					(this.usedActionBar ? " Used Action Bar" : " Action Bar"));
		}
	}

	[ORKEditorHelp("Check Action Bar", "Checks a combatant's action bar.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Check", "Combatant")]
	public class CheckActionBarStep : BaseFormulaCheckStep
	{
		// status value
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Used Action Bar", "Check the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.\n" +
			"E.g. use this to check if a combatant already chose actions by checking if the used action bar equals 0.", "")]
		public bool usedActionBar = false;

		[ORKEditorHelp("Use Average", "Use the average action bar value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;


		[ORKEditorHelp("Check Type", "Checks if the action bar value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the action bar value is between two defined values, including the values.\n" +
			"Range exclusive checks if the action bar value is between two defined values, excluding the values.\n" +
			"Approximately checks if the action bar value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public FormulaFloat turn = new FormulaFloat();

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FormulaFloat turn2;

		public CheckActionBarStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = ValueHelper.CheckVariableValue(
					this.useAverage ?
						(this.onlyBattle ?
							(this.usedActionBar ?
								c.Group.AverageBattleUsedActionBar :
								c.Group.AverageBattleActionBar) :
							(this.usedActionBar ?
								c.Group.AverageUsedActionBar :
								c.Group.AverageActionBar)) :
						(this.usedActionBar ?
							c.Battle.UsedActionBar :
							c.Battle.ActionBar),
					this.turn.GetValue(call),
					this.turn2 != null ? this.turn2.GetValue(call) : 0,
					this.check);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() +
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Inventory Space", "A combatant's used (occupied) or maximum inventory space is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class InventorySpaceStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Maximum", "The maximum inventory space is used.\n" +
			"If disabled, the currently used (occupied) inventory space is used.", "")]
		public bool useMax = false;

		public InventorySpaceStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useMax)
				{
					value = c.Inventory.TotalSpace;
				}
				else
				{
					value = c.Inventory.Space;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + (this.useMax ? " Max" : "");
		}
	}

	[ORKEditorHelp("Inventory Quantity", "The quantity of an item, equipment, currency, " +
		"AI behaviour or AI ruleset in a combatant's inventory is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class InventoryQuantityStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// item selection
		[ORKEditorHelp("Type", "Select the type, either an item, weapon, armor, currency (money), " +
			"AI behaviour, AI ruleset or crafting recipe.", "")]
		[ORKEditorInfo(separator=true, labelText="Item Settings")]
		public ItemDropType type = ItemDropType.Item;

		[ORKEditorHelp("Selection", "Select the item based on the selected type.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="type")]
		public int itemID = 0;

		public InventoryQuantityStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null)
			{
				int quantity = 0;
				if(ItemDropType.Item == this.type)
				{
					quantity = combatant.Inventory.Items.GetCount(this.itemID);
				}
				else if(ItemDropType.Weapon == this.type)
				{
					quantity = combatant.Inventory.Weapons.GetCount(this.itemID);
				}
				else if(ItemDropType.Armor == this.type)
				{
					quantity = combatant.Inventory.Armors.GetCount(this.itemID);
				}
				else if(ItemDropType.Currency == this.type)
				{
					quantity = combatant.Inventory.GetMoney(this.itemID);
				}
				else if(ItemDropType.AIBehaviour == this.type)
				{
					quantity = combatant.Inventory.AICollection.GetAIBehaviourQuantity(this.itemID);
				}
				else if(ItemDropType.AIRuleset == this.type)
				{
					quantity = combatant.Inventory.AICollection.GetAIRulesetQuantity(this.itemID);
				}
				else if(ItemDropType.CraftingRecipe == this.type)
				{
					quantity = combatant.Inventory.Crafting.GetRecipeQuantity(this.itemID);
				}
				ValueHelper.UseOperator(ref call.result, quantity, this.formulaOperator);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(ItemDropType.Item == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.Items.GetName(this.itemID);
			}
			else if(ItemDropType.Weapon == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.Weapons.GetName(this.itemID);
			}
			else if(ItemDropType.Armor == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.Armors.GetName(this.itemID);
			}
			else if(ItemDropType.Currency == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.Currencies.GetName(this.itemID);
			}
			else if(ItemDropType.AIBehaviour == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.AIBehaviours.GetName(this.itemID);
			}
			else if(ItemDropType.AIRuleset == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.AIRulesets.GetName(this.itemID);
			}
			else if(ItemDropType.CraftingRecipe == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.CraftingRecipes.GetName(this.itemID);
			}
			return this.formulaOperator + " " + this.origin.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Status", "Checks a combatant on certain status requirements, e.g. status value.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckStatusStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[] {new StatusRequirement()};

		public CheckStatusStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = true;
			bool any = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				any = true;
				if(!StatusRequirement.Check(c, this.req, this.needed))
				{
					check = false;
				}
			}

			if(any && check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}

		public override int CalculatePreview(FormulaCall call)
		{
			bool check = true;
			bool any = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				any = true;
				if(!StatusRequirement.CheckPreview(c, this.req, this.needed))
				{
					check = false;
				}
			}

			if(any && check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}
	}

	[ORKEditorHelp("Status Fork", "Checks a combatant for certain status requirements.\n" +
		"If a requirement is valid, it's next step will be executed.\n" +
		"If no requirement is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Check", "Combatant")]
	public class StatusForkStep : BaseFormulaStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirementNextNode[] req = new StatusRequirementNextNode[] {new StatusRequirementNextNode()};

		public StatusForkStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				for(int i = 0; i < this.req.Length; i++)
				{
					if(this.req[i].CheckRequirement(c))
					{
						return this.req[i].next;
					}
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				for(int i = 0; i < this.req.Length; i++)
				{
					if(this.req[i].CheckRequirementPreview(c))
					{
						return this.req[i].next;
					}
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Requirement " + (index - 1) + ": " + this.req[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.req.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.req[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.req[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Equipment Durability", "The durability of an equipment stored in selected data is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class EquipmentDurabilityStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorHelp("Use Max Durability", "Use the maximum durability of the equipment.", "")]
		public bool useMaxDurability = false;

		[ORKEditorInfo(separator=true, labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		[ORKEditorHelp("Use First", "Use the durability of the first found durable equipment stored in the defined selected data.\n" +
			"If disabled, the durability of all stored equipment will be used.", "")]
		public bool useFirst = false;

		public EquipmentDurabilityStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			List<EquipShortcut> equipment = SelectedDataHelper.GetEquipment(
				call.SelectedData.Get(this.selectedKey.GetValue()));
			float value = 0;
			for(int i = 0; i < equipment.Count; i++)
			{
				if(equipment[i] != null &&
					equipment[i].UseDurability)
				{
					value += this.useMaxDurability ?
						equipment[i].MaxDurability :
						equipment[i].Durability;
					if(this.useFirst)
					{
						break;
					}
				}
			}
			ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.selectedKey.GetInfoText() +
				(this.useFirst ? " (First)" : " (All)");
		}
	}
}
