
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class SpawnerData : ISaveData
	{
		public int quantity = 0;

		public List<Group> groups = new List<Group>();

		public List<float> respawn = new List<float>();


		// spawner
		private CombatantSpawner spawner;

		private int spawnerIndex = 0;

		private bool doRespawn = false;

		public SpawnerData()
		{

		}

		public bool CanSpawn(int maxQuantity)
		{
			return this.quantity + this.respawn.Count < maxQuantity;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("quantity", this.quantity);
			data.Set("respawn", this.respawn.ToArray());

			DataObject[] tmp = new DataObject[this.groups.Count];
			for(int i = 0; i < this.groups.Count; i++)
			{
				tmp[i] = this.groups[i].SaveGame();
			}
			data.Set("groups", tmp);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.groups.Clear();
			this.respawn.Clear();
			if(data != null)
			{
				data.Get("quantity", ref this.quantity);

				DataObject[] tmp = data.GetFileArray("groups");
				if(tmp != null)
				{
					for(int i = 0; i < tmp.Length; i++)
					{
						Group group = new Group(tmp[i]);
						if(this.spawner != null)
						{
							group.BattleType = this.spawner.battleType;
							group.SetSpawner(this.spawner, this.spawnerIndex, this.doRespawn);
						}
						group.LoadMembers(tmp[i], true);
						this.groups.Add(group);

						List<Combatant> list = group.GetBattle();
						for(int j = 0; j < list.Count; j++)
						{
							list[j].RememberPosition = true;
						}
						if(this.spawner != null)
						{
							this.spawner.SetWaypoints(group);
						}
					}
				}

				float[] tmp2;
				data.Get("respawn", out tmp2);
				if(tmp2 != null)
				{
					this.respawn.AddRange(tmp2);
				}
			}
		}

		public void UpdateSpawner(CombatantSpawner spawner, int spawnerIndex, bool respawn)
		{
			this.spawner = spawner;
			this.spawnerIndex = spawnerIndex;
			this.doRespawn = respawn;
		}
	}
}
