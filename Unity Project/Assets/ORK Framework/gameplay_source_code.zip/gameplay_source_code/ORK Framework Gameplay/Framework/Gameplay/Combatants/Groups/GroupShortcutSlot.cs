
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupShortcutSlot : ISaveData
	{
		private Combatant owner;

		private IShortcut shortcut;


		// load index
		private int tmpIndex = -1;

		public GroupShortcutSlot()
		{

		}

		public GroupShortcutSlot(Combatant owner, IShortcut shortcut)
		{
			this.owner = owner;
			this.shortcut = shortcut;
		}

		public GroupShortcutSlot(Group group, DataObject data)
		{
			this.LoadGame(data);
			this.owner = group.MemberAt(this.tmpIndex);
			if(this.shortcut is AbilityLinkShortcut)
			{
				((AbilityLinkShortcut)this.shortcut).UpdateAbility(this.owner);
			}
		}


		/*
		============================================================================
		Get functions
		============================================================================
		*/
		public Combatant Owner
		{
			get { return this.owner; }
		}

		public IShortcut Shortcut
		{
			get
			{
				this.RenewShortcut();
				return this.shortcut;
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public bool CheckShortcut()
		{
			return this.shortcut is MoneyShortcut ||
				(this.shortcut is AbilityShortcut &&
					this.owner.Abilities.Has((AbilityShortcut)this.shortcut)) ||
				((this.shortcut is ItemShortcut || this.shortcut is EquipShortcut) &&
					this.owner.Inventory.Has(this.shortcut)) ||
				shortcut is AbilityLinkShortcut ||
				shortcut is DefendShortcut ||
				shortcut is EscapeShortcut ||
				shortcut is NoneShortcut ||
				shortcut is GridMoveShortcut ||
				shortcut is GridOrientationShortcut ||
				shortcut is GridExamineShortcut;
		}

		public void RenewShortcut()
		{
			if(this.shortcut is AbilityLinkShortcut)
			{
				((AbilityLinkShortcut)this.shortcut).UpdateAbility(this.owner);
			}
			else if(this.shortcut is AbilityShortcut)
			{
				if(ORK.ShortcutSettings.keepUnavailableShortcuts)
				{
					IShortcut tmp = this.owner.Abilities.Get((AbilityShortcut)this.shortcut);
					if(tmp != null)
					{
						this.shortcut = tmp;
					}
				}
				else
				{
					this.shortcut = this.owner.Abilities.Get((AbilityShortcut)this.shortcut);
				}
			}
			else if(this.shortcut is ItemShortcut)
			{
				if(ORK.ShortcutSettings.keepUnavailableShortcuts)
				{
					IShortcut tmp = this.shortcut = this.owner.Inventory.GetItem(this.shortcut.ID);
					if(tmp != null)
					{
						this.shortcut = tmp;
					}
				}
				else
				{
					this.shortcut = this.owner.Inventory.GetItem(this.shortcut.ID);
				}
			}
			else if(this.shortcut is EquipShortcut)
			{
				if(ORK.ShortcutSettings.keepUnavailableShortcuts)
				{
					IShortcut tmp = this.owner.Inventory.GetEquipment((EquipShortcut)this.shortcut);
					if(tmp != null)
					{
						this.shortcut = tmp;
					}
				}
				else
				{
					this.shortcut = this.owner.Inventory.GetEquipment((EquipShortcut)this.shortcut);
				}
			}
			else if(this.shortcut is MoneyShortcut)
			{
				if(ORK.ShortcutSettings.keepUnavailableShortcuts)
				{
					IShortcut tmp = this.owner.Inventory.GetMoneyShortcut(this.shortcut.ID);
					if(tmp != null)
					{
						this.shortcut = tmp;
					}
				}
				else
				{
					this.shortcut = this.owner.Inventory.GetMoneyShortcut(this.shortcut.ID);
				}
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("combatant", this.owner.Group.GetMemberIndex(this.owner));
			if(this.shortcut != null)
			{
				data.Set("shortcut", this.shortcut.SaveGame());
			}

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				this.tmpIndex = -1;
				data.Get("combatant", ref this.tmpIndex);

				DataObject tmp = data.GetFile("shortcut");
				if(tmp != null)
				{
					string typeInfo = "";
					tmp.Get(DataSerializer.TYPE, ref typeInfo);
					if(typeInfo.EndsWith("Shortcut"))
					{
						IShortcut tmpShortcut = ReflectionTypeHandler.Instance.CreateInstance(
							System.Type.GetType("ORKFramework." + typeInfo)) as IShortcut;
						if(tmpShortcut != null &&
							ShortcutHelper.CheckValidID(tmpShortcut))
						{
							tmpShortcut.LoadGame(tmp);
							this.shortcut = tmpShortcut;
						}
					}
				}
			}
		}
	}
}
