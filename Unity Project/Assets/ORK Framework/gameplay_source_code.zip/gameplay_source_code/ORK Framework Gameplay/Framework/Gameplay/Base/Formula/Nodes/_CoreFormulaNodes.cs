﻿
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	public static class FormulaStepHelper
	{
		public static Dictionary<System.Type, NodeInfo> GetSteps()
		{
			Dictionary<System.Type, NodeInfo> list = new Dictionary<System.Type, NodeInfo>();

			System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
			for(int i = 0; i < assembly.Length; i++)
			{
				FormulaStepHelper.AddFromAssembly(assembly[i], ref list);
			}

			return list;
		}

		private static void AddFromAssembly(System.Reflection.Assembly assembly,
			ref Dictionary<System.Type, NodeInfo> list)
		{
			System.Type[] types = assembly.GetTypes();
			for(int i = 0; i < types.Length; i++)
			{
				if(types[i].Namespace == "ORKFramework.Formulas.Steps")
				{
					System.Object[] attr = types[i].GetCustomAttributes(typeof(ORKEditorHelpAttribute), true);
					if(attr.Length > 0)
					{
						string[] help = (attr[0] as ORKEditorHelpAttribute).text;

						string[] subMenu = new string[0];
						attr = types[i].GetCustomAttributes(typeof(ORKNodeInfoAttribute), true);
						if(attr.Length > 0)
						{
							subMenu = (attr[0] as ORKNodeInfoAttribute).subMenu;
						}
						list.Add(types[i], new NodeInfo(help, subMenu));
					}
				}
			}
		}
	}

	public abstract class BaseFormulaStep : CoreFormulaStep
	{
		[ORKEditorHelp("Enabled", "This step is enabled and will be executed.\n" +
			"If disabled, the step wont execute and the next step ('Next') will be executed.", "")]
		[ORKEditorInfo(hide=true)]
		public bool active = true;

		[ORKEditorInfo(hide=true)]
		public int next = -1;

		public abstract int Calculate(FormulaCall call);

		public virtual int CalculatePreview(FormulaCall call)
		{
			return this.Calculate(call);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "";
		}

		public override string GetNodeDetails()
		{
			return "";
		}

		public override string GetNextName(int index)
		{
			return "Next";
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.next;
		}

		public override void SetNext(int index, int next)
		{
			this.next = next;
		}


		/*
		============================================================================
		Enable functions
		============================================================================
		*/
		public override bool IsEnabled
		{
			get { return this.active; }
		}
	}

	public abstract class BaseFormulaCheckStep : BaseFormulaStep
	{
		[ORKEditorInfo(hide=true)]
		public int nextFail = -1;


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}

		public override int GetNextCount()
		{
			return 2;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
	}
}
