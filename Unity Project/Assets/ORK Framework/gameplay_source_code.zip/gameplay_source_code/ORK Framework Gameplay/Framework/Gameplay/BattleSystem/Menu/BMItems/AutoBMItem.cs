
namespace ORKFramework.UI
{
	public class AutoBMItem : BMItem
	{
		private bool wholeGroup = false;
		
		public AutoBMItem(ChoiceContent content, bool wholeGroup)
		{
			this.content = content;
			this.wholeGroup = wholeGroup;
		}
		
		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = !owner.Status.StopMove;
			return tmp != this.content.Active;
		}

		public override bool Accepted(Combatant owner)
		{
			if(this.wholeGroup && ORK.Battle.System != null)
			{
				ORK.Battle.System.SetGroupAuto(owner);
			}
			owner.BattleMenu.AddAction(owner.AI.GetAction(
				ORK.Game.Combatants.Get(owner, true, Range.Battle, Consider.No, Consider.Ignore, Consider.Ignore), 
				ORK.Game.Combatants.Get(owner, true, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Ignore)));
			return true;
		}
	}
}
