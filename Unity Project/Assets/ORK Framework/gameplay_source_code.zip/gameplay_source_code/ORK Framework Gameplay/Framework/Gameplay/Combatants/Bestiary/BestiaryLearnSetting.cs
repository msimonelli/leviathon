
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BestiaryLearnSetting : BaseData
	{
		[ORKEditorHelp("Combatant", "Select the combatant used for the bestiary entry.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		public int combatantID = 0;
		
		[ORKEditorHelp("Class", "Select the class of the bestiary entry.", "")]
		[ORKEditorInfo(ORKDataType.Class)]
		[ORKEditorLayout(checkCallback="check:bestiarySeparation")]
		public int classID = 0;
		
		[ORKEditorHelp("Level", "Set the level of the bestiary entry.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(checkCallback="check:bestiarySeparation")]
		public int level = 1;
		
		[ORKEditorHelp("Class Level", "Set the level of the bestiary entry.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(checkCallback="check:bestiarySeparation")]
		public int classLevel = 1;
		
		public BestiaryLearnSetting()
		{
			
		}
		
		public BestiaryEntry Get()
		{
			return ORK.Game.Bestiary.GetEntry(this.combatantID, 
				this.classID, this.level, this.classLevel);
		}
		
		public void Add(bool complete, int[] areaIDs, bool ignoreNotScanable, bool ignoreNoEntry)
		{
			if(complete)
			{
				ORK.Game.Bestiary.SetComplete(this.combatantID, 
					this.classID, this.level, this.classLevel, areaIDs, 
					ignoreNotScanable, ignoreNoEntry);
			}
			else
			{
				ORK.Game.Bestiary.AddBlank(this.combatantID, 
					this.classID, this.level, this.classLevel, areaIDs, ignoreNoEntry);
			}
		}
		
		public void Remove()
		{
			ORK.Game.Bestiary.Remove(this.combatantID, 
				this.classID, this.level, this.classLevel);
		}
		
		public bool IsKnown()
		{
			return ORK.Game.Bestiary.IsKnown(this.combatantID, 
				this.classID, this.level, this.classLevel);
		}
		
		public bool IsComplete()
		{
			return ORK.Game.Bestiary.IsComplete(this.combatantID, 
				this.classID, this.level, this.classLevel);
		}
	}
}
