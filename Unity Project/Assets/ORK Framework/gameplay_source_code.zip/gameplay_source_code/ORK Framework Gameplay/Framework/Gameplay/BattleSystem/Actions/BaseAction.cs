
using UnityEngine;
using ORKFramework.AI;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate void ActionFinished(BaseAction action);

	public abstract class BaseAction : IEventStarter
	{
		private CombatantAffiliationType actionAffiliation = CombatantAffiliationType.Player;

		protected Combatant user;

		public bool forceFoundTargets = false;

		public bool moveToTarget = false;

		public bool blockBattleCamera = false;

		public List<Combatant> target;

		public List<Combatant> outOfRange;

		public List<Combatant> counter = new List<Combatant>();

		public ActionResults results;

		public ActionFinished finishedCallback;

		protected GridPath gridPath;


		// battle events
		protected List<BattleEvent> events;

		protected BattleEvent activeEvent;

		protected VariableHandler variableHandler;

		protected SelectedDataHandler selectedData;

		protected Dictionary<string, List<GameObject>> foundObjects;


		// sub actions
		protected List<BaseAction> subAction;

		public ActionFinished subActionFinishedCallback;


		// settings
		protected bool userConsumeDone = false;

		protected Consider targetDead = Consider.No;

		protected bool consumeTime = true;

		public bool autoAttackFlag = false;

		protected float actionCost = 0;

		protected bool tooltipDisplayed = false;


		// turn based battles
		public bool isPerforming = false;

		public bool notifiedFinished = false;


		// phase battles
		public bool endPhaseFlag = false;


		// raycast target
		public TargetRaycast targetRaycast = new TargetRaycast();

		public bool rayTargetSet = false;

		public Vector3 rayPoint = Vector3.zero;

		public bool rayObjectCreated = false;

		public GameObject rayObject = null;


		// from battle event step
		public float damageMultiplier = 1;


		/*
		============================================================================
		Helper functions
		============================================================================
		*/
		public abstract bool IsType(ActionType t);

		public Combatant User
		{
			get { return this.user; }
		}

		public virtual IShortcut Shortcut
		{
			get { return null; }
		}

		public static AbilityAction CreateAbility(Combatant user, AbilityShortcut ability, int lvl)
		{
			if(ability != null)
			{
				if(lvl == -1)
				{
					ability.SetHighestUseLevel(user);
				}
				else if(lvl >= 0)
				{
					ability.SetUseLevel(lvl);
				}
				if(ability.CanUse(user, AbilityActionType.CounterAttack != ability.Type, true))
				{
					return new AbilityAction(user, ability);
				}
			}
			return null;
		}

		public virtual string GetName()
		{
			return "";
		}

		public float ActionCost
		{
			get { return this.actionCost; }
		}

		public bool ConsumeTime
		{
			get { return this.consumeTime; }
			set { this.consumeTime = value; }
		}

		public GridPath GridPath
		{
			get { return this.gridPath; }
			set
			{
				if(this.gridPath != null)
				{
					this.gridPath.Clear();
				}
				this.gridPath = value;
			}
		}

		public CombatantAffiliationType ActionAffiliation
		{
			get { return this.actionAffiliation; }
		}

		public void CheckActionAffiliation()
		{
			if(this.user.IsPlayerControlled())
			{
				this.actionAffiliation = CombatantAffiliationType.Player;
			}
			else if(this.user.IsEnemy(ORK.Game.ActiveGroup.Leader))
			{
				this.actionAffiliation = CombatantAffiliationType.Enemy;
			}
			else
			{
				this.actionAffiliation = CombatantAffiliationType.Ally;
			}
		}

		public virtual void SetTarget(Combatant t)
		{

		}

		public virtual void SetTargets(List<Combatant> t)
		{

		}

		public virtual bool AutoTarget(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			return false;
		}

		public virtual bool ForceFoundTargets(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			return false;
		}

		public virtual bool SetGroupTarget()
		{
			return false;
		}

		public virtual bool SetIndividualTarget()
		{
			return false;
		}

		public virtual bool ConsumeDone
		{
			get { return this.userConsumeDone; }
			set { this.userConsumeDone = value; }
		}

		public virtual void ConsumeCosts()
		{
			this.userConsumeDone = true;
		}

		public VariableHandler Variables
		{
			get
			{
				if(this.variableHandler == null)
				{
					this.variableHandler = new VariableHandler(false);
				}
				return this.variableHandler;
			}
			set { this.variableHandler = value; }
		}

		public SelectedDataHandler SelectedData
		{
			get
			{
				if(this.selectedData == null)
				{
					this.selectedData = SelectedDataHelper.CreateSelectedData(
						SelectedDataHelper.Action, this.GetSelectedData());
				}
				return this.selectedData;
			}
			set { this.selectedData = value; }
		}

		public Dictionary<string, List<GameObject>> FoundObjects
		{
			get
			{
				if(this.foundObjects == null)
				{
					this.foundObjects = new Dictionary<string, List<GameObject>>();
				}
				return this.foundObjects;
			}
			set { this.foundObjects = value; }
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public Consider TargetDead
		{
			get { return this.targetDead; }
		}

		public virtual bool CanTarget(Combatant combatant)
		{
			return this.user == combatant;
		}


		/*
		============================================================================
		Ability cast functions
		============================================================================
		*/
		public virtual bool IsCastingAbility()
		{
			return false;
		}

		public virtual bool CancelAbilityCast()
		{
			return false;
		}


		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		public virtual void SetRandomTarget()
		{

		}

		public void UpdateTargets()
		{
			if(this.target == null)
			{
				this.target = new List<Combatant>();
			}

			List<Combatant> tmp = new List<Combatant>();
			for(int i = 0; i < this.target.Count; i++)
			{
				if(!this.InRange(this.target[i]))
				{
					tmp.Add(this.target[i]);
					this.target.RemoveAt(i--);
				}
			}

			if(this.outOfRange != null)
			{
				for(int i = 0; i < this.outOfRange.Count; i++)
				{
					if(this.InRange(this.outOfRange[i]))
					{
						this.target.Add(this.outOfRange[i]);
						this.outOfRange.RemoveAt(i--);
					}
				}
			}

			if(tmp.Count > 0)
			{
				if(this.outOfRange == null)
				{
					this.outOfRange = new List<Combatant>();
				}
				this.outOfRange.AddRange(tmp);
			}
		}

		public void PerformCheckTargets()
		{
			this.UpdateTargets();
			if(this.target != null && target.Count > 0)
			{
				for(int i = 0; i < this.target.Count; i++)
				{
					if(this.target[i] == null ||
						!TargetHelper.CheckDeath(this.target[i], this.targetDead))
					{
						this.target.RemoveAt(i--);
					}
				}
			}

			if(!this.rayTargetSet && (this.target == null || this.target.Count == 0))
			{
				this.SetRandomTarget();
			}
		}

		public virtual bool TargetNone()
		{
			return false;
		}

		public bool HasTargets()
		{
			return this.HasTargets(this.target);
		}

		public bool HasTargets(List<Combatant> list)
		{
			if(!this.TargetNone() &&
				list != null && list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(TargetHelper.CheckDeath(list[i], this.targetDead))
					{
						return true;
					}
				}
				return false;
			}
			return true;
		}

		public bool HasOutOfRangeTargets()
		{
			return this.outOfRange != null && this.outOfRange.Count > 0;
		}

		public Combatant GetNearestTarget()
		{
			Combatant nearest = null;
			if(this.target != null && this.target.Count > 0)
			{
				nearest = TargetHelper.GetNearestTarget(this.user, this.target, this.targetDead);
			}
			if(nearest == null && this.outOfRange != null && this.outOfRange.Count > 0)
			{
				nearest = TargetHelper.GetNearestTarget(this.user, this.outOfRange, this.targetDead);
			}
			return nearest;
		}

		public void CheckTargetAggressive()
		{
			if(this.target != null && this.target.Count > 0)
			{
				for(int i = 0; i < this.target.Count; i++)
				{
					if(this.target[i] != null && this.user.IsEnemy(this.target[i]))
					{
						this.target[i].CheckAggressive(AggressionType.OnSelection, this.user);
					}
				}
			}
		}

		public void CheckBestiary(List<Combatant> list)
		{
			if(this.user.IsPlayerControlled())
			{
				for(int i = 0; i < list.Count; i++)
				{
					ORK.Game.Bestiary.Attack(list[i]);
				}
			}
			else if(this.user.IsEnemy(ORK.Game.ActiveGroup.Leader))
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].IsPlayerControlled())
					{
						ORK.Game.Bestiary.AttackedBy(list[i]);
					}
				}
			}
		}

		public List<Combatant> GetTargetsWithAffectRange(TargetSettings targetSettings, List<Combatant> targets)
		{
			if(this.rayObject != null &&
				ORK.Battle.Grid != null &&
				targetSettings.NoneTarget() &&
				targetSettings.noneSelectGridCell)
			{
				BattleGridCellComponent originCell = this.rayObject.GetComponent<BattleGridCellComponent>();
				if(originCell != null)
				{
					List<BattleGridCellComponent> affectRangeCells = targetSettings.
						GetAffectRangeCells(this.user, originCell, null);
					for(int i = 0; i < affectRangeCells.Count; i++)
					{
						if(affectRangeCells[i] != null &&
							!affectRangeCells[i].IsEmpty)
						{
							affectRangeCells[i].GetCombatants(ref targets, this.CanTarget);
						}
					}
				}
			}
			else
			{
				targets = targetSettings.GetAffectRange(this.user, targets);
			}
			return targets;
		}

		public void CheckCanTarget()
		{
			if(this.target != null)
			{
				for(int i = 0; i < this.target.Count; i++)
				{
					if(!this.CanTarget(this.target[i]))
					{
						this.target.RemoveAt(i--);
					}
				}
			}
			if(this.outOfRange != null)
			{
				for(int i = 0; i < this.outOfRange.Count; i++)
				{
					if(!this.CanTarget(this.outOfRange[i]))
					{
						this.outOfRange.RemoveAt(i--);
					}
				}
			}
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public bool InRange()
		{
			return this.TargetNone() || this.InRange(this.GetNearestTarget());
		}

		public virtual bool InRange(Combatant t)
		{
			return true;
		}

		public virtual bool InRange(Vector3 position)
		{
			return true;
		}

		public bool InBattleRange()
		{
			if(this.user != null)
			{
				if(this.target != null && this.target.Count > 0)
				{
					for(int i = 0; i < this.target.Count; i++)
					{
						if(Range.Battle.InRange(this.user, this.target[i]))
						{
							return true;
						}
					}
				}
				if(this.outOfRange != null && this.outOfRange.Count > 0)
				{
					for(int i = 0; i < this.outOfRange.Count; i++)
					{
						if(Range.Battle.InRange(this.user, this.outOfRange[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		public void MoveAITick()
		{
			if(this.moveToTarget &&
				this.user.MoveAI != null &&
				ORK.Battle.CanUseMoveAI(this.user))
			{
				this.UpdateTargets();
				if(this.InRange() &&
					this.user.MoveAI.ReachedActionTarget())
				{
					this.user.MoveAI.Stop();
					this.moveToTarget = false;
				}
			}
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		protected void GetNextEvent()
		{
			if(this.activeEvent != null)
			{
				this.events[0].Variables = this.Variables;
				this.events[0].SelectedData = this.SelectedData;
				this.events[0].FoundObjects = this.FoundObjects;
				this.activeEvent = this.events[0];
			}
			else
			{
				this.activeEvent = this.events[0];
				this.activeEvent.Variables = this.Variables;
				this.activeEvent.SelectedData = this.SelectedData;
				this.activeEvent.FoundObjects = this.FoundObjects;
			}
			this.events.RemoveAt(0);
		}

		public virtual System.Object GetSelectedData()
		{
			return null;
		}

		public virtual bool CanUse()
		{
			return this.user != null;
		}

		public virtual void ActionAdded()
		{

		}

		// setup action stuff, show info, get events
		protected abstract void ActionStartSetup();

		public virtual void PerformAction()
		{
			// add control blocks
			ORK.Battle.DoAllActionsBlock(1);
			if(ORK.Game.PlayerHandler.IsPlayer(this.user))
			{
				ORK.Battle.DoPlayerActionsBlock(1);
			}
			ORK.Battle.AllowPlayerTurnControl(-1, this.user, AllowTurnControl.WhileInAction);

			ORK.Battle.Actions.AddActive(this);
			this.PerformCheckTargets();
			this.CheckActionAffiliation();

			if(this.CanUse())
			{
				// check target aggression
				if(this.target != null && this.target.Count > 0)
				{
					for(int i = 0; i < this.target.Count; i++)
					{
						if(this.target[i] != null && this.user.IsEnemy(this.target[i]))
						{
							this.target[i].CheckAggressive(AggressionType.OnAction, this.user);
							this.target[i].Battle.SetAttackedBy(this.user, true);
						}
					}
				}

				// base setup
				if(this.IsType(ActionType.Ability) ||
					this.IsType(ActionType.Attack) ||
					this.IsType(ActionType.Item))
				{
					user.Battle.LastTargets = this.target;
				}
				user.Actions.ActionState = CombatantActionState.InAction;

				if(!this.blockBattleCamera &&
					!ORK.BattleSettings.camera.IsNone &&
					user.GameObject != null &&
					!ORK.BattleSettings.camera.latestUserActionBlock.IsBlocked(this))
				{
					ORK.BattleSettings.camera.SetLatestUser(user.GameObject.transform, user.GameObject.transform);
				}
				this.events = new List<BattleEvent>();
				this.ActionStartSetup();

				// start battle event
				if(this.events.Count > 0)
				{
					this.user.Shortcuts.Active = this.Shortcut;
					this.ShowTooltip();
					this.GetNextEvent();
					this.activeEvent.StartEvent(this, this.user.GameObject);
				}
				else
				{
					if(this.target != null && this.target.Count > 0)
					{
						this.Calculate(this.target, 1, true);
					}
					this.EventEnded();
				}
			}
			else
			{
				this.EventEnded();
			}
		}

		public abstract void Calculate(List<Combatant> ts, float damageFactor, bool animate);

		protected abstract void ActionEndSetup();

		public virtual void EventEnded()
		{
			// get next event
			if(this.events != null && this.events.Count > 0)
			{
				this.GetNextEvent();
				this.activeEvent.StartEvent(this, this.user.GameObject);
			}
			// end action if no sub actions are running
			else
			{
				this.activeEvent = null;

				if(this.subAction == null || this.subAction.Count == 0)
				{
					// remove control blocks
					ORK.Battle.DoAllActionsBlock(-1);
					if(ORK.Game.PlayerHandler.IsPlayer(this.user))
					{
						ORK.Battle.DoPlayerActionsBlock(-1);
					}
					ORK.Battle.AllowPlayerTurnControl(1, this.user, AllowTurnControl.WhileInAction);

					if(this.rayObject != null &&
						this.rayObjectCreated)
					{
						GameObject.Destroy(this.rayObject);
					}

					if(this.endPhaseFlag && ORK.Battle.IsPhase())
					{
						ORK.BattleSystem.phase.ClearCurrentFaction();
					}

					if(this.user != null)
					{
						this.ActionEndSetup();

						this.user.Actions.CheckActionCombos(this);

						if(this.gridPath != null)
						{
							this.gridPath.Clear();
						}

						this.user.Shortcuts.Active = null;
						this.RemoveTooltip();

						if(!this.user.Dead && !this.autoAttackFlag && this.consumeTime)
						{
							if(ORK.Battle.IsActiveTime() &&
								this.actionCost > 0)
							{
								this.user.Battle.UsedActionBar -= this.actionCost;
								this.user.Battle.ActionBar -= this.actionCost;

								if(this.user.Battle.ActionBar >= ORK.BattleSystem.activeTime.maxTimebar)
								{
									this.user.Battle.ActionBar = ORK.BattleSystem.activeTime.maxTimebar;
								}
							}
							else if(ORK.Battle.IsTurnBased())
							{
								if(TurnBasedMode.MultiTurns == ORK.BattleSystem.turnBased.mode &&
									ORK.BattleSystem.turnBased.invertTurnOrder)
								{
									this.user.Battle.TurnValue = ORK.BattleSystem.turnBased.GetTurnCalculation(this.user);
								}
								else
								{
									this.user.Battle.TurnValue = 0;
								}
								this.user.Battle.UsedActionBar -= this.actionCost;
								this.user.Battle.ActionBar -= this.actionCost;
							}
							else if(ORK.Battle.IsPhase())
							{
								this.user.Battle.TurnValue = 0;
								this.user.Battle.UsedActionBar -= this.actionCost;
								this.user.Battle.ActionBar -= this.actionCost;
							}
						}

						if(!ORK.Battle.IsRealTime())
						{
							for(int i = 0; i < this.counter.Count; i++)
							{
								if(this.counter[i] != null &&
									this.counter[i].Actions.ActionState == CombatantActionState.Available)
								{
									BaseAction counterAction = new AbilityAction(
										this.counter[i], this.counter[i].Abilities.GetCounterAttack());
									counterAction.SetTarget(this.user);
									ORK.Battle.Actions.Unshift(counterAction);
								}
							}
						}

						this.user.Actions.ActionState = CombatantActionState.EndingAction;

						if((ORK.Battle.IsActiveTime() || ORK.Battle.IsRealTime()) &&
							!this.IsType(ActionType.CounterAttack) &&
							this.user.Battle.CanEndTurn)
						{
							this.user.Battle.EndTurn(this.TurnEndCallback);
						}
						else
						{
							this.TurnEndCallback();
						}
					}
					else
					{
						ORK.Battle.Actions.RemoveActive(this);
						ORK.Battle.CheckBattleEnd();
						if(this.finishedCallback != null)
						{
							this.finishedCallback(this);
						}
						else
						{
							ORK.Battle.Actions.Finished(this);
						}
					}
				}
			}
		}

		private void TurnEndCallback()
		{
			this.user.Actions.ActionState = CombatantActionState.Available;

			bool noActionsLeft = true;
			if(!this.IsType(ActionType.CounterAttack))
			{
				noActionsLeft = !this.user.Actions.DequeueNextAction();
			}

			if(noActionsLeft &&
				!this.IsType(ActionType.Death) &&
				ORK.Battle.CanUseMoveAI(this.user))
			{
				this.user.MoveAI.ActionFinished(this.target);
			}

			ORK.Battle.Actions.RemoveActive(this);
			ORK.Battle.CheckBattleEnd();
			if(this.finishedCallback != null)
			{
				this.finishedCallback(this);
			}
			else
			{
				ORK.Battle.Actions.Finished(this);
			}
		}

		public void StopAction()
		{
			if(this.activeEvent != null)
			{
				this.events.Clear();
				this.activeEvent.StopEvent();

				if(this.subAction != null)
				{
					for(int i = 0; i < this.subAction.Count; i++)
					{
						this.subAction[i].StopAction();
					}
				}
			}
		}

		public void ClearEvents()
		{
			if(this.events != null &&
				this.events.Count > 0)
			{
				this.events.Clear();
			}
		}

		public void Tick()
		{
			if(this.activeEvent != null)
			{
				this.activeEvent.Tick(ORK.Game.DeltaTime);
			}
		}

		public void DontDestroy()
		{

		}

		public void OnSceneLoaded()
		{

		}

		public GameObject GameObject
		{
			get { return this.user.GameObject; }
		}


		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public virtual void AutoActivateUserDamageDealers(bool activate)
		{
			if(this.user != null && this.user.GameObject != null)
			{
				DamageDealer[] damage = this.user.GameObject.GetComponentsInChildren<DamageDealer>();
				for(int i = 0; i < damage.Length; i++)
				{
					if((!this.user.Battle.InBattle && damage[i].autoField) ||
						(this.user.Battle.InBattle &&
							((ORK.Battle.IsTurnBased() && damage[i].autoTurnBased) ||
							(ORK.Battle.IsActiveTime() && damage[i].autoActiveTime) ||
							(ORK.Battle.IsRealTime() && damage[i].autoRealTime) ||
							(ORK.Battle.IsPhase() && damage[i].autoPhase)) &&
						(Consider.Ignore == damage[i].autoGridBattles ||
							(Consider.Yes == damage[i].autoGridBattles && ORK.Battle.Grid != null) ||
							(Consider.No == damage[i].autoGridBattles && ORK.Battle.Grid == null))))
					{
						damage[i].SetAction(activate ? this : null);
						damage[i].SetDamageActive(activate, (string[])null);
					}
				}
			}
		}

		public virtual bool CheckDamageDealer(DamageDealer dealer)
		{
			return false;
		}

		public virtual string[] GetActivationTags()
		{
			return new string[0];
		}

		public virtual DamageDealerActivation GetDamageDealerActivation()
		{
			return null;
		}


		/*
		============================================================================
		Sub action functions
		============================================================================
		*/
		public void AddSubAction(BaseAction action, bool shareVariables, bool shareFoundObjects)
		{
			if(this.subAction == null)
			{
				this.subAction = new List<BaseAction>();
			}

			if(shareVariables)
			{
				action.Variables = this.Variables;
			}
			if(shareFoundObjects)
			{
				action.FoundObjects = this.FoundObjects;
			}
			action.finishedCallback = this.SubActionFinished;
			this.subAction.Add(action);
			action.PerformAction();
		}

		public void SubActionFinished(BaseAction action)
		{
			if(this.subAction != null &&
				this.subAction.Contains(action))
			{
				this.subAction.Remove(action);

				if(action.subActionFinishedCallback != null)
				{
					action.subActionFinishedCallback(action);
				}

				if(this.subAction.Count == 0 &&
					(this.events == null || this.events.Count == 0) &&
					(this.activeEvent == null || !this.activeEvent.Executing))
				{
					this.EventEnded();
				}
			}
		}


		/*
		============================================================================
		Tooltip functions
		============================================================================
		*/
		public void ShowTooltip()
		{
			IShortcut shortcut = this.Shortcut;
			if(shortcut != null)
			{
				if(user.IsPlayerControlled())
				{
					if(ORK.MenuSettings.tooltip.playerActionTooltip &&
						(!ORK.MenuSettings.tooltip.noCounterTooltips ||
							!this.IsType(ActionType.CounterAttack)))
					{
						ORK.GUI.ForceTooltip(shortcut, -1, false);
						this.tooltipDisplayed = true;
					}
				}
				else if(user.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					if(ORK.MenuSettings.tooltip.enemyActionTooltip)
					{
						ORK.GUI.ForceTooltip(shortcut, -1, false);
						this.tooltipDisplayed = true;
					}
				}
				else if(ORK.MenuSettings.tooltip.allyActionTooltip)
				{
					ORK.GUI.ForceTooltip(shortcut, -1, false);
					this.tooltipDisplayed = true;
				}
			}
		}

		public void RemoveTooltip()
		{
			if(this.tooltipDisplayed)
			{
				ORK.GUI.RemoveForceTooltip(this.Shortcut);
			}
		}
	}
}
