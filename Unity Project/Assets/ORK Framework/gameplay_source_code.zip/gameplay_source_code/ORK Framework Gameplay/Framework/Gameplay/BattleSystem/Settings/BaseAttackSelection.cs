﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BaseAttackSelection : BaseData
	{
		[ORKEditorHelp("Use Current Attack", "Uses the current base attack of the combatant.\n" +
			"If disabled, you need to define which attack index will be used.", "")]
		public bool useCurrentAttack = true;

		[ORKEditorHelp("Attack Index", "Set the index of the base attack that will be used, e.g.:\n" +
			"- 0: Index of the first base attack.\n" +
			"- 1: Index of the second base attack.\n" +
			"Attack index 0 can always be used, the others only if the combatant currently has the set attack index.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("useCurrentAttack", false)]
		public int attackIndex = 0;

		[ORKEditorHelp("Force Index", "The defined attack index is forced (if available).\n" +
			"The attack will be performed, even if the user's attack index isn't set to this index " +
			"(i.e. you can use the attack outside of attack combos).\n" +
			"If disabled, the user's attack index has to be set to the defined index - " +
			"the attack can only be performed in sequence.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool forceAttackIndex = false;

		// equipment part attack
		[ORKEditorHelp("Use Equipment Part", "Use the attack of a selected equipment part.\n" +
			"If disabled, the usual base attack is used " +
			"(i.e. either the attack of an equipped weapon or the default attack).", "")]
		[ORKEditorInfo(separator=true)]
		public bool useEquipmentPart = false;

		[ORKEditorHelp("Equipment Part", "Select the equipment part used to attack.\n" +
			"Can only be used if the equipment part has a weapon with 'Override Attack' equipped.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("useEquipmentPart", true, endCheckGroup=true)]
		public int equipmentPartID = 0;

		public BaseAttackSelection()
		{

		}


		/*
		============================================================================
		Shortcut functions
		============================================================================
		*/
		public AbilityShortcut GetAttack(Combatant combatant)
		{
			AbilityShortcut ability = null;

			// current attack
			if(this.useCurrentAttack)
			{
				if(this.useEquipmentPart)
				{
					if(combatant.Equipment[this.equipmentPartID].Equipped)
					{
						ability = combatant.Equipment[this.equipmentPartID].Equipment.
							GetCurrentBaseAttack(combatant.Abilities.AttackIndex);
					}
				}
				else
				{
					ability = combatant.Abilities.GetCurrentBaseAttack();
				}
			}
			// force attack index
			else if(this.forceAttackIndex)
			{
				if(this.useEquipmentPart)
				{
					if(combatant.Equipment[this.equipmentPartID].Equipped)
					{
						ability = combatant.Equipment[this.equipmentPartID].Equipment.GetCurrentBaseAttack(this.attackIndex);
					}
				}
				else
				{
					ability = combatant.Abilities.GetBaseAttack(this.attackIndex);
				}
			}
			// defined attack index
			else if(combatant.Abilities.AttackIndex == this.attackIndex ||
				this.attackIndex == 0)
			{
				if(this.attackIndex == 0)
				{
					combatant.Abilities.ResetBaseAttack();
				}
				if(this.useEquipmentPart)
				{
					if(combatant.Equipment[this.equipmentPartID].Equipped)
					{
						ability = combatant.Equipment[this.equipmentPartID].Equipment.
							GetCurrentBaseAttack(combatant.Abilities.AttackIndex);
					}
				}
				else
				{
					ability = combatant.Abilities.GetCurrentBaseAttack();
				}
			}

			return ability;
		}
	}
}
