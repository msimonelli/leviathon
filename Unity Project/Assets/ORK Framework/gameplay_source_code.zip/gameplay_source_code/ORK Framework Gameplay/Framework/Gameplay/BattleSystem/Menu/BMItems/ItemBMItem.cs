
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class ItemBMItem : BMItem
	{
		private ItemShortcut item;

		private bool blockBattleCamera = false;

		public ItemBMItem(ItemShortcut item, ChoiceContent content) : this(item, content, false)
		{

		}

		public ItemBMItem(ItemShortcut item, ChoiceContent content, bool blockBattleCamera)
		{
			this.item = item;
			this.content = content;
			this.blockBattleCamera = blockBattleCamera;
		}

		public override void CreateDrag(Combatant owner)
		{
			if(this.content.data == null)
			{
				// drag+drop
				this.content.isDragable = ORK.BattleSettings.bmDrag;
				this.content.clickCount = ORK.BattleSettings.bmClick ? ORK.BattleSettings.bmClickCount : 0;
				this.content.isTooltip = ORK.BattleSettings.bmTooltip;
				if(this.content.isDragable || this.content.clickCount > 0 || this.content.isTooltip)
				{
					this.content.data = this.item.GetDrag(owner.BattleMenu, owner);
				}
			}

			// portrait
			if(this.content.portrait == null &&
				owner.BattleMenu.Settings.showItemPortraits)
			{
				this.content.portrait = this.item.GetPortrait(owner.BattleMenu.Settings.itemPortraitTypeID);
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = this.item.CanUse(owner, true, true) &&
				(this.item.Setting.targetSettings.NoneTarget() ||
					this.item.HasPossibleTargets(owner, null));
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			owner.BattleMenu.TargetHighlight.SelectAction(this.item);
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				if(this.item.Setting.targetSettings.TargetSelf())
				{
					BaseAction action = new ItemAction(owner, this.item);
					action.blockBattleCamera = this.blockBattleCamera;
					action.SetTarget(owner);
					owner.BattleMenu.AddAction(action);
					return true;
				}
				else if(this.item.Setting.targetSettings.NoneTarget())
				{
					if(ORK.Battle.Grid != null &&
						this.item.Setting.targetSettings.noneSelectGridCell)
					{
						owner.BattleMenu.StartGridTargetCellSelection(this.item, this.blockBattleCamera);
						owner.BattleMenu.CloseSilent();
					}
					else
					{
						BaseAction action = new ItemAction(owner, this.item);
						action.blockBattleCamera = this.blockBattleCamera;
						if(action.targetRaycast.NeedInteraction())
						{
							owner.BattleMenu.RayAction = action;
							owner.BattleMenu.CloseSilent();
						}
						else
						{
							if(action.targetRaycast.active)
							{
								action.targetRaycast.GetAutoPoint(owner.GameObject, VectorHelper.GetScreenCenter(), action);
							}
							owner.BattleMenu.AddAction(action);
						}
					}
					return true;
				}
				else
				{
					// use on group target
					if(owner.BattleMenu.Settings.useGroupTarget)
					{
						Combatant target = owner.Group.SelectedTargets.GetItemTarget(owner, this.item);
						if(target != null)
						{
							BaseAction action = new ItemAction(owner, this.item);
							action.blockBattleCamera = this.blockBattleCamera;
							action.SetTarget(target);
							owner.BattleMenu.AddAction(action);
							return true;
						}
					}
					// use on individual target
					if(owner.BattleMenu.Settings.useIndividualTarget)
					{
						Combatant target = owner.SelectedTargets.GetItemTarget(owner, this.item);
						if(target != null)
						{
							BaseAction action = new ItemAction(owner, this.item);
							action.blockBattleCamera = this.blockBattleCamera;
							action.SetTarget(target);
							owner.BattleMenu.AddAction(action);
							return true;
						}
					}

					// display target menu
					owner.BattleMenu.TargetHighlight.AcceptAction(this.item);
					List<BMItem> list = new List<BMItem>();

					int selection = -1;
					if(this.item.Setting.targetSettings.SingleTarget())
					{
						for(int i = 0; i < owner.BattleMenu.TargetHighlight.AvailableTargets.Count; i++)
						{
							List<Combatant> tmp = new List<Combatant>();
							tmp.Add(owner.BattleMenu.TargetHighlight.AvailableTargets[i]);
							list.Add(new TargetBMItem(
								owner.BattleMenu.GetCombatantChoice(owner.BattleMenu.TargetHighlight.AvailableTargets[i]),
								this.item, tmp, this.blockBattleCamera));

							if(selection < 0 && this.item.Setting.targetSettings.useAutoTarget &&
								this.item.Setting.targetSettings.autoTarget.Check(owner.BattleMenu.TargetHighlight.AvailableTargets[i]))
							{
								selection = i;
							}
						}
					}
					else if(this.item.Setting.targetSettings.GroupTarget())
					{
						list.Add(new TargetBMItem(
							ORK.BattleTexts.GetAllCombatantsContent(
								this.item.Setting.targetSettings.targetType,
								owner.BattleMenu.Settings.contentLayout),
							this.item, new List<Combatant>(owner.BattleMenu.TargetHighlight.AvailableTargets),
							this.blockBattleCamera));
					}

					if(list.Count > 0)
					{
						if(ORK.BattleSettings.useTargetMenu)
						{
							owner.BattleMenu.Settings.AddBack(list);
						}

						owner.BattleMenu.TargetHighlight.AcceptHighlights();
						owner.BattleMenu.Show(list, selection < 0 ? 0 : selection, BattleMenuMode.Target);
						return true;
					}
				}
			}
			return false;
		}
	}
}
