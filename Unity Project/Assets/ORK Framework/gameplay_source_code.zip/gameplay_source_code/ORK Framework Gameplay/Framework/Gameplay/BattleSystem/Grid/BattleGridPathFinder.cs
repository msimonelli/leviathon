﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public class BattleGridPathFinder
	{
		private Combatant user;

		private bool keepBlockedCells = false;

		private bool ignoreBlockingCombatants = false;

		public BattleGridCellComponent startCell;

		public List<BattleGridCellComponent> availableTargets;

		public List<BattleGridCellComponent> blockedCells;

		public List<BattleGridCellComponent> passableCells;

		public Dictionary<BattleGridCellComponent, BattleGridCellComponent> cameFrom;

		public Dictionary<BattleGridCellComponent, float> costSoFar;

		private CombatantCheck occupantCheck;

		private GridCellCheck cellCheck;

		public BattleGridPathFinder()
		{
			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
		}

		public BattleGridPathFinder(bool keepBlockedCells)
		{
			this.keepBlockedCells = keepBlockedCells;

			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
		}

		public BattleGridPathFinder(bool keepBlockedCells, bool ignoreBlockingCombatants)
		{
			this.keepBlockedCells = keepBlockedCells;
			this.ignoreBlockingCombatants = ignoreBlockingCombatants;

			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
		}

		public void Clear()
		{
			this.user = null;
			this.startCell = null;
			if(this.availableTargets != null)
			{
				this.availableTargets.Clear();
			}
			if(this.blockedCells != null)
			{
				this.blockedCells.Clear();
			}
			if(this.passableCells != null)
			{
				this.passableCells.Clear();
			}
			if(this.cameFrom != null)
			{
				this.cameFrom.Clear();
			}
			if(this.costSoFar != null)
			{
				this.costSoFar.Clear();
			}
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public List<Combatant> GetCombatantsOnPath(BattleGridCellComponent toCell)
		{
			List<Combatant> list = new List<Combatant>();
			this.GetCombatantsOnPath(toCell, ref list);
			return list;
		}

		public void GetCombatantsOnPath(BattleGridCellComponent toCell, ref List<Combatant> list)
		{
			if(list.Count > 0)
			{
				list.Clear();
			}
			if(toCell != null && this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				BattleGridCellComponent current = toCell;
				current.GetCombatants(ref list, null);
				while(current != this.startCell)
				{
					current = this.cameFrom[current];
					if(current != this.startCell)
					{
						current.GetCombatants(ref list, null);
					}
				}
				list.Reverse();
			}
		}


		/*
		============================================================================
		Path functions
		============================================================================
		*/
		public float GetCost(BattleGridCellComponent toCell)
		{
			return this.costSoFar.ContainsKey(toCell) ? this.costSoFar[toCell] : 0;
		}

		public List<BattleGridCellComponent> GetPath(BattleGridCellComponent toCell)
		{
			List<BattleGridCellComponent> path = new List<BattleGridCellComponent>();
			this.GetPath(toCell, ref path);
			return path;
		}

		public void GetPath(BattleGridCellComponent toCell, ref List<BattleGridCellComponent> path)
		{
			if(path.Count > 0)
			{
				path.Clear();
			}
			if(toCell != null && this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				BattleGridCellComponent current = toCell;
				path.Add(current);
				while(current != this.startCell)
				{
					current = this.cameFrom[current];
					if(current != this.startCell)
					{
						path.Add(current);
					}
				}
				path.Reverse();
			}
		}

		public int GetPathLength(BattleGridCellComponent toCell)
		{
			int length = 0;
			if(toCell != null && this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				BattleGridCellComponent current = toCell;
				while(current != this.startCell)
				{
					current = this.cameFrom[current];
					if(current != this.startCell)
					{
						length++;
					}
				}
			}
			return length;
		}

		public BattleGridCellComponent GetLastReachablePathCell(BattleGridCellComponent toCell,
			int stopDistance, ref bool canReach)
		{
			BattleGridCellComponent current = null;
			if(toCell != null &&
				this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				if(stopDistance == 0)
				{
					if(toCell.IsEmpty &&
						!toCell.IsBlocked)
					{
						current = toCell;
					}
				}
				else
				{
					for(int i = 0; i < stopDistance; i++)
					{
						toCell = this.cameFrom[toCell];
						if(toCell.IsEmpty &&
							!toCell.IsBlocked)
						{
							current = toCell;
						}
						if(toCell == this.startCell)
						{
							break;
						}
					}
				}
				if(this.ignoreBlockingCombatants &&
					current == null)
				{
					current = toCell;
				}
				if(current != null)
				{
					canReach = true;
					if(this.ignoreBlockingCombatants)
					{
						BattleGridCellComponent tmpCell = current;
						current = null;
						while(tmpCell != this.startCell)
						{
							if(!tmpCell.IsPassable ||
								!this.CheckCellOccupant(tmpCell.Combatant))
							{
								current = null;
							}
							if(current == null &&
								tmpCell.IsEmpty &&
								!tmpCell.IsBlocked)
							{
								current = tmpCell;
							}
							tmpCell = this.cameFrom[tmpCell];
						}
					}
					if(current != null)
					{
						while(current != this.startCell &&
							this.costSoFar[current] > this.user.Battle.GridMoveRange)
						{
							current = this.cameFrom[current];
							while(current != this.startCell &&
								(!current.IsEmpty || current.IsBlocked))
							{
								current = this.cameFrom[current];
							}
						}
						if(current == this.startCell ||
							(current != null &&
								(!current.IsEmpty || current.IsBlocked)))
						{
							current = null;
						}
					}
				}
			}
			return current;
		}

		public BattleGridCellComponent GetMostDistantCell(BattleGridCellComponent fromCell)
		{
			BattleGridCellComponent current = null;
			if(fromCell != null)
			{
				float maxDistance = Mathf.Infinity;
				for(int i = 0; i < this.availableTargets.Count; i++)
				{
					if(this.availableTargets[i] != null)
					{
						float tmpDistance = fromCell.CubeCoord.Distance(this.availableTargets[i].CubeCoord);
						if(tmpDistance < maxDistance)
						{
							tmpDistance = maxDistance;
							current = this.availableTargets[i];
						}
					}
				}
			}
			return current;
		}


		/*
		============================================================================
		Move range functions
		============================================================================
		*/
		public GridMoveAction GetMoveAction(BattleGridCellComponent toCell, GridMoveShortcut gridMoveShortcut)
		{
			return new GridMoveAction(this.user, this.GetPath(toCell), this.GetCost(toCell), gridMoveShortcut);
		}

		public bool CheckCell(BattleGridCellComponent cell)
		{
			return cell != null && cell.CheckOccupants(this.occupantCheck);
		}

		public bool CheckCellOccupant(Combatant combatant)
		{
			return combatant == null ||
				(ORK.BattleSystem.gridSettings.moveCommand.moveOverAllies &&
					!this.user.IsEnemy(combatant)) ||
				(ORK.BattleSystem.gridSettings.moveCommand.moveOverEnemies &&
					this.user.IsEnemy(combatant));
		}

		public void CreateMoveRange(Combatant user, bool useMaxRange)
		{
			if(user != null && user.GridCell != null)
			{
				this.user = user;
				this.startCell = this.user.GridCell;

				if(this.keepBlockedCells)
				{
					ArrayHelper.GetBlank(ref this.blockedCells);
					ArrayHelper.GetBlank(ref this.passableCells);
				}

				KeyValuePairKeySorter<float, BattleGridCellComponent> sorter =
					new KeyValuePairKeySorter<float, BattleGridCellComponent>(false);
				List<KeyValuePair<float, BattleGridCellComponent>> frontier =
					new List<KeyValuePair<float, BattleGridCellComponent>>();
				frontier.Add(new KeyValuePair<float, BattleGridCellComponent>(0, this.startCell));

				ArrayHelper.GetBlank(ref this.cameFrom);
				this.cameFrom.Add(this.startCell, null);

				ArrayHelper.GetBlank(ref this.costSoFar);
				this.costSoFar.Add(this.startCell, 0);

				List<BattleGridCellComponent> neighbours = new List<BattleGridCellComponent>();
				List<BattleGridCellComponent> used = new List<BattleGridCellComponent>();

				float moveRange = useMaxRange ?
					this.user.Battle.GridMoveRangeMax :
					this.user.Battle.GridMoveRange;

				while(frontier.Count > 0)
				{
					// sort frontier
					if(frontier.Count > 1)
					{
						frontier.Sort(sorter);
					}

					BattleGridCellComponent current = frontier[0].Value;
					frontier.RemoveAt(0);

					if(!used.Contains(current))
					{
						used.Add(current);

						// get neighbours
						if(neighbours.Count > 0)
						{
							neighbours.Clear();
						}

						if(this.keepBlockedCells)
						{
							BattleGridHelper.GetNeighbourCells(current, ref neighbours,
								ref this.blockedCells, true, false,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove, this.cellCheck,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null, null);
						}
						else
						{
							BattleGridHelper.GetNeighbourCells(current, ref neighbours, true, false,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove, this.cellCheck,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null, null);
						}

						for(int i = 0; i < neighbours.Count; i++)
						{
							// check cost
							float newCost = (this.costSoFar.ContainsKey(current) ? this.costSoFar[current] : 0) +
								neighbours[i].Settings.moveCost.GetValue(this.user, this.user);

							if(newCost <= moveRange)
							{
								// new cell
								if(!this.costSoFar.ContainsKey(neighbours[i]))
								{
									this.costSoFar.Add(neighbours[i], newCost);
									frontier.Add(new KeyValuePair<float, BattleGridCellComponent>(newCost, neighbours[i]));
									if(this.cameFrom.ContainsKey(neighbours[i]))
									{
										this.cameFrom[neighbours[i]] = current;
									}
									else
									{
										this.cameFrom.Add(neighbours[i], current);
									}
								}
								// check replace old cell
								else
								{
									float oldCost = this.costSoFar[neighbours[i]];
									if(newCost < oldCost ||
										(newCost == oldCost &&
											// not diagonal
											((ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove &&
												!CubeCoord.IsSquareDiagonal(current.CubeCoord, neighbours[i].CubeCoord)) ||
											// shorter path
											(ORK.BattleSystem.gridSettings.moveCommand.useShortestPath &&
												this.GetPathLength(current) + 1 < this.GetPathLength(neighbours[i])))))
									{
										this.costSoFar[neighbours[i]] = newCost;
										frontier.Add(new KeyValuePair<float, BattleGridCellComponent>(newCost, neighbours[i]));
										if(this.cameFrom.ContainsKey(neighbours[i]))
										{
											this.cameFrom[neighbours[i]] = current;
										}
										else
										{
											this.cameFrom.Add(neighbours[i], current);
										}
									}
								}
							}
						}
					}
				}

				// generate available target cells
				ArrayHelper.GetBlank(ref this.availableTargets);
				foreach(BattleGridCellComponent cell in this.cameFrom.Keys)
				{
					if(cell != null &&
						cell.IsEmpty &&
						!cell.IsBlocked)
					{
						this.availableTargets.Add(cell);
					}
					else if(this.keepBlockedCells)
					{
						this.passableCells.Add(cell);
					}
				}
			}
		}

		public void CreatePathTo(Combatant user, BattleGridCellComponent toCell)
		{
			if(user != null && user.GridCell != null)
			{
				this.user = user;
				this.startCell = this.user.GridCell;

				KeyValuePairKeySorter<float, BattleGridCellComponent> sorter =
					new KeyValuePairKeySorter<float, BattleGridCellComponent>(false);
				List<KeyValuePair<float, BattleGridCellComponent>> frontier =
					new List<KeyValuePair<float, BattleGridCellComponent>>();
				frontier.Add(new KeyValuePair<float, BattleGridCellComponent>(0, this.startCell));

				ArrayHelper.GetBlank(ref this.cameFrom);
				this.cameFrom.Add(this.startCell, null);

				ArrayHelper.GetBlank(ref this.costSoFar);
				this.costSoFar.Add(this.startCell, 0);

				List<BattleGridCellComponent> neighbours = new List<BattleGridCellComponent>();
				List<BattleGridCellComponent> used = new List<BattleGridCellComponent>();
				used.Add(toCell);

				while(frontier.Count > 0)
				{
					// sort frontier
					if(frontier.Count > 1)
					{
						frontier.Sort(sorter);
					}

					BattleGridCellComponent current = frontier[0].Value;
					frontier.RemoveAt(0);

					if(!used.Contains(current))
					{
						used.Add(current);

						// get neighbours
						if(neighbours.Count > 0)
						{
							neighbours.Clear();
						}
						BattleGridHelper.GetNeighbourCells(current, ref neighbours,
							true, false, ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove, null,
							ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null, null);

						for(int i = 0; i < neighbours.Count; i++)
						{
							// check cell combatant
							if(neighbours[i] == toCell ||
								this.ignoreBlockingCombatants ||
								neighbours[i].CheckOccupants(this.occupantCheck))
							{
								float newCost = (this.costSoFar.ContainsKey(current) ? this.costSoFar[current] : 0) +
									neighbours[i].Settings.moveCost.GetValue(this.user, this.user);

								// new cell
								if(!this.costSoFar.ContainsKey(neighbours[i]))
								{
									this.costSoFar.Add(neighbours[i], newCost);
									frontier.Add(new KeyValuePair<float, BattleGridCellComponent>(newCost, neighbours[i]));
									if(this.cameFrom.ContainsKey(neighbours[i]))
									{
										this.cameFrom[neighbours[i]] = current;
									}
									else
									{
										this.cameFrom.Add(neighbours[i], current);
									}
								}
								// check replace old cell
								else
								{
									float oldCost = this.costSoFar[neighbours[i]];
									if(newCost < oldCost ||
										(newCost == oldCost &&
											// not diagonal
											((ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove &&
												!CubeCoord.IsSquareDiagonal(current.CubeCoord, neighbours[i].CubeCoord)) ||
											// shorter path
											(ORK.BattleSystem.gridSettings.moveCommand.useShortestPath &&
												this.GetPathLength(current) + 1 < this.GetPathLength(neighbours[i])))) ||
										// use free cell
										(neighbours[i] == toCell && current.IsEmpty &&
											(!ORK.BattleSystem.gridSettings.squareDiagonalDistanceOne ||
												CubeCoord.Distance(current.CubeCoord, toCell.CubeCoord) == 1) &&
											this.cameFrom.ContainsKey(neighbours[i]) &&
											!this.cameFrom[neighbours[i]].IsEmpty))
									{
										this.costSoFar[neighbours[i]] = newCost;
										frontier.Add(new KeyValuePair<float, BattleGridCellComponent>(newCost, neighbours[i]));
										if(this.cameFrom.ContainsKey(neighbours[i]))
										{
											this.cameFrom[neighbours[i]] = current;
										}
										else
										{
											this.cameFrom.Add(neighbours[i], current);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
