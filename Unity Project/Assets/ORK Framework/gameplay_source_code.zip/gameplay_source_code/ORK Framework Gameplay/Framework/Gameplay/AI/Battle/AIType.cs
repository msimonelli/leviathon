﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIType : BaseLanguageData, IContentSimple
	{
		// parent type
		[ORKEditorHelp("Is Sub Type", "This AI type is a sub type of another AI type.", "")]
		[ORKEditorInfo("Base Settings", "Define the base settings of this AI type.", "")]
		public bool isSubType = false;

		[ORKEditorHelp("Parent AI Type", "Select the AI type that is the parent type of this AI type.\n" +
			"Selecting the this AI type as parent type will result in this type not being a sub type.", "")]
		[ORKEditorInfo(ORKDataType.AIType, endFoldout=true)]
		[ORKEditorLayout("isSubType", true, endCheckGroup=true)]
		public int parentTypeID = 0;

		public AIType()
		{

		}

		public AIType(string name) : base(name)
		{

		}


		/*
		============================================================================
		Parent type functions
		============================================================================
		*/
		public int ParentType
		{
			get
			{
				if(this.isSubType && this.realID != this.parentTypeID)
				{
					return this.parentTypeID;
				}
				return -1;
			}
		}

		public int RootType
		{
			get
			{
				if(this.isSubType && this.realID != this.parentTypeID)
				{
					return ORK.AITypes.Get(this.parentTypeID).RootType;
				}
				return this.realID;
			}
		}

		public bool HasSubTypes()
		{
			for(int i = 0; i < ORK.AITypes.Count; i++)
			{
				if(ORK.AITypes.Get(i).ParentType == this.realID)
				{
					return true;
				}
			}
			return false;
		}

		public bool IsSubTypeOf(int parentID)
		{
			if(this.isSubType && this.parentTypeID != this.realID)
			{
				if(this.parentTypeID == parentID)
				{
					return true;
				}
				else
				{
					return ORK.AITypes.Get(this.parentTypeID).IsSubTypeOf(parentID);
				}
			}
			return false;
		}

		public int GetParentTypeAfter(int parentID)
		{
			if(this.isSubType && this.parentTypeID != this.realID)
			{
				if(this.ParentType == parentID)
				{
					return this.ID;
				}
				else
				{
					return ORK.AITypes.Get(this.ParentType).GetParentTypeAfter(parentID);
				}
			}
			return parentID == -1 ? this.ID : -1;
		}

		public void AddTypeToList(int parentID, ref List<int> list)
		{
			if(parentID == -2 || this.ID == parentID || this.ParentType == parentID)
			{
				if(!list.Contains(this.ID))
				{
					list.Add(this.ID);
				}
			}
			else if(parentID == -1 || this.IsSubTypeOf(parentID))
			{
				int tmpID = this.GetParentTypeAfter(parentID);
				if(tmpID != -1 &&
					!list.Contains(tmpID))
				{
					list.Add(tmpID);
				}
			}
		}

		public List<int> GetTypePath()
		{
			List<int> list = new List<int>();
			this.AddTypePath(ref list);
			return list;
		}

		private void AddTypePath(ref List<int> list)
		{
			list.Insert(0, this.realID);
			if(this.ParentType != -1 && !list.Contains(this.ParentType))
			{
				ORK.AITypes.Get(this.ParentType).AddTypePath(ref list);
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}

		public string GetIconTextCode()
		{
			return TextCode.AITypeIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
