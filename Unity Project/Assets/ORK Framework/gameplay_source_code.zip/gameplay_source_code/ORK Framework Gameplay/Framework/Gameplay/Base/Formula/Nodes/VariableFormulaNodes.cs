
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using ORKFramework.Formulas;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Change Game Variables", "Changes game variables.", "")]
	[ORKNodeInfo("Variable")]
	public class ChangeGameVariableStep : BaseFormulaStep
	{
		// variable origin
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used while calculating a formula and don't interfere with global variables. " +
			"The variable will be gone once the formula finished calculating.\n" +
			"When a formula is called from an event, the local variables are shared with the event and " +
			"will also be available in the running event (until the event ends)." +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data coming from an event.\n" +
			"When coming from a battle event, the variables are usually assigned to the ability or item of the action.\n" +
			"Only available when the formula was initially called by an event.", "")]
		public VariableOrigin variableOrigin = VariableOrigin.Global;

		[ORKEditorLayout("variableOrigin", VariableOrigin.Object, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("variableOrigin", VariableOrigin.Selected, endCheckGroup=true, autoInit=true)]
		public StringValue selectedKey;


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableSetter change = new VariableSetter();

		public ChangeGameVariableStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin = VariableOrigin.Object;
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				this.change.SetVariables(call.Variables);
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				this.change.SetVariables(ORK.Game.Variables);
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						this.change.SetVariables(comp.GetHandler());
					}
				}
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				List<VariableHandler> handlers = SelectedDataHelper.GetVariableHandlers(
					call.SelectedData.Get(this.selectedKey.GetValue()));
				for(int i = 0; i < handlers.Count; i++)
				{
					this.change.SetVariables(handlers[i]);
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				return "Local Variables";
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				return "Global Variables";
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				return "Object Variables: " + this.origin.GetInfoText();
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				return "Selected Variables";
			}
			return "";
		}
	}

	[ORKEditorHelp("Check Game Variables", "Checks if game variables have certain values.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Variable", "Check")]
	public class CheckGameVariableStep : BaseFormulaCheckStep
	{
		// variable origin
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used while calculating a formula and don't interfere with global variables. " +
			"The variable will be gone once the formula finished calculating.\n" +
			"When a formula is called from an event, the local variables are shared with the event and " +
			"will also be available in the running event (until the event ends)." +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data coming from an event.\n" +
			"When coming from a battle event, the variables are usually assigned to the ability or item of the action.\n" +
			"Only available when the formula was initially called by an event.", "")]
		public VariableOrigin variableOrigin = VariableOrigin.Global;

		[ORKEditorLayout("variableOrigin", VariableOrigin.Object, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("variableOrigin", VariableOrigin.Selected, endCheckGroup=true, autoInit=true)]
		public StringValue selectedKey;


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableCondition condition = new VariableCondition();

		public CheckGameVariableStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin = VariableOrigin.Object;
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;
			if(VariableOrigin.Local == this.variableOrigin)
			{
				check = this.condition.CheckVariables(call.Variables);
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				check = this.condition.CheckVariables(ORK.Game.Variables);
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						check = this.condition.CheckVariables(comp.GetHandler());
					}
				}
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				VariableHandler handler = SelectedDataHelper.GetFirstVariableHandler(
					call.SelectedData.Get(this.selectedKey.GetValue()));
				if(handler != null)
				{
					check = this.condition.CheckVariables(handler);
				}
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				return "Local Variables";
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				return "Global Variables";
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				return "Object Variables: " + this.origin.GetInfoText();
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				return "Selected Variables";
			}
			return "";
		}
	}

	[ORKEditorHelp("Game Variable Fork", "Checks if a single game variable for certain values.\n" +
		"If a variable condition is valid, it's next step will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Variable", "Check")]
	public class GameVariableForkStep : BaseFormulaCheckStep
	{
		// variable origin
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used while calculating a formula and don't interfere with global variables. " +
			"The variable will be gone once the formula finished calculating.\n" +
			"When a formula is called from an event, the local variables are shared with the event and " +
			"will also be available in the running event (until the event ends)." +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data coming from an event.\n" +
			"When coming from a battle event, the variables are usually assigned to the ability or item of the action.\n" +
			"Only available when the formula was initially called by an event.", "")]
		public VariableOrigin variableOrigin = VariableOrigin.Global;

		[ORKEditorLayout("variableOrigin", VariableOrigin.Object, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("variableOrigin", VariableOrigin.Selected, endCheckGroup=true, autoInit=true)]
		public StringValue selectedKey;


		// variable
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorArray(false, "Add Condition", "Adds a new game variable condition.", "",
			"Remove", "Removes the game variable condition.", "", isMove=true, isCopy=true,
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the game variable condition that must be valid.", ""
		})]
		public CheckVariableNextNode[] condition = new CheckVariableNextNode[] {new CheckVariableNextNode()};

		public GameVariableForkStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin = VariableOrigin.Object;
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			int check = this.next;

			if(VariableOrigin.Local == this.variableOrigin)
			{
				this.Check(ref check, this.key.GetValue(), call.Variables);
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				this.Check(ref check, this.key.GetValue(), ORK.Game.Variables);
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						this.Check(ref check, this.key.GetValue(), comp.GetHandler());
					}
				}
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				List<VariableHandler> handlers = SelectedDataHelper.GetVariableHandlers(
					call.SelectedData.Get(this.selectedKey.GetValue()));
				for(int i = 0; i < handlers.Count; i++)
				{
					if(this.Check(ref check, this.key.GetValue(), handlers[i]))
					{
						break;
					}
				}
			}

			return check;
		}

		private bool Check(ref int check, string varKey, VariableHandler handler)
		{
			for(int i = 0; i < this.condition.Length; i++)
			{
				if(this.condition[i].Check(varKey, handler))
				{
					check = this.condition[i].next;
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				return "Local Variables";
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				return "Global Variables";
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				return "Object Variables: " + this.origin.GetInfoText();
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				return "Selected Variables";
			}
			return "";
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Condition " + (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Store Formula Value", "Stores the current value of the formula into a float game variable.", "")]
	[ORKNodeInfo("Variable")]
	public class StoreFormulaValueStep : BaseFormulaStep
	{
		// variable origin
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used while calculating a formula and don't interfere with global variables. " +
			"The variable will be gone once the formula finished calculating.\n" +
			"When a formula is called from an event, the local variables are shared with the event and " +
			"will also be available in the running event (until the event ends)." +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data coming from an event.\n" +
			"When coming from a battle event, the variables are usually assigned to the ability or item of the action.\n" +
			"Only available when the formula was initially called by an event.", "")]
		public VariableOrigin variableOrigin = VariableOrigin.Global;

		[ORKEditorLayout("variableOrigin", VariableOrigin.Object, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("variableOrigin", VariableOrigin.Selected, endCheckGroup=true, autoInit=true)]
		public StringValue selectedKey;


		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Set;

		public StoreFormulaValueStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin = VariableOrigin.Object;
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				call.Variables.Set(this.key.GetValue(), call.result);
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				ORK.Game.Variables.Set(this.key.GetValue(), call.result);
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						comp.GetHandler().Set(this.key.GetValue(), call.result);
					}
				}
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				List<VariableHandler> handlers = SelectedDataHelper.GetVariableHandlers(
					call.SelectedData.Get(this.selectedKey.GetValue()));
				for(int i = 0; i < handlers.Count; i++)
				{
					handlers[i].Set(this.key.GetValue(), call.result);
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				return "Local Variables: " + this.key.GetInfoText() +
					" " + this.floatOperator.ToString();
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				return "Global Variables: " + this.key.GetInfoText() +
					" " + this.floatOperator.ToString();
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				return "Object Variables (" + this.origin.GetInfoText() + "): " +
					this.key.GetInfoText() + " " + this.floatOperator.ToString();
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				return "Selected Variables: " + this.key.GetInfoText() +
					" " + this.floatOperator.ToString();
			}
			return "";
		}
	}
}
