﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionCombo : ISaveData
	{
		private int comboID = -1;

		private int stage = 0;

		private float availableTime = 0;

		private ActionComboSettings settings;

		private BaseAction usedAction;

		public ActionCombo()
		{

		}

		public ActionCombo(int comboID)
		{
			this.comboID = comboID;
			this.settings = ORK.ActionCombos.Get(this.comboID);
		}

		public ActionCombo(DataObject data)
		{
			this.LoadGame(data);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public int ID
		{
			get { return this.comboID; }
		}

		public int Stage
		{
			get { return this.stage; }
		}

		public float AvailableTime
		{
			get { return this.availableTime; }
		}


		/*
		============================================================================
		Time functions
		============================================================================
		*/
		public void Tick(Combatant combatant)
		{
			if(this.availableTime > 0 &&
				this.usedAction == null &&
				this.CanDecrease(combatant))
			{
				this.availableTime -= ORK.Core.GUITimeDelta;
				if(this.availableTime <= 0)
				{
					this.availableTime = 0;
					this.stage = 0;
				}
			}
		}

		private bool CanDecrease(Combatant combatant)
		{
			if(ActionTimeDecreaseType.Always == this.settings.decreaseTime)
			{
				return true;
			}
			else if(ActionTimeDecreaseType.WhileChoosing == this.settings.decreaseTime)
			{
				return combatant.Actions.IsChoosing;
			}
			else if(ActionTimeDecreaseType.WhileInAction == this.settings.decreaseTime)
			{
				return combatant.Actions.ActionState == CombatantActionState.InAction;
			}
			return false;
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public void Reset()
		{
			this.stage = 0;
			this.availableTime = 0;
			this.usedAction = null;
		}

		public BaseAction GetReplacementAction(BaseAction action)
		{
			if(this.usedAction == null &&
				this.settings != null &&
				this.stage >= 0 &&
				this.stage < this.settings.action.Length)
			{
				ActionComboStageSettings currentAction = this.settings.action[this.stage];
				for(int i = 0; i < currentAction.requirementAction.Length; i++)
				{
					if(currentAction.requirementAction[i].CheckAction(action))
					{
						if(currentAction.useReplacementAction)
						{
							BaseAction replaceAction = currentAction.replacementAction.
								GetAction(action.User, true, true, action.blockBattleCamera);

							if(replaceAction != null)
							{
								if(action.target != null &&
									action.target.Count > 0)
								{
									List<Combatant> targets = new List<Combatant>();
									for(int j = 0; j < action.target.Count; j++)
									{
										if(replaceAction.CanTarget(action.target[j]))
										{
											targets.Add(action.target[j]);
										}
									}
									if(targets.Count > 0)
									{
										replaceAction.SetTargets(targets);
									}
								}
								this.usedAction = replaceAction;
								return replaceAction;
							}
							else
							{
								this.stage = 0;
								this.availableTime = 0;
							}
						}
						return null;
					}
				}
			}
			return null;
		}

		public void CheckStageIncrease(BaseAction performedAction)
		{
			bool increase = false;

			if(this.settings != null &&
				performedAction != null &&
				this.stage >= 0 &&
				this.stage < this.settings.action.Length)
			{
				if(this.usedAction == performedAction)
				{
					increase = true;
				}
				else
				{
					for(int i = 0; i < this.settings.action[this.stage].requirementAction.Length; i++)
					{
						if(this.settings.action[this.stage].requirementAction[i].CheckAction(performedAction))
						{
							increase = true;
							break;
						}
					}
				}
			}

			this.usedAction = null;
			if(increase)
			{
				this.stage++;
				if(this.stage >= this.settings.action.Length)
				{
					this.stage = 0;
				}
				this.availableTime = this.stage == 0 ?
					0 : this.settings.action[this.stage].availableTime;
			}
			else
			{
				this.stage = 0;
				this.availableTime = 0;
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("comboID", this.comboID);
			data.Set("stage", this.stage);
			data.Set("availableTime", this.availableTime);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("comboID", ref this.comboID);
				data.Get("stage", ref this.stage);
				data.Get("availableTime", ref this.availableTime);

				this.settings = ORK.ActionCombos.Get(this.comboID);
			}
		}
	}
}
