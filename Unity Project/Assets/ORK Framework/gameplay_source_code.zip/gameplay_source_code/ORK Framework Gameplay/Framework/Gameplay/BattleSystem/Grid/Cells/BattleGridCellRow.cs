﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class BattleGridCellRow
	{
		public BattleGridCellComponent[] cell;

		public BattleGridCellRow()
		{

		}

		public BattleGridCellRow(int size)
		{
			this.cell = new BattleGridCellComponent[size];
		}

		public int Length
		{
			get { return this.cell != null ? this.cell.Length : 0; }
		}

		public BattleGridCellComponent this[int index]
		{
			get
			{
				if(this.cell != null && index < this.cell.Length)
				{
					return this.cell[index];
				}
				return null;
			}
			set
			{
				if(this.cell != null && index < this.cell.Length)
				{
					this.cell[index] = value;
				}
			}
		}
	}
}
