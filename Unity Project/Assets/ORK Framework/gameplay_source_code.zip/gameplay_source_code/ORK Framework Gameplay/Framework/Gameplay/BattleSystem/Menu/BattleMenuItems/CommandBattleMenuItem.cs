﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class CommandBattleMenuItem : BaseBattleMenuItem
	{
		[ORKEditorHelp("Only AI Combatants", "Commands can only be given to AI controlled combatants of the group.\n" +
			"If disabled, commands can be given to all combatants of the group.", "")]
		public bool onlyAICombatants = false;


		// button
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		public LanguageInfo[] button = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);

		public CommandBattleMenuItem()
		{

		}

		public CommandBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.Command == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			ChoiceContent cc = bm.contentLayout.GetChoiceContent(this.button);
			this.customSkin.SetSkin(cc);
			list.Add(new CommandBMItem(cc, null, parent));
		}
	}
}
