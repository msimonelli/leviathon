﻿
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveAIHunting : BaseData
	{
		// hunting settings
		[ORKEditorHelp("Use Hunting", "The hunting settings are enabled.\n" +
			"If disabled, the combatant wont react to enemy combatants.\n" +
			"Please note that only aggressive combatants will hunt enemies.", "")]
		public bool enabled = false;


		// hunting range
		[ORKEditorHelp("Use Hunting Range", "The combatant will only hunt within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the hunting range, the combatant will return to its start position." +
			"If disabled, there is no limit to the hunting range.", "")]
		[ORKEditorInfo("Hunting Range", "Optionally only hunt within a defined range of the combatant's start position.", "")]
		[ORKEditorLayout("enabled", true)]
		public bool useRange = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useRange", true, endCheckGroup=true, autoInit=true)]
		public Range range;


		// stop range
		[ORKEditorHelp("Use Stop Range", "The combatant will stop when being within a defined range to the target." +
			"If disabled, the combatant will keep running toward the target.", "")]
		[ORKEditorInfo("Stop Range", "Optionally stop hunting being within a defined range to the target.", "")]
		public bool useStopRange = false;

		[ORKEditorLayout("useStopRange", true, autoInit=true)]
		public Range stopRange;

		[ORKEditorHelp("Use Action Range", "The use range of a selected action is used when moving into range.\n" +
			"A combatant will only move into range when the used action is out of range to the target.\n" +
			"If the action doesn't have a use range, the stop range will be used.", "")]
		public bool useActionStopRange = false;

		// target angle
		[ORKEditorHelp("Use Stop Angle", "The target position (based on the stop range) will be placed at a defined angle to the target.", "")]
		[ORKEditorInfo(separator=true, labelText="Stop Angle")]
		public bool useStopAngle = false;

		[ORKEditorHelp("Local Space", "The stop angle is used in local space of the target.\n" +
			"E.g. 0 will always be in front, 90 on the right side." +
			"If disabled, world space is used, e.g. 0 being north, 90 being east.\n" +
			"Depending on the used horizontal plane, a different rotation axis is used for determining the local space:\n" +
			"- XZ: The Y-axis.\n" +
			"- XY: The Z-axis.", "")]
		[ORKEditorLayout("useStopAngle", true)]
		public bool stopAngleLocal = false;

		[ORKEditorHelp("Stop Angle", "The angle used to determine the target position.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public float stopAngle = 0;


		// conditions
		[ORKEditorHelp("Conditions Needed", "Select if all or just one condition must be valid to hunt the target.", "")]
		[ORKEditorInfo("Hunting Conditions", "Optionally only hunt when defined conditions are valid.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorArray(false, "Add Hunting Condition", "Adds a hunting condition.\n" +
			"You can use multiple conditions to determine if the combatant hunts the target.", "",
			"Remove", "Removes this hunting condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Hunting Condition", "Hunting conditions determine if the combatant hunts the target.", ""
			})]
		public MoveCondition[] condition = new MoveCondition[0];

		public MoveAIHunting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useHunting"))
			{
				data.Get("useHunting", ref this.enabled);

				data.Get("useHuntingRange", ref this.useRange);
				if(this.useRange)
				{
					DataObject tmp = data.GetFile("huntingRange");
					this.range = new Range();
					if(tmp != null)
					{
						this.range.SetData(tmp);
					}
				}

				data.Get("useHuntingStopRange", ref this.useStopRange);
				if(this.useStopRange)
				{
					DataObject tmp = data.GetFile("huntingStopRange");
					this.stopRange = new Range();
					if(tmp != null)
					{
						this.stopRange.SetData(tmp);
					}
				}

				data.Get("huntingNeeded", ref this.needed);
				DataObject[] tmpCondition = data.GetFileArray("huntingCondition");
				if(tmpCondition != null)
				{
					this.condition = new MoveCondition[tmpCondition.Length];
					for(int i = 0; i < this.condition.Length; i++)
					{
						this.condition[i] = new MoveCondition();
						this.condition[i].SetData(tmpCondition[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Hunting functions
		============================================================================
		*/
		public bool IsHunting(Combatant combatant, Combatant target)
		{
			if(this.enabled && combatant.IsAggressive)
			{
				if(this.condition != null && this.condition.Length > 0)
				{
					for(int i = 0; i < this.condition.Length; i++)
					{
						if(this.condition[i].IsValid(combatant, target))
						{
							if(Needed.One == this.needed)
							{
								return true;
							}
						}
						else if(Needed.All == this.needed)
						{
							return false;
						}
					}

					if(Needed.All == this.needed)
					{
						return true;
					}
					else if(Needed.One == this.needed)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool IsInRange(Vector3 startPosition, Combatant combatant)
		{
			return !this.useRange ||
				this.range == null ||
				this.range.InRange(startPosition, combatant);
		}

		public bool IsOutOfRange(Vector3 startPosition, Combatant combatant)
		{
			return this.useRange &&
				this.range != null &&
				this.range.OutOfRange(startPosition, combatant);
		}

		public void Use(MoveAIComponent moveAI)
		{
			Vector3 targetPosition = this.GetTargetPosition(moveAI);
			if(this.enabled &&
				this.IsOutOfRange(moveAI.startPosition, moveAI.combatant))
			{
				moveAI.targetLostTimeout = -1;
				moveAI.ClearTarget(false);

				moveAI.SetMode(MoveAIMode.Waypoint);
				moveAI.SetMovePosition(moveAI.startPosition);
			}
			else if(this.enabled &&
				this.useStopRange)
			{
				if(moveAI.HuntStopRange.InRange(targetPosition, moveAI.combatant, 0.1f))
				{
					moveAI.targetPosTimeout = -1;
					moveAI.Stop();
				}
				else if(!moveAI.IsTargetLost())
				{
					moveAI.UpdateTargetPosition(true);
				}
			}
			else if(!moveAI.IsTargetLost())
			{
				moveAI.UpdateTargetPosition(true);
			}
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public Vector3 GetTargetPosition(MoveAIComponent moveAI)
		{
			if(moveAI.TargetCombatant != null &&
				moveAI.TargetCombatant.GameObject != null)
			{
				if(this.enabled &&
					this.useStopRange)
				{
					if(this.useStopAngle)
					{
						return moveAI.HuntStopRange.GetAngledPosition(
							moveAI.TargetCombatant,
							this.stopAngle, this.stopAngleLocal,
							moveAI.settings.horizontalPlane);
					}
					else
					{
						return Vector3.MoveTowards(
							moveAI.TargetCombatant.GameObject.transform.position,
							moveAI.combatant.GameObject.transform.position,
							moveAI.HuntStopRange.GetRange(moveAI.TargetCombatant));
					}
				}
				return moveAI.TargetCombatant.GameObject.transform.position;
			}
			else
			{
				return moveAI.combatant.GameObject.transform.position;
			}
		}

		public bool ReachedTarget(MoveAIComponent moveAI)
		{
			if(this.enabled &&
				this.useStopRange)
			{
				if(moveAI.HuntStopRange.InRange(this.GetTargetPosition(moveAI), moveAI.combatant, 0.1f))
				{
					return true;
				}
				return false;
			}
			return true;
		}
	}
}
