﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class ChangeMemberBattleMenuItem : BaseBattleMenuItem
	{
		// button
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		public LanguageInfo[] button = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);

		public ChangeMemberBattleMenuItem()
		{

		}

		public ChangeMemberBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.ChangeMember == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			ChoiceContent cc = bm.contentLayout.GetChoiceContent(this.button);
			this.customSkin.SetSkin(cc);
			list.Add(new ChangeMemberBMItem(cc, null));
		}
	}
}
