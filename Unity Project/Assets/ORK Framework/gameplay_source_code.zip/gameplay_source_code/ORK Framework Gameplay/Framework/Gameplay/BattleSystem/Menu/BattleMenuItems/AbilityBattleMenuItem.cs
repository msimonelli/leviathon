﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AbilityBattleMenuItem : BaseBattleMenuItem
	{
		// ability type
		[ORKEditorHelp("Limit Ability Type", "Limit the displayed abilities to a defined ability type and it's sub-types.", "")]
		public bool limitAbilityType = false;

		[ORKEditorHelp("Ability Type", "Select the ability type that will be used to limit the displayed abilities.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType)]
		[ORKEditorLayout("limitAbilityType", true, endCheckGroup=true)]
		public int abilityTypeID = 0;


		// ability
		[ORKEditorHelp("Type Display", "Select how ability types are displayed:\n" +
			"- Combined: All types are displayed in a combined option. You can display the types in a sub-menu.\n" +
			"- Type: All types are listed individually.\n" +
			"- List: All abilities are listed directly, without any type list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BMTypeDisplay typeDisplay = BMTypeDisplay.Combined;

		[ORKEditorHelp("Sub Menu", "Display the ability/item types in a sub-menu.\n" +
			"If disabled, all abilities/items will be displayed without a type filter.", "")]
		[ORKEditorLayout("typeDisplay", BMTypeDisplay.Combined, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool subMenu = false;

		[ORKEditorHelp("Add Temporary Abilities", "Select if temporary abilities will be included:\n" +
			"- Yes: Temporary abilities will be included.\n" +
			"- No: Temporary abilities will not be included.\n" +
			"- Only: Only temporary abilities will be displayed.", "")]
		public IncludeCheckType addTemporaryAbilities = IncludeCheckType.Yes;


		// sorting
		[ORKEditorInfo(separator=true, labelText="Type Sorting")]
		[ORKEditorLayout(new string[] {"typeDisplay", "subMenu"},
			new System.Object[] {BMTypeDisplay.Type, true},
			needed=Needed.One, endCheckGroup=true)]
		public TypeSorter typeSorter = new TypeSorter();

		[ORKEditorInfo(separator=true, labelText="List Sorting")]
		public ContentSorter contentSorter = new ContentSorter();


		// button
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		[ORKEditorLayout("typeDisplay", BMTypeDisplay.Combined, endCheckGroup=true,
			autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;

		public AbilityBattleMenuItem()
		{

		}

		public AbilityBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.Ability == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			// combined
			if(BMTypeDisplay.Combined == this.typeDisplay)
			{
				ChoiceContent cc = bm.contentLayout.GetChoiceContent(this.button);
				this.customSkin.SetSkin(cc);
				list.Add(new TypeBMItem(cc,
					this.limitAbilityType ? this.abilityTypeID : -1, parent, false));
			}
			// list types
			else if(BMTypeDisplay.Type == this.typeDisplay)
			{
				List<int> types = owner.Abilities.GetTypes(UseableIn.Battle, this.addTemporaryAbilities,
						this.limitAbilityType ? this.abilityTypeID : -1);
				this.typeSorter.Sort(ref types, ORKDataType.AbilityType);
				for(int i = 0; i < types.Count; i++)
				{
					AbilityType abilityType = ORK.AbilityTypes.Get(types[i]);
					ChoiceContent cc = bm.contentLayout.GetChoiceContent(abilityType);
					this.customSkin.SetSkin(cc);
					TypeBMItem tmp = new TypeBMItem(cc, types[i], parent, false);
					tmp.hasSubTypes = abilityType.HasSubTypes();
					list.Add(tmp);
				}
			}
			// list abilities
			else if(BMTypeDisplay.List == this.typeDisplay)
			{
				List<AbilityShortcut> abilities = this.limitAbilityType ?
					owner.Abilities.GetByType(this.abilityTypeID, UseableIn.Battle, this.addTemporaryAbilities, true) :
					owner.Abilities.GetAbilities(UseableIn.Battle, this.addTemporaryAbilities);
				this.contentSorter.Sort(ref abilities);
				for(int i = 0; i < abilities.Count; i++)
				{
					ChoiceContent cc = bm.contentLayout.GetChoiceContent(abilities[i], owner);
					this.customSkin.SetSkin(cc);
					list.Add(new AbilityBMItem(abilities[i], cc));
				}
			}
		}
	}
}
