
using UnityEngine;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class CheckFields : BaseData
	{
		[ORKEditorHelp("Needed", "Either all or just one of the field/property checks needs to be valid.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;

		// parameters
		[ORKEditorArray(false, "Add Field", "Adds a field that will be checked.", "",
			"Remove", "Removes this field.", "",
			foldout=true, foldoutText=new string[] {"Field", "The field's value will be checked.", ""})]
		public CheckField[] field = new CheckField[0];

		public CheckFields()
		{

		}

		public bool Check(System.Object instance)
		{
			if(instance != null)
			{
				System.Type instanceType = instance.GetType();
				if(instanceType != null)
				{
					if(this.field.Length > 0)
					{
						for(int i = 0; i < this.field.Length; i++)
						{
							if(this.field[i].Check(instance, instanceType))
							{
								if(Needed.One == this.needed)
								{
									return true;
								}
							}
							else if(Needed.All == this.needed)
							{
								return false;
							}
						}
						if(Needed.All == this.needed)
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return true;
					}
				}
			}
			return false;
		}

		public bool CheckStatic(string className)
		{
			if(className != "")
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(className);
				if(classType != null)
				{
					if(this.field.Length > 0)
					{
						for(int i = 0; i < this.field.Length; i++)
						{
							if(this.field[i].CheckStatic(classType))
							{
								if(Needed.One == this.needed)
								{
									return true;
								}
							}
							else if(Needed.All == this.needed)
							{
								return false;
							}
						}
						if(Needed.All == this.needed)
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return true;
					}
				}
				else
				{
					Debug.LogWarning("Class not found: " + className);
				}
			}
			return false;
		}
	}
}
