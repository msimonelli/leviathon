﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantGridDistanceSorter : IComparer<Combatant>
	{
		private Combatant user;

		private bool inverse = false;

		public CombatantGridDistanceSorter(Combatant user, bool inverse)
		{
			this.user = user;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				if(x.GridCell == null &&
					y.GridCell == null)
				{
					return 0;
				}
				else if(x.GridCell != null &&
					y.GridCell == null)
				{
					return 1;
				}
				else if(x.GridCell == null &&
					y.GridCell != null)
				{
					return -1;
				}
				else
				{
					return user.GridCell.CubeCoord.Distance(y.GridCell.CubeCoord).CompareTo(
						user.GridCell.CubeCoord.Distance(x.GridCell.CubeCoord));
				}
			}
			else
			{
				if(x.GridCell == null &&
					y.GridCell == null)
				{
					return 0;
				}
				else if(x.GridCell != null &&
					y.GridCell == null)
				{
					return -1;
				}
				else if(x.GridCell == null &&
					y.GridCell != null)
				{
					return 1;
				}
				else
				{
					return user.GridCell.CubeCoord.Distance(x.GridCell.CubeCoord).CompareTo(
						user.GridCell.CubeCoord.Distance(y.GridCell.CubeCoord));
				}
			}
		}
	}
}
