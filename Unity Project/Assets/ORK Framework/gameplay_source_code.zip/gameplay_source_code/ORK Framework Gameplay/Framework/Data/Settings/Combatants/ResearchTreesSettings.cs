﻿
using UnityEngine;

namespace ORKFramework
{
	public class ResearchTreesSettings : BaseLanguageSettings
	{
		public ResearchTreeSetting[] data = new ResearchTreeSetting[] {new ResearchTreeSetting("None")};

		public ResearchTreesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}

		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "researchTrees"; }
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ResearchTreeSetting newData = new ResearchTreeSetting("New");
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.ResearchTree);
			return this.data.Length - 1;
		}

		public override int Copy(int index)
		{
			ResearchTreeSetting newData = this.GetCopy(index);
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.ResearchTree);
			return this.data.Length - 1;
		}

		public ResearchTreeSetting GetCopy(int index)
		{
			ResearchTreeSetting tmp = new ResearchTreeSetting();
			if(index >= 0 && index < this.data.Length)
			{
				tmp.SetData(this.data[index].GetData());
				tmp.RealID = index;
			}
			return tmp;
		}

		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.ResearchTree, index);
		}

		public ResearchTreeSetting Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else if(this.data.Length > 0)
			{
				return this.data[0];
			}
			else
			{
				return null;
			}
		}

		public ResearchItemSetting Get(int index, int index2)
		{
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null)
			{
				if(index2 >= 0 && index2 < tree.item.Length)
				{
					return tree.item[index2];
				}
				else if(tree.item.Length > 0)
				{
					return tree.item[0];
				}
			}
			return null;
		}

		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.ResearchTree, down, index);
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetName();
			}
			else
			{
				return "ResearchTree " + index + " not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}

		public override int Count
		{
			get { return this.data.Length; }
		}

		public string GetName(int index, int index2)
		{
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null)
			{
				if(index2 >= 0 && index2 < tree.item.Length)
				{
					return tree.GetName(index2);
				}
				else
				{
					return "ResearchTree " + index + ", ResearchItem " + index2 + " not found";
				}
			}
			else
			{
				return "ResearchTree " + index + " not found";
			}
		}

		public string[] GetNames(int index, bool addIndex)
		{
			string[] names = new string[0];
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null)
			{
				names = new string[tree.item.Length];
				for(int i = 0; i < names.Length; i++)
				{
					if(addIndex)
					{
						names[i] = i + ": " + this.GetName(index, i);
					}
					else
					{
						names[i] = this.GetName(index, i);
					}
				}
			}
			return names;
		}

		public int AttributeCount(int index)
		{
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null)
			{
				return tree.item.Length;
			}
			else
			{
				return 0;
			}
		}

		public override string GetDescription(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetDescription();
			}
			else
			{
				return "ResearchTree " + index + " not found";
			}
		}

		public string GetDescription(int index, int index2)
		{
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null && index2 >= 0 && index2 < tree.item.Length)
			{
				return tree.GetDescription(index2);
			}
			else
			{
				return "ResearchTree " + index + ", ResearchItem " + index2 + " not found";
			}
		}

		public override Texture GetIcon(int index)
		{
			Texture tex = null;

			if(index >= 0 && index < this.data.Length)
			{
				int l = ORK.Game.Language;
				tex = this.data[index].languageInfo[l].GetIcon();
				if(tex == null && l != 0)
				{
					tex = this.data[index].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}

		public Texture GetIcon(int index, int index2)
		{
			Texture tex = null;
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null && index2 >= 0 && index2 < tree.item.Length)
			{
				return tree.GetIcon(index2);
			}
			return tex;
		}
	}
}
