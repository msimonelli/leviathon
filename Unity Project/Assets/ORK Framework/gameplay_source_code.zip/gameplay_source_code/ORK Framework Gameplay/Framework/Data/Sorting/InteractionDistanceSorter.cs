﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class InteractionDistanceSorter : IComparer<BaseInteraction>
	{
		private InteractionController controller;

		private Vector3 position;

		public InteractionDistanceSorter(InteractionController controller)
		{
			this.controller = controller;
			this.UpdatePosition();
		}

		public void UpdatePosition()
		{
			this.position = this.controller.transform.TransformPoint(this.controller.nearestOffset);
		}

		public int Compare(BaseInteraction x, BaseInteraction y)
		{
			if(x != null && y != null)
			{
				return VectorHelper.Distance(this.position, x.transform.position,
						this.controller.nearestIgnoreHeightDistance).CompareTo(
					VectorHelper.Distance(this.position, y.transform.position,
						this.controller.nearestIgnoreHeightDistance));
			}
			return 0;
		}
	}
}
