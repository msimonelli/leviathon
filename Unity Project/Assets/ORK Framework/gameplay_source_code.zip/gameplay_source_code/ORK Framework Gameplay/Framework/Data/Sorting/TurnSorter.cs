
using System.Collections.Generic;

namespace ORKFramework
{
	public class TurnSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		public TurnSorter(bool inverse)
		{
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(x.Battle.TurnValue < y.Battle.TurnValue)
			{
				return this.inverse ? -1 : 1;
			}
			else if(x.Battle.TurnValue > y.Battle.TurnValue)
			{
				return this.inverse ? 1 : -1;
			}
			else
			{
				return 0;
			}
		}
	}

	public class DummyTurnSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		public DummyTurnSorter(bool inverse)
		{
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(x.Battle.TurnValueDummy < y.Battle.TurnValueDummy)
			{
				return this.inverse ? -1 : 1;
			}
			else if(x.Battle.TurnValueDummy > y.Battle.TurnValueDummy)
			{
				return this.inverse ? 1 : -1;
			}
			else
			{
				return 0;
			}
		}
	}
}
