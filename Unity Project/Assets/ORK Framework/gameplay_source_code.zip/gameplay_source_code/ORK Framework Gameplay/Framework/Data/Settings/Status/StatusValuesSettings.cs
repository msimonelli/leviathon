
using UnityEngine;

namespace ORKFramework
{
	public class StatusValuesSettings : BaseLanguageSettings
	{
		public StatusValueSetting[] data = new StatusValueSetting[] {new StatusValueSetting("Default Value")};
		
		public StatusValuesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "statusValues"; }
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			StatusValueSetting newData = new StatusValueSetting("New");
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.StatusValue);
			return this.data.Length - 1;
		}
		
		public override int Copy(int index)
		{
			StatusValueSetting newData = this.GetCopy(index);
			newData.expType = ExperienceType.None;
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.StatusValue);
			return this.data.Length - 1;
		}
		
		public StatusValueSetting GetCopy(int index)
		{
			StatusValueSetting tmp = new StatusValueSetting();
			if(index >= 0 && index < this.data.Length)
			{
				tmp.SetData(this.data[index].GetData());
				tmp.RealID = index;
			}
			return tmp;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.StatusValue, index);
		}
		
		public StatusValueSetting Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else if(this.data.Length > 0)
			{
				return this.data[0];
			}
			else
			{
				return null;
			}
		}
		
		public int GetFirstConsumable()
		{
			for(int i=0; i<this.data.Length; i++)
			{
				if(this.data[i].IsConsumable())
				{
					return i;
				}
			}
			return -1;
		}
		
		public StatusValue Create(int index, Combatant owner)
		{
			if(index >= 0 && index < this.Count)
			{
				return new StatusValue(index, this.data[index], owner);
			}
			return null;
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.StatusValue, down, index);
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetName();
			}
			else
			{
				return "StatusValue " + index + " not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		public override string GetDescription(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetDescription();
			}
			else
			{
				return "StatusValue " + index + " not found";
			}
		}
		
		public override Texture GetIcon(int index)
		{
			Texture tex = null;
			
			if(index >= 0 && index < this.data.Length)
			{
				int l = ORK.Game.Language;
				tex = this.data[index].languageInfo[l].GetIcon();
				if(tex == null && l != 0)
				{
					tex = this.data[index].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}
		
		
		/*
		============================================================================
		Add, remove callbacks
		============================================================================
		*/
		public void SetStatusValueType(int index, StatusValueType val)
		{
			for(int i=0; i<this.data.Length; i++)
			{
				if(this.data[i].IsConsumable() && 
					this.data[i].barrier != null)
				{
					for(int j=0; j<this.data[i].barrier.Length; j++)
					{
						if(this.data[i].barrier[j].statusID == index)
						{
							ArrayHelper.RemoveAt(ref this.data[i].barrier, j--);
						}
					}
				}
			}
		}
	}
}
