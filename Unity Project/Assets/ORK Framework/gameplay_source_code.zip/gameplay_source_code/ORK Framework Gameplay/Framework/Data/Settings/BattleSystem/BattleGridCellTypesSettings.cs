﻿
using UnityEngine;

namespace ORKFramework
{
	public class BattleGridCellTypesSettings : BaseLanguageSettings
	{
		public BattleGridCellType[] data = new BattleGridCellType[] {new BattleGridCellType("Default")};

		public BattleGridCellTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}

		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleGridCellTypes"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetName();
			}
			else
			{
				return "BattleGridCellType(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}

		public override int Count
		{
			get { return this.data.Length; }
		}

		public override string GetDescription(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetDescription();
			}
			else
			{
				return "Armor " + index + " not found";
			}
		}

		public override Texture GetIcon(int index)
		{
			Texture tex = null;

			if(index >= 0 && index < this.data.Length)
			{
				int l = ORK.Game.Language;
				tex = this.data[index].languageInfo[l].GetIcon();
				if(tex == null && l != 0)
				{
					tex = this.data[index].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new BattleGridCellType("New"));
			DataHelper.Added(ORKDataType.BattleGridCellType);
			return this.data.Length - 1;
		}

		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.BattleGridCellType);
			return this.data.Length - 1;
		}

		public BattleGridCellType GetCopy(int index)
		{
			BattleGridCellType t = new BattleGridCellType();
			if(index >= 0 && index < this.data.Length)
			{
				t.SetData(this.data[index].GetData());
			}
			return t;
		}

		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.BattleGridCellType, index);
		}

		public BattleGridCellType Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}

		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.BattleGridCellType, down, index);
		}
	}
}
